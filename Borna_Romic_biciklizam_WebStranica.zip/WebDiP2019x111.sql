-- phpMyAdmin SQL Dump
-- version 4.5.4.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 17, 2020 at 12:35 PM
-- Server version: 5.5.62-0+deb8u1
-- PHP Version: 7.2.25-1+0~20191128.32+debian8~1.gbp108445

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `WebDiP2019x111`
--

-- --------------------------------------------------------

--
-- Table structure for table `biciklijada`
--

CREATE TABLE `biciklijada` (
  `id_biciklijada` int(11) NOT NULL,
  `naziv_biciklijade` varchar(45) NOT NULL,
  `vrijeme_pocetka` datetime NOT NULL,
  `vrijeme_zavrsetka` datetime NOT NULL,
  `id_administrator` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `biciklijada`
--

INSERT INTO `biciklijada` (`id_biciklijada`, `naziv_biciklijade`, `vrijeme_pocetka`, `vrijeme_zavrsetka`, `id_administrator`) VALUES
(1, '4 Islands', '2021-04-29 08:00:00', '2021-05-05 20:00:00', 1),
(2, 'Bic Pak', '2021-04-16 10:00:00', '2021-04-21 19:00:00', 1),
(3, 'Weekend Bike & Gourmet Tour', '2021-04-18 06:00:00', '2021-04-19 15:00:00', 1),
(4, 'BIMEP', '2021-06-09 08:00:00', '2021-06-12 09:00:00', 5),
(5, 'E-BIKE', '2019-04-30 08:00:00', '2019-05-01 18:00:00', 5),
(6, 'Gora Bike', '2021-04-24 07:00:00', '2021-04-24 21:00:00', 6),
(7, 'Limes Bike Tour', '2020-06-03 06:00:00', '2021-06-28 15:00:00', 6),
(8, 'Zabok Bike Tour', '2021-04-30 11:00:00', '2021-04-30 19:00:00', 6),
(9, '1-2-3-4 VirBike', '2021-03-30 06:00:00', '2021-03-30 23:00:00', 1),
(10, 'Karlovačke 4 rijeke', '2018-08-11 08:00:00', '2018-08-12 21:00:00', 5),
(11, 'Prošla', '2019-06-10 00:00:00', '2019-06-15 00:00:00', 1),
(20, 'Projektna biciklijada', '2021-04-18 06:00:00', '2021-04-20 06:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `dnevnik`
--

CREATE TABLE `dnevnik` (
  `id_dnevnik` int(11) NOT NULL,
  `radnja` text NOT NULL,
  `upit` text NOT NULL,
  `datum_vrijeme` datetime NOT NULL,
  `id_korisnik` int(11) NOT NULL,
  `id_tip` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `dnevnik`
--

INSERT INTO `dnevnik` (`id_dnevnik`, `radnja`, `upit`, `datum_vrijeme`, `id_korisnik`, `id_tip`) VALUES
(1, 'prijava.html', 'SELECT * FROM korisnik;', '2020-04-04 15:00:00', 1, 1),
(2, 'obrazac.html', 'SELECT * FROM biciklijada;', '2020-04-06 13:00:00', 1, 2),
(3, 'prijava.html', 'SELECT * FROM korisnik;', '2020-04-08 12:00:00', 4, 1),
(4, 'prijava.html', 'SELECT * FROM korisnik;', '2020-04-09 09:00:00', 7, 1),
(5, 'prijava.html', 'SELECT * FROM korisnik;', '2020-04-01 13:00:00', 9, 1),
(6, 'prijava.html', 'SELECT * FROM korisnik;', '0000-00-00 00:00:00', 5, 1),
(7, 'obrazac.html', 'SELECT * FROM korisnik, utrka;', '2020-04-03 09:00:00', 10, 3),
(8, 'prijava.html', 'SELECT * FROM korisnik;', '2020-04-01 11:21:18', 6, 1),
(9, 'prijava.html', 'SELECT * FROM korisnik;', '2020-04-01 23:00:00', 2, 1),
(10, 'prijava.html', 'SELECT * FROM korisnik;', '2020-02-12 01:00:00', 3, 1);

-- --------------------------------------------------------

--
-- Table structure for table `korisnik`
--

CREATE TABLE `korisnik` (
  `id_korisnik` int(11) NOT NULL,
  `ime` varchar(45) NOT NULL,
  `prezime` varchar(45) NOT NULL,
  `godina_rodenja` date DEFAULT NULL,
  `korisnicko_ime` varchar(25) NOT NULL,
  `email` varchar(45) NOT NULL,
  `zaporka` varchar(25) NOT NULL,
  `lozinka_sha1` char(40) DEFAULT NULL,
  `uvjeti` datetime DEFAULT NULL,
  `status` tinyint(1) NOT NULL,
  `aktivacijski_kod` text,
  `id_uloga` int(11) NOT NULL,
  `broj_prijava` int(11) DEFAULT NULL,
  `dozvola_slika` tinyint(4) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `korisnik`
--

INSERT INTO `korisnik` (`id_korisnik`, `ime`, `prezime`, `godina_rodenja`, `korisnicko_ime`, `email`, `zaporka`, `lozinka_sha1`, `uvjeti`, `status`, `aktivacijski_kod`, `id_uloga`, `broj_prijava`, `dozvola_slika`) VALUES
(1, 'Borna', 'Romić', '1998-03-30', 'bromic', 'bromic@foi.hr', 'bromiclozinka', '42acfb5a1b049160405bca8e6b9a23a06f810ed4', '2020-03-30 12:00:00', 1, NULL, 1, 0, 1),
(2, 'Sven', 'Petrović', '1998-05-20', 'spetrovic', 'spetrovic@foi.hr', 'spetroviclozinka', '54d786b0883ac7029a7c413ab76a074f87db8060', '2020-03-30 15:00:00', 1, NULL, 2, 0, 1),
(3, 'Emil', 'Mihalić', '1998-05-23', 'emihalic', 'emihalic@foi.hr', 'emihaliczaporka', '6c8dc4fe0961a35a1ad7002b7dd1139aa9100a58', '2020-04-02 20:00:00', 1, NULL, 2, 0, 0),
(4, 'Luka', 'Mrkonjić', '1999-05-20', 'lukamrko', 'lukamrko@foi.hr', 'lukamrkolozinka', NULL, '2020-04-03 23:00:00', 1, NULL, 2, 0, 0),
(5, 'Lukarozic', 'Rožić', '1998-02-02', 'lrozic', 'lrozic@foi.hr', 'lroziczaporka', '77367bc0f3e8e4272fffbb773a2460141f0f07f5', '2020-04-05 03:00:00', 1, NULL, 1, 0, 0),
(6, 'Martina', 'Ricijaš', '1998-01-20', 'mricijas', 'mricijas@foi.hr', 'mricijaszaporka', '405ee1c0897db9a7d7c847b47dd53b65d0b4f111', '2020-04-05 08:00:00', 1, NULL, 1, 0, 0),
(7, 'Tomislav', 'Periša', '1930-05-20', 'tperisa', 'tperisa@foi.hr', 'tperisazaporka', NULL, '2020-04-03 09:05:32', 1, NULL, 3, 0, 0),
(8, 'Josip', 'Matoković', '1999-03-30', 'jmatokovic', 'jmatokovic@foi.hr', 'jmatokoviczaporka', NULL, '2020-04-05 09:00:00', 0, NULL, 3, 0, 0),
(9, 'Karlo', 'Nenadić', '1998-05-20', 'knenadic', 'knenadic@foi.hr', 'knenadiczaporka', '3219cbbfff8a1880226b8211f7ca71fbc556f031', '2020-04-02 08:00:00', 1, NULL, 3, 0, 1),
(10, 'Zvonimir', 'Petričušić', '1998-09-20', 'zpetricusic', 'zpetricusic@foi.hr', 'zpetricusiczaporka', NULL, '2020-04-03 06:00:00', 1, NULL, 3, 0, 0),
(11, 'Neprijavljen', 'Neprijavljen', NULL, 'Neprijavljen', 'Neprijavljen', 'Neprijavljen', NULL, NULL, 0, NULL, 4, NULL, 0),
(13, 'ivicas', 'ivicevic', '1998-03-30', 'ivicovski', 'ivicev@mail', 'ivica', '7e1ef76c2c0ee96b136d1e7a8b8da42f6a64b610', NULL, 0, NULL, 3, 0, 0),
(59, 'Sanja', 'Romić', '1998-04-30', 'sanja', 'sanja@foi.hr', 'Sanja123', '90e1fa6205d9b44eef806126ece69230279889e8', NULL, 1, NULL, 1, 0, 0),
(73, 'Velimir', 'Velijanko', '1998-03-31', 'Velijanko', 'romic.borndawfa@gmail.com', 'Velij123', 'ae0018f20aeb97040719053a24e1b5a8dd4dcdd5', NULL, 1, 'SZmtZinS', 3, 0, 0),
(79, 'Pero', 'Perić', '1998-03-31', 'pperic', 'pero@foi.hr', 'Peric123', '2b119fcc5bbeb0fd59f791089f6de69ce88f8a84', NULL, 0, 'j5qxHffM', 3, 0, 0),
(80, 'Tomislav', 'Netkić', '1998-03-31', 'ttomislav', 'romic.borna@gmail.com', 'HtqS7Ati', 'be195b2f4adc226de62cbf84b1b86ec3624f55c2', NULL, 1, '7kHaOWZa', 3, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `lokacija`
--

CREATE TABLE `lokacija` (
  `id_lokacija` int(11) NOT NULL,
  `mjesto` varchar(45) NOT NULL,
  `adresa` varchar(45) NOT NULL,
  `id_administrator` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `lokacija`
--

INSERT INTO `lokacija` (`id_lokacija`, `mjesto`, `adresa`, `id_administrator`) VALUES
(1, 'Hrvatska - Virovitica', 'Ulica Nikole Tricka', 1),
(2, 'Hrvatska - Varaždin', 'Ulica Julija Merlića', 5),
(3, 'Hrvatska - Zabok', 'Ulica Matije Gupca', 6),
(4, 'Hrvatska - Zagreb', 'Trnjanska ulica', 1),
(5, 'Hrvatska - Vir', 'Krčevine', 1),
(6, 'Hrvatska - Zadar', 'Benkovačka cesta', 5),
(7, 'Hrvatska - Split', 'Marmontova ulica', 6),
(8, 'Hrvatska - Koprivnica', 'Ulica Ivana Meštrovića', 1),
(9, 'Hrvatska - Osijek', 'Vodenička ulica', 6),
(10, 'Hrvatska - Karlovac', 'Ulica Ivanja Banjevčića', 5),
(25, 'Vukovar', 'Vukovarska ulica 13', 1);

-- --------------------------------------------------------

--
-- Table structure for table `lokacija/biciklijada`
--

CREATE TABLE `lokacija/biciklijada` (
  `id_lokacija_biciklijada` int(11) NOT NULL,
  `id_biciklijada` int(11) NOT NULL,
  `id_lokacija` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `lokacija/biciklijada`
--

INSERT INTO `lokacija/biciklijada` (`id_lokacija_biciklijada`, `id_biciklijada`, `id_lokacija`) VALUES
(6, 9, 1),
(9, 5, 2),
(10, 7, 2),
(4, 8, 3),
(8, 6, 3),
(2, 2, 6),
(3, 3, 7),
(25, 1, 7),
(7, 4, 8),
(16, 11, 9),
(5, 10, 10);

-- --------------------------------------------------------

--
-- Table structure for table `moderator/lokacija`
--

CREATE TABLE `moderator/lokacija` (
  `id_moderator_lokacija` int(11) NOT NULL,
  `id_lokacija` int(11) NOT NULL,
  `id_moderator` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `moderator/lokacija`
--

INSERT INTO `moderator/lokacija` (`id_moderator_lokacija`, `id_lokacija`, `id_moderator`) VALUES
(37, 10, 1),
(1, 1, 2),
(3, 2, 2),
(6, 4, 2),
(9, 5, 2),
(41, 25, 2),
(8, 8, 3),
(10, 3, 3),
(24, 2, 3),
(25, 7, 3),
(4, 2, 4),
(5, 6, 4),
(7, 7, 4);

-- --------------------------------------------------------

--
-- Table structure for table `odabir pobjednika`
--

CREATE TABLE `odabir pobjednika` (
  `id_pobjednik` int(11) NOT NULL,
  `opis` text,
  `id_korisnik` int(11) DEFAULT NULL,
  `id_administrator` int(11) DEFAULT NULL,
  `id_utrka` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `odabir pobjednika`
--

INSERT INTO `odabir pobjednika` (`id_pobjednik`, `opis`, `id_korisnik`, `id_administrator`, `id_utrka`) VALUES
(2, 'Pobjednik je Karlo Nenadić', 9, 1, 4),
(3, 'Pobjednik je Zvonimir Petričušić jer je Tomislav Periša uhvaćen u varanju', 10, 5, 10),
(4, 'Pobjednik je Karlo Nenadić', 9, 6, 8),
(5, 'Pobjednik je Tomislav Periša', 7, 1, 2),
(6, 'Pobjednik je Tomislav Periša', 7, 1, 6),
(7, 'Pobjednik je Karlo Nenadić', 9, 5, 3),
(8, 'Pobjednik je Zvonimir Petričušić', 10, 1, 5),
(14, 'Pobjednik je Karlo Nenadić', 9, 1, 7),
(17, 'Pobjednik je Sven Petrović', 2, 1, 9),
(22, 'Pobjednik je Karlo Nenadić!', 9, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `prijava`
--

CREATE TABLE `prijava` (
  `id_prijava` int(11) NOT NULL,
  `ime` varchar(30) NOT NULL,
  `prezime` varchar(30) NOT NULL,
  `prijava_prihvacena` tinyint(1) NOT NULL,
  `mjesto` varchar(45) NOT NULL,
  `id_korisnik` int(11) NOT NULL,
  `id_utrka` int(11) NOT NULL,
  `id_moderator` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `prijava`
--

INSERT INTO `prijava` (`id_prijava`, `ime`, `prezime`, `prijava_prihvacena`, `mjesto`, `id_korisnik`, `id_utrka`, `id_moderator`) VALUES
(1, 'Karlo', 'Nenadić', 1, 'Osijek', 9, 1, 2),
(2, 'Zvonimir', 'Petričušić', 1, 'Posušje', 10, 1, 2),
(3, 'Tomislav', 'Periša', 1, 'Virovitica', 7, 1, 2),
(5, 'Karlo', 'Nenadić', 1, 'Osijek', 9, 4, 3),
(6, 'Zvonimir', 'Petričušić', 1, 'Posušje', 10, 4, 3),
(7, 'Tomislav', 'Periša', 1, 'Virovitica', 7, 10, 3),
(8, 'Karlo', 'Nenadić', 1, 'Osijek', 9, 8, 4),
(9, 'Tomislav', 'Periša', 1, 'Virovitica', 7, 2, 2),
(11, 'Zvonimir', 'Petričušić', 1, 'Posušje', 10, 10, 3),
(12, 'Tomislav', 'Periša', 1, 'Virovitica', 7, 6, 3),
(13, 'Karlo', 'Nenadić', 1, 'Osijek', 9, 3, 2),
(14, 'Zvonimir', 'Petričušić', 1, 'Posušje', 10, 5, 2),
(15, 'Tomislav', 'Periša', 1, 'Virovitica', 7, 9, 3),
(16, 'Karlo', 'Nenadić', 1, 'Osijek', 9, 7, 2),
(29, 'Bornis', 'Bornsi', 1, 'Virovitica', 1, 3, 2),
(30, 'BornaR', 'RomicB', 1, 'Vtc', 1, 7, 2),
(34, 'Borna', 'Romić', 1, 'Virovitica', 1, 5, 2),
(35, 'Sanja', 'Romić', 1, 'Vtc', 59, 3, 2),
(45, 'Karlo', 'Nenadić', 1, 'Osijek', 9, 5, 2),
(49, 'Sven', 'Petrović', 1, 'Nizina', 2, 5, 2),
(50, 'Sven', 'Petrović', 1, 'Magla', 2, 9, 2),
(51, 'Sven', 'Petrović', 1, 'PLati', 2, 10, 2),
(52, 'Borna', 'Romić', 1, 'Virovitica', 1, 13, 2),
(62, 'Sven', 'Petrović', 0, 'Virovitica', 2, 4, 2);

-- --------------------------------------------------------

--
-- Table structure for table `prijava prihvacena`
--

CREATE TABLE `prijava prihvacena` (
  `id_prijava_prihvacena` int(11) NOT NULL,
  `potvrda_o_placanju` tinyint(1) NOT NULL,
  `racun` text NOT NULL,
  `id_prijava` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `prijava prihvacena`
--

INSERT INTO `prijava prihvacena` (`id_prijava_prihvacena`, `potvrda_o_placanju`, `racun`, `id_prijava`) VALUES
(1, 1, 'Molim vas uplatite 50 kn na racun broj \nHR 89 2484008 1102131080', 1),
(2, 1, 'Molim vas uplatite 50 kn na racun broj \nHR 89 2484008 1102131080', 2),
(3, 1, 'Molim vas uplatite 50 kn na racun broj \r\nHR 89 2484008 1102131080', 3),
(4, 1, 'Molim vas uplatite 30 kn na racun broj \r\nHR 89 2484008 1102131080', 5),
(5, 1, 'Molim vas uplatite 30 kn na racun broj \r\nHR 89 2484008 1102131080', 6),
(6, 1, 'Molim vas uplatite 20 kn na racun broj \nHR 89 2484008 1102131080', 7),
(7, 1, 'Molim vas uplatite 20 kn na racun broj \r\nHR 89 2484008 1102131080', 9),
(8, 1, 'Nije potrebna uplata za utrku', 8),
(9, 0, 'Molim vas uplatite 20 kn na racun broj HR 89 2484008 1102131080', 11),
(10, 1, 'Molim vas uplatite 20 kn na racun broj HR 89 2484008 1102131080', 12),
(11, 1, 'Molim vas uplatite 50 kn na racun broj \r\nHR 89 2484008 1102131080', 13),
(12, 1, 'Nije potrebna uplata za utrku', 14),
(13, 1, 'Nije potrebna uplata za utrku', 15),
(14, 1, 'Molim vas uplatite 50 kn na racun broj \nHR 89 2484008 1102131080', 16),
(20, 1, 'Molim vas uplatite pare', 29),
(21, 1, 'Molim vas uplatite pare', 30),
(25, 0, '', 34),
(26, 0, '', 35),
(36, 1, 'Nije potrebna uplata za utrku', 45),
(40, 1, 'Nije potrebna uplata za utrku', 49),
(41, 1, 'Nije potrebna uplata za utrku', 50),
(42, 0, 'Molim vas uplatite 20 kn na racun broj HR 89 2484008 1102131080', 51),
(43, 1, 'Molim vas uplatite 30 kn na racun broj HR 89 2484008 1102131080', 52),
(53, 0, '', 62);

-- --------------------------------------------------------

--
-- Table structure for table `rezultati utrke`
--

CREATE TABLE `rezultati utrke` (
  `id_rezultat` int(11) NOT NULL,
  `datum_i_vrijeme_zavrsetka` datetime DEFAULT NULL,
  `odustao` tinyint(4) DEFAULT '0',
  `razlog_odustajanja` text,
  `id_korisnik` int(11) NOT NULL,
  `id_utrka` int(11) NOT NULL,
  `id_moderator` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `rezultati utrke`
--

INSERT INTO `rezultati utrke` (`id_rezultat`, `datum_i_vrijeme_zavrsetka`, `odustao`, `razlog_odustajanja`, `id_korisnik`, `id_utrka`, `id_moderator`) VALUES
(1, '2019-04-30 16:00:00', 0, NULL, 9, 1, 2),
(2, '2019-04-30 17:00:00', 0, NULL, 10, 1, 2),
(3, '2019-04-30 17:09:00', 0, NULL, 7, 1, 2),
(4, '2020-04-24 10:00:00', 0, NULL, 9, 4, 3),
(5, '2020-04-24 10:11:00', 0, NULL, 10, 4, 3),
(6, '2020-04-07 10:01:00', 0, NULL, 7, 10, 3),
(7, '2020-05-02 09:00:00', 0, NULL, 9, 8, 4),
(8, '2020-03-30 10:00:00', 0, NULL, 7, 2, 2),
(10, '2020-04-07 10:00:00', 0, NULL, 7, 6, 2),
(11, '2020-04-29 15:28:00', 0, NULL, 9, 3, 2),
(12, '2020-03-30 11:12:00', 0, NULL, 10, 5, 2),
(13, '2020-04-28 07:00:00', 0, NULL, 7, 9, 3),
(14, '2020-04-17 13:00:00', 0, NULL, 9, 7, 2),
(15, '2019-06-19 00:00:00', 0, NULL, 3, 11, 2),
(50, '2021-08-12 22:00:00', 0, NULL, 1, 13, 1),
(52, '2020-03-30 11:17:00', 0, NULL, 9, 5, 9),
(59, '0000-00-00 00:00:00', 1, 'Odustao od utrke.', 2, 9, 2);

-- --------------------------------------------------------

--
-- Table structure for table `tip radnje`
--

CREATE TABLE `tip radnje` (
  `id_tip` int(11) NOT NULL,
  `naziv_radnje` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tip radnje`
--

INSERT INTO `tip radnje` (`id_tip`, `naziv_radnje`) VALUES
(1, 'prijava / odjava'),
(2, 'rad s bazom'),
(3, 'ostale radnje');

-- --------------------------------------------------------

--
-- Table structure for table `uloga`
--

CREATE TABLE `uloga` (
  `id_uloga` int(11) NOT NULL,
  `naziv` varchar(30) NOT NULL,
  `opis` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `uloga`
--

INSERT INTO `uloga` (`id_uloga`, `naziv`, `opis`) VALUES
(1, 'Administrator', 'Osoba odgovorna za provođenje funkcionalnosti ili organizacije aplikacije.'),
(2, 'Moderator', 'Osoba koja pregledava događaje radi postizanja dosljednosti, tj. nadzire odvijanje događaja.'),
(3, 'Korisnik', 'Osoba koja koristi uslugu stranice.'),
(4, 'Neprijavljen', 'Korisnik nije prijavljen u sustav');

-- --------------------------------------------------------

--
-- Table structure for table `utrka`
--

CREATE TABLE `utrka` (
  `id_utrka` int(11) NOT NULL,
  `naziv_utrke` varchar(45) NOT NULL,
  `startnina` int(11) NOT NULL,
  `broj_natjecatelja` int(11) NOT NULL,
  `vrijeme_pocetka` datetime NOT NULL,
  `id_biciklijada` int(11) NOT NULL,
  `kraj_utrke` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `utrka`
--

INSERT INTO `utrka` (`id_utrka`, `naziv_utrke`, `startnina`, `broj_natjecatelja`, `vrijeme_pocetka`, `id_biciklijada`, `kraj_utrke`) VALUES
(1, '2Fast', 50, 100, '2019-04-30 11:00:00', 5, 1),
(2, 'Hrvatska – Slovenija @ Zagreb', 20, 300, '2021-03-30 06:00:00', 9, 1),
(3, 'CRO Race', 50, 50, '2021-04-29 15:00:00', 2, 0),
(4, 'BikeHill', 30, 40, '2021-04-24 07:00:00', 6, 0),
(5, 'Nizinske trke', 0, 100, '2021-03-30 11:00:00', 9, 0),
(6, 'Week OFF', 20, 400, '2021-04-19 07:00:00', 3, 0),
(7, 'Big Race', 50, 50, '2021-04-17 11:00:00', 2, 0),
(8, 'SeaSide Cycle', 0, 300, '2021-05-02 08:00:00', 1, 1),
(9, 'Utrka u magli', 0, 30, '2020-04-28 06:00:00', 7, 0),
(10, 'VN Varaždinske županije', 20, 400, '2020-04-07 08:30:00', 7, 0),
(11, 'Najzadnja utrka', 40, 50, '2019-06-12 00:00:00', 11, 1),
(12, 'Neka', 30, 30, '2021-08-12 08:00:00', 10, 0),
(13, 'Brzina rijeke', 30, 30, '2018-08-12 08:00:00', 10, 1),
(18, 'Brzinska utrka', 50, 30, '2018-08-11 08:00:00', 11, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `biciklijada`
--
ALTER TABLE `biciklijada`
  ADD PRIMARY KEY (`id_biciklijada`),
  ADD KEY `fk_biciklijada_korisnik1_idx` (`id_administrator`);

--
-- Indexes for table `dnevnik`
--
ALTER TABLE `dnevnik`
  ADD PRIMARY KEY (`id_dnevnik`,`id_korisnik`,`id_tip`),
  ADD KEY `fk_dnevnik_korisnik1_idx` (`id_korisnik`),
  ADD KEY `fk_dnevnik_tip_radnje1_idx` (`id_tip`);

--
-- Indexes for table `korisnik`
--
ALTER TABLE `korisnik`
  ADD PRIMARY KEY (`id_korisnik`),
  ADD UNIQUE KEY `korisnicko_ime_UNIQUE` (`korisnicko_ime`),
  ADD UNIQUE KEY `e-mail_UNIQUE` (`email`),
  ADD KEY `fk_korisnik_uloga_idx` (`id_uloga`);

--
-- Indexes for table `lokacija`
--
ALTER TABLE `lokacija`
  ADD PRIMARY KEY (`id_lokacija`),
  ADD KEY `fk_lokacija_korisnik1_idx` (`id_administrator`);

--
-- Indexes for table `lokacija/biciklijada`
--
ALTER TABLE `lokacija/biciklijada`
  ADD PRIMARY KEY (`id_lokacija_biciklijada`,`id_biciklijada`,`id_lokacija`),
  ADD KEY `fk_biciklijada_has_lokacija_lokacija1_idx` (`id_lokacija`),
  ADD KEY `fk_biciklijada_has_lokacija_biciklijada1_idx` (`id_biciklijada`);

--
-- Indexes for table `moderator/lokacija`
--
ALTER TABLE `moderator/lokacija`
  ADD PRIMARY KEY (`id_moderator_lokacija`,`id_lokacija`,`id_moderator`),
  ADD KEY `fk_lokacija_has_korisnik_korisnik1_idx` (`id_moderator`),
  ADD KEY `fk_lokacija_has_korisnik_lokacija1_idx` (`id_lokacija`);

--
-- Indexes for table `odabir pobjednika`
--
ALTER TABLE `odabir pobjednika`
  ADD PRIMARY KEY (`id_pobjednik`),
  ADD KEY `fk_odabir pobjednika_korisnik1_idx` (`id_korisnik`),
  ADD KEY `fk_odabir pobjednika_korisnik2_idx` (`id_administrator`),
  ADD KEY `fk_odabir pobjednika_utrka1_idx` (`id_utrka`);

--
-- Indexes for table `prijava`
--
ALTER TABLE `prijava`
  ADD PRIMARY KEY (`id_prijava`,`id_korisnik`,`id_utrka`,`id_moderator`),
  ADD KEY `fk_prijava_korisnik1_idx` (`id_korisnik`),
  ADD KEY `fk_prijava_utrka1_idx` (`id_utrka`),
  ADD KEY `index4` (`id_moderator`);

--
-- Indexes for table `prijava prihvacena`
--
ALTER TABLE `prijava prihvacena`
  ADD PRIMARY KEY (`id_prijava_prihvacena`),
  ADD KEY `fk_prijava prihvacena_prijava1_idx` (`id_prijava`);

--
-- Indexes for table `rezultati utrke`
--
ALTER TABLE `rezultati utrke`
  ADD PRIMARY KEY (`id_rezultat`),
  ADD KEY `fk_rezultati utrke_korisnik1_idx` (`id_korisnik`),
  ADD KEY `fk_rezultati utrke_utrka1_idx` (`id_utrka`),
  ADD KEY `fk_rezultati utrke_korisnik2_idx` (`id_moderator`);

--
-- Indexes for table `tip radnje`
--
ALTER TABLE `tip radnje`
  ADD PRIMARY KEY (`id_tip`);

--
-- Indexes for table `uloga`
--
ALTER TABLE `uloga`
  ADD PRIMARY KEY (`id_uloga`),
  ADD UNIQUE KEY `naziv_UNIQUE` (`naziv`);

--
-- Indexes for table `utrka`
--
ALTER TABLE `utrka`
  ADD PRIMARY KEY (`id_utrka`),
  ADD KEY `fk_utrka_biciklijada1_idx` (`id_biciklijada`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `biciklijada`
--
ALTER TABLE `biciklijada`
  MODIFY `id_biciklijada` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `dnevnik`
--
ALTER TABLE `dnevnik`
  MODIFY `id_dnevnik` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `korisnik`
--
ALTER TABLE `korisnik`
  MODIFY `id_korisnik` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=81;
--
-- AUTO_INCREMENT for table `lokacija`
--
ALTER TABLE `lokacija`
  MODIFY `id_lokacija` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `lokacija/biciklijada`
--
ALTER TABLE `lokacija/biciklijada`
  MODIFY `id_lokacija_biciklijada` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `moderator/lokacija`
--
ALTER TABLE `moderator/lokacija`
  MODIFY `id_moderator_lokacija` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;
--
-- AUTO_INCREMENT for table `odabir pobjednika`
--
ALTER TABLE `odabir pobjednika`
  MODIFY `id_pobjednik` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `prijava`
--
ALTER TABLE `prijava`
  MODIFY `id_prijava` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;
--
-- AUTO_INCREMENT for table `prijava prihvacena`
--
ALTER TABLE `prijava prihvacena`
  MODIFY `id_prijava_prihvacena` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;
--
-- AUTO_INCREMENT for table `rezultati utrke`
--
ALTER TABLE `rezultati utrke`
  MODIFY `id_rezultat` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;
--
-- AUTO_INCREMENT for table `tip radnje`
--
ALTER TABLE `tip radnje`
  MODIFY `id_tip` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `uloga`
--
ALTER TABLE `uloga`
  MODIFY `id_uloga` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `utrka`
--
ALTER TABLE `utrka`
  MODIFY `id_utrka` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `biciklijada`
--
ALTER TABLE `biciklijada`
  ADD CONSTRAINT `fk_biciklijada_korisnik1` FOREIGN KEY (`id_administrator`) REFERENCES `korisnik` (`id_korisnik`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `dnevnik`
--
ALTER TABLE `dnevnik`
  ADD CONSTRAINT `fk_dnevnik_korisnik1` FOREIGN KEY (`id_korisnik`) REFERENCES `korisnik` (`id_korisnik`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_dnevnik_tip_radnje1` FOREIGN KEY (`id_tip`) REFERENCES `tip radnje` (`id_tip`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `korisnik`
--
ALTER TABLE `korisnik`
  ADD CONSTRAINT `fk_korisnik_uloga` FOREIGN KEY (`id_uloga`) REFERENCES `uloga` (`id_uloga`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `lokacija`
--
ALTER TABLE `lokacija`
  ADD CONSTRAINT `fk_lokacija_korisnik1` FOREIGN KEY (`id_administrator`) REFERENCES `korisnik` (`id_korisnik`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `lokacija/biciklijada`
--
ALTER TABLE `lokacija/biciklijada`
  ADD CONSTRAINT `fk_biciklijada_has_lokacija_biciklijada1` FOREIGN KEY (`id_biciklijada`) REFERENCES `biciklijada` (`id_biciklijada`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_biciklijada_has_lokacija_lokacija1` FOREIGN KEY (`id_lokacija`) REFERENCES `lokacija` (`id_lokacija`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `moderator/lokacija`
--
ALTER TABLE `moderator/lokacija`
  ADD CONSTRAINT `fk_lokacija_has_korisnik_korisnik1` FOREIGN KEY (`id_moderator`) REFERENCES `korisnik` (`id_korisnik`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_lokacija_has_korisnik_lokacija1` FOREIGN KEY (`id_lokacija`) REFERENCES `lokacija` (`id_lokacija`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `odabir pobjednika`
--
ALTER TABLE `odabir pobjednika`
  ADD CONSTRAINT `fk_odabir pobjednika_korisnik1` FOREIGN KEY (`id_korisnik`) REFERENCES `korisnik` (`id_korisnik`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_odabir pobjednika_korisnik2` FOREIGN KEY (`id_administrator`) REFERENCES `korisnik` (`id_korisnik`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_odabir pobjednika_utrka1` FOREIGN KEY (`id_utrka`) REFERENCES `utrka` (`id_utrka`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `prijava`
--
ALTER TABLE `prijava`
  ADD CONSTRAINT `fk_prijava_1` FOREIGN KEY (`id_moderator`) REFERENCES `korisnik` (`id_korisnik`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_prijava_korisnik1` FOREIGN KEY (`id_korisnik`) REFERENCES `korisnik` (`id_korisnik`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_prijava_utrka1` FOREIGN KEY (`id_utrka`) REFERENCES `utrka` (`id_utrka`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `prijava prihvacena`
--
ALTER TABLE `prijava prihvacena`
  ADD CONSTRAINT `fk_prijava prihvacena_prijava1` FOREIGN KEY (`id_prijava`) REFERENCES `prijava` (`id_prijava`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `rezultati utrke`
--
ALTER TABLE `rezultati utrke`
  ADD CONSTRAINT `fk_rezultati utrke_korisnik1` FOREIGN KEY (`id_korisnik`) REFERENCES `korisnik` (`id_korisnik`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_rezultati utrke_korisnik2` FOREIGN KEY (`id_moderator`) REFERENCES `korisnik` (`id_korisnik`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_rezultati utrke_utrka1` FOREIGN KEY (`id_utrka`) REFERENCES `utrka` (`id_utrka`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `utrka`
--
ALTER TABLE `utrka`
  ADD CONSTRAINT `fk_utrka_biciklijada1` FOREIGN KEY (`id_biciklijada`) REFERENCES `biciklijada` (`id_biciklijada`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
