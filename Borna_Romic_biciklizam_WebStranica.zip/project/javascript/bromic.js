function kreirajRegistraciju() {
    console.log("Registracija");
    formular = document.getElementById("registracija");
    greske = document.getElementById("greske");
    greskeCaptcha = document.getElementById("greskeCaptcha");
    poruka = document.getElementById("poruka");
    document.getElementById("register").disabled = true;

    captcha = document.getElementById("refresh");
    captchaSub = document.getElementById("Button1");
    document.getElementById("Button1").disabled = true;
    greske.innerHTML = " ";
    greskeCaptcha.innerHTML = " ";


    formular.addEventListener("keyup", function (event) {

        var lozinka;
        greske.innerHTML = "";

        for (i = 0; i < formular.length; i++) {
            //provjera unosa imena

            if (formular[i].id === "ime") {
                if (formular[i].value[0] === formular[i].value[0].toLowerCase()) {
                    console.log("ne valja");
                    formular[i].style = "border-color:red";
                    greske.innerHTML += "Prvo slovo imena mora biti veliko!<br>";
                } else {
                    formular[i].style = "border-color:green";

                }
            }
            //provjera unosa prezimena
            if (formular[i].id === "prezime") {
                if (formular[i].value[0] === formular[i].value[0].toLowerCase()) {
                    console.log("ne valja");
                    formular[i].style = "border-color:red";
                    greske.innerHTML += "Prvo slovo prezimena mora biti veliko!<br>";
                } else {
                    formular[i].style = "border-color:green";
                }
            }
            //provjera unosa korisničkog imena
            if (formular[i].id === "korIme") {
                if (formular[i].value.length < 5) {
                    formular[i].style = "border-color:red";
                    greske.innerHTML += "Korisničko ime mora biti duže od 4 znaka<br>";
                } else {
                    formular[i].style = "border-color:green";
                }
            }

            //provjera godine
            if (formular[i].id === "godina") {
                console.log(formular[i].value);
                if (formular[i].value === "") {
                    formular[i].style = "border-color:red";
                    greske.innerHTML += "Godina rođenja ne smije ostati prazna!<br>";
                } else {
                    formular[i].style = "border-color:green";
                }
            }
            //provjera unosa email adrese
            if (formular[i].id === "email") {
                var email = formular[i].value;
                var re = new RegExp((/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/));
                var ok = re.test(email);
                if (!ok)
                {
                    formular[i].style = "border-color:red";
                    greske.innerHTML += "Email nije dobro unesen!<br>";

                } else {
                    formular[i].style = "border-color:green";
                }
            }

            if (formular[i].id === "lozinka") {
                var lozinka = formular[i].value;
                var provjera = new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.{8,})");
                var ok = provjera.test(lozinka);
                if (!ok)
                {
                    formular[i].style = "border-color:red";
                    greske.innerHTML += "Lozinka mora imati veliko i malo slovo, broj te barem 8 znakova!<br>";

                } else {
                    formular[i].style = "border-color:green";
                    lozinka = formular[i].value;
                }
            }

            if (formular[i].id === "lozinka2") {
                if (formular[i].value !== lozinka) {
                    formular[i].style = "border-color:red";
                    greske.innerHTML += "Lozinke nisu iste!<br>";

                } else {
                    formular[i].style = "border-color:green";
                    lozinka = formular[i].value;
                }
            }

        }
        if (greske.innerHTML.length === 0 && greskeCaptcha.innerHTML.length === 0) {
            document.getElementById("register").disabled = false;
        } else
            document.getElementById("register").disabled = true;
    }, false);

    captcha.addEventListener("click", function () {
        var alpha = new Array('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z',
                'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z',
                '0', '1', '2', '3', '4', '5', '6', '7', '8', '9');
        var i;
        for (i = 0; i < 6; i++) {
            var a = alpha[Math.floor(Math.random() * alpha.length)];
            var b = alpha[Math.floor(Math.random() * alpha.length)];
            var c = alpha[Math.floor(Math.random() * alpha.length)];
            var d = alpha[Math.floor(Math.random() * alpha.length)];
            var e = alpha[Math.floor(Math.random() * alpha.length)];
            var f = alpha[Math.floor(Math.random() * alpha.length)];
            var g = alpha[Math.floor(Math.random() * alpha.length)];
        }
        var code = a + ' ' + b + ' ' + ' ' + c + ' ' + d + ' ' + e + ' ' + f + ' ' + g;
        document.getElementById("mainCaptcha").innerHTML = code;
        document.getElementById("mainCaptcha").value = code;
        document.getElementById("Button1").disabled = false;

    }, false);

    captchaSub.addEventListener("click", function () {
        greskeCaptcha.innerHTML = "";
        function removeSpaces(string) {
            return string.split(' ').join('');
        }
        var string1 = removeSpaces(document.getElementById('mainCaptcha').value);
        var string2 = removeSpaces(document.getElementById('txtInput').value);
        if (string1 === string2) {
            console.log("svaka cast");
            greskeCaptcha.innerHTML = "";
        } else {
            greskeCaptcha.innerHTML += "Captcha nije dobro unesena!<br>";
        }
        
        if (greskeCaptcha.innerHTML.length === 0 && greske.innerHTML.length === 0) {
            document.getElementById("register").disabled = false;
        } else
            document.getElementById("register").disabled = true;
    }, false);
    
}