$(document).ready(function () {
    naslov = $(document).find("title").text();



    switch (naslov) {
        case "Početna stranica":
            var dogadaji = new Array();
            $.ajax({
                url: "json/search.json",
                dataType: "json",
                success: function (data) {
                    $.each(data, function (key, val) {
                        console.log(val);
                        dogadaji.push(val);
                    });
                }
            });
            $('#pretrazi').autocomplete({
                source: dogadaji
            });
            break;

        
        case "Prijava":
            alert("prijava");

            break;

        case "Registracija":
            $('#register').click(function () {
                $("#register").prop("disabled", true);
                //var id= $('#userId').val();
                var ime = $('#ime').val();
                var prezime = $('#prezime').val();
                var korIme = $('#korIme').val();
                var godina = $('#godina').val();
                var email = $('#email').val();
                var lozinka = $('#lozinka').val();
                var lozinka2 = $('#lozinka2').val();
                var register = $("#register").val();

                $.ajax({
                    url: '../php_funkcije/registerUser.php',
                    method: 'POST',
                    data: {ime: ime, prezime: prezime, korIme: korIme, godina: godina, email: email, lozinka: lozinka, lozinka2: lozinka2, register: register},
                    success: function (response) {
                        $("#register").prop("disabled", false);
                        alert("Uspješna registracija");
                    }
                });
            });
            $('#aktiviraj').click(function () {
                var aktKod = $('#aktKod').val();
                var aktiviraj = $("#aktiviraj").val();
                $.ajax({
                    url: '../php_funkcije/registerUser.php',
                    method: 'POST',
                    data: {aktKod: aktKod, aktiviraj: aktiviraj},
                    success: function (response) {
                        alert("Uspješna aktivacija");
                    }
                });
            });
            break;
        case "Popis lokacija biciklijada":
            alert("Popis biciklijada");
            const DohvatiBiciklijade = () => {
                $.ajax({
                    url: "../php_funkcije/PopisBiciklijadaCount.php",
                    method: "POST",
                    dataType: "JSON",
                    success: (data) => {
                        let tableData = "";
                        $("#tableData").empty();
                        $.each(data, (index, value) => {
                            console.log(value);
                            tableData += "<tr id=" + value.id_biciklijada + ">";
                            tableData += "<td data-target=\"mjesto\">" + value.mjesto + "</td>";
                            tableData += "<td data-target=\"broj\">" + value.Broj_biciklijada + "</td>";
                            tableData += "<td data-target=\"broj\">" + value.Broj_utrka + "</td>";
                            tableData += "<td><a href=\"#\" data-role=\"pregled\" data-id=" + value.id_lokacija + ">Pregled</td>";
                            tableData += "</tr>";
                        });
                        $("#tableData").append(tableData);
                    }
                });
            };
            DohvatiBiciklijade();
            $(document).on('click', 'a[data-role=pregled]', function () {
                var id = $(this).data('id');
                //var mjesto = $('#' + id).children('td[data-target=mjesto]').text();
                $('#userId').val(id);
                //var id= $('#userId').val();

                $.ajax({
                    url: "../php_funkcije/PopisBiciklijadaPobjednici.php",
                    method: "POST",
                    dataType: "JSON",
                    data: {userId: id},
                    success: (data) => {
                        let tableImage = "";
                        $("#tableImage").empty();
                        $.each(data, (index, value) => {
                            console.log(value);
                            tableImage += "<tr id=" + value.id_lokacija + ">";
                            tableImage += "<td data-target=\"biciklijada\">" + value.naziv_biciklijade + "</td>";
                            tableImage += "<td data-target=\"utrka\">" + value.naziv_utrke + "</td>";
                            tableImage += "<td data-target=\"ime\">" + value.ime + "</td>";
                            tableImage += "<td data-target=\"prezime\">" + value.prezime + "</td>";
                            if (value.dozvola_slika === "1") {
                                var img = "<img src=\"" + "../multimedija/slike_korisnika/" + value.korisnicko_ime + ".png" + "\"alt=\"korisnik nije priložio sliku\" " + "width=\"" + "50" + "\" " + "height=\"" + "50" + "\"" + ">";
                                tableImage += "<td>" + img + "</td>";
                            } else {
                                var tekst = "Korisnik ne dozvoljava prikaz slike!";
                                tableImage += "<td>" + tekst + "</td>";
                            }
                            tableImage += "</tr>";
                        });
                        $("#tableImage").append(tableImage);
                    }
                });
            });
            break;
            
        case "Prijava na utrke":
            alert("Prijava na utrke");
            var today = new Date();
            var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
            alert(date);
            const DohvatiUtrke = () => {
                $.ajax({
                    url: "../php_funkcije/PopisUtrka.php",
                    method: "POST",
                    dataType: "JSON",
                    success: (data) => {
                        let tableData = "";
                        $("#tableData").empty();
                        $.each(data, (index, value) => {
                            console.log(value);
                            if (value.vrijeme_pocetka > date){
                                tableData += "<tr id=" + value.id_utrka + ">";
                                tableData += "<td data-target=\"mjesto\">" + value.mjesto + "</td>";
                                tableData += "<td data-target=\"nazivB\">" + value.naziv_biciklijade + "</td>";
                                tableData += "<td data-target=\"nazivU\">" + value.naziv_utrke + "</td>";
                                tableData += "<td data-target=\"vrijeme\">" + value.vrijeme_pocetka + "</td>";
                                tableData += "<td><a href=\"#\" data-role=\"pregled\" data-id=" + value.id_utrka + ">Odaberi</td>";
                                tableData += "</tr>";
                            }
                        });
                        $("#tableData").append(tableData);
                    }
                });
            };
            DohvatiUtrke();
            $(document).on('click', 'a[data-role=pregled]', function () {
                var id = $(this).data('id');
                var nazivU = $('#' + id).children('td[data-target=nazivU]').text();
                $('#nazivU').val(nazivU);
                $('#utrkaId').val(id);
            });
            $('#prijavi').click(function () {
                $("#prijavi").prop("disabled", true);
                var nazivU = $('#nazivU').val();
                var ime = $('#ime').val();
                var prezime = $('#prezime').val();
                var prebivaliste = $('#prebivaliste').val();
                var email = $('#email').val();
                var utrkaId = $("#utrkaId").val();
                var prijavi = $("#prijavi").val();
                

                $.ajax({
                    url: '../php_funkcije/podnesiPrijavu.php',
                    method: 'POST',
                    data: {nazivU: nazivU, ime: ime, prezime: prezime, prebivaliste: prebivaliste, email: email, utrkaId: utrkaId, prijavi: prijavi},
                    success: function () {
                        $("#prijavi").prop("disabled", false);
                        alert("Uspješno prijavljeni!");
                    }
                });
            });
            
            break;
        case "Pregled prijava":
            alert("Pregled prijava");
            var korisnik = $("#KORIME").val();
            var today = new Date();
            var date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
            var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
            var dateTime = date + ' ' + time;
            const DohvatiPrijave = () => {
                $.ajax({
                    url: "../php_funkcije/podnesenePrijave.php",
                    method: "GET",
                    dataType: "JSON",
                    data: {korime: korisnik},
                    success: (data) => {
                        let tableData = "";
                        $("#tableData").empty();
                        $.each(data, (index, value) => {
                            console.log(value);
                            if (value.vrijeme_pocetka > date) {
                                tableData += "<tr id=" + value.id_utrka + ">";
                                tableData += "<td data-target=\"nazivU\">" + value.naziv_utrke + "</td>";
                                tableData += "<td data-target=\"vrijeme\">" + value.vrijeme_pocetka + "</td>";
                                tableData += "<td data-target=\"status\">" + value.prijava_prihvacena + "</td>";
                                tableData += "<td data-target=\"prijavaId\">" + value.id_prijava + "</td>";
                                tableData += "<td data-target=\"racun\">" + value.racun + "</td>";
                                tableData += "<td data-target=\"potvrda\">" + value.potvrda_o_placanju + "</td>";
                                if (value.potvrda_o_placanju === "0") {
                                    tableData += "<td><a href=\"#\" data-role=\"plati\" data-id=" + value.id_utrka + ">Odaberi</td>";
                                }
                                tableData += "</tr>";
                            }
                        });
                        $("#tableData").append(tableData);
                    }
                });
            };
            const DohvatiPrijaveUTijeku = () => {
                $.ajax({
                    url: "../php_funkcije/podnesenePrijave.php",
                    method: "GET",
                    dataType: "JSON",
                    data: {korime: korisnik},
                    success: (data) => {
                        let tableTren = "";
                        $("#tableTren").empty();
                        $.each(data, (index, value) => {
                            console.log(value);
                            if (dateTime < value.vrijeme_zavrsetka && dateTime > value.vrijeme_pocetka) {
                                tableTren += "<tr id=" + value.id_utrka + ">";
                                tableTren += "<td data-target=\"nazivTren\">" + value.naziv_utrke + "</td>";
                                tableTren += "<td data-target=\"vrijemePTren\">" + value.vrijeme_pocetka + "</td>";
                                tableTren += "<td data-target=\"vrijemeZTren\">" + value.vrijeme_zavrsetka + "</td>";
                                tableTren += "<td data-target=\"racunTren\">" + value.potvrda_o_placanju + "</td>";
                                tableTren += "<td data-target=\"prijavaId\">" + value.id_prijava + "</td>";
                                if (value.potvrda_o_placanju === "1") {
                                    tableTren += "<td><a href=\"#\" data-role=\"odustani\" data-id=" + value.id_utrka + ">Odustani</td>";
                                }
                                tableTren += "</tr>";
                            }
                        });
                        $("#tableTren").append(tableTren);
                    }
                });
            };
            DohvatiPrijave();
            DohvatiPrijaveUTijeku();
            $(document).on('click', 'a[data-role=plati]', function () {
                //alert($(this).data('id'));
                var id = $(this).data('id');
                var nazivU = $('#' + id).children('td[data-target=nazivU]').text();
                var prijavaId = $('#' + id).children('td[data-target=prijavaId]').text();
                var status = $('#' + id).children('td[data-target=status]').text();
                if (status === "0") {
                    $("#uplati").prop("disabled", true);
                }
                else {
                    $("#uplati").prop("disabled", false);
                }

                ////alert(ime);
                //alert(godina);
                $('#utrkaId').val(id);
                $('#nazivU').val(nazivU);
                $('#prijavaId').val(prijavaId);
                //$('#myModal').modal('toggle');
                //alert(id);
                //alert(nazivU);
            });
            $(document).on('click', 'a[data-role=plati]', function () {
                //alert($(this).data('id'));
                var id = $(this).data('id');
                var nazivU = $('#' + id).children('td[data-target=nazivU]').text();
                var prijavaId = $('#' + id).children('td[data-target=prijavaId]').text();
                var status = $('#' + id).children('td[data-target=status]').text();
                if (status === "0") {
                    $("#uplati").prop("disabled", true);
                }
                else {
                    $("#uplati").prop("disabled", false);
                }

                ////alert(ime);
                //alert(godina);
                $('#utrkaId').val(id);
                $('#nazivU').val(nazivU);
                $('#prijavaId').val(prijavaId);
                //$('#myModal').modal('toggle');
                //alert(id);
                //alert(nazivU);
            });
            $(document).on('click', 'a[data-role=odustani]', function () {
                var id = $(this).data('id');
                $('#utrkaIdO').val(id);

            });
            $('#odustaniUtr').click(function () {
                var utrkaIdO = $('#utrkaIdO').val();
                var razlog = $('#razlog').val();
                var odustaniUtr = $("#odustaniUtr").val();
                var korisnik = $("#KORIME").val();
                $.ajax({
                    url: '../php_funkcije/odustajOdUtrke.php',
                    method: 'POST',
                    data: {utrkaIdO: utrkaIdO, razlog: razlog, korime: korisnik, odustaniUtr: odustaniUtr},
                    success: function (response) {
                        alert("Uspjesno");
                        DohvatiPrijaveUTijeku();
                    }
                });
            });
            $('#uplati').click(function () {
                $("#uplati").prop("disabled", true);
                var id = $('#utrkaId').val();
                var nazivU = $('#nazivU').val();
                var prijavaId = $('#prijavaId').val();
                var uplati = $("#uplati").val();
                
                /*alert(id);
                alert(nazivU);
                alert(prijavaId);
                alert(uplati);
                */
                $.ajax({
                    url: '../php_funkcije/uplataRacuna.php',
                    method: 'POST',
                    data: {prijavaId: id, nazivU: nazivU, prijavaId: prijavaId, uplati: uplati},
                    success: function (response) {
                        $("#uplati").prop("disabled", false);
                        DohvatiPrijave();
                    }
                });
            });
            $('#obrisi').click(function () {
                $("#obrisi").prop("disabled", true);
                var id = $('#utrkaId').val();
                var nazivU = $('#nazivU').val();
                var prijavaId = $('#prijavaId').val();
                var obrisi = $("#obrisi").val();
                
                /*alert(id);
                alert(nazivU);
                alert(prijavaId);
                alert(uplati);
                */
                $.ajax({
                    url: '../php_funkcije/uplataRacuna.php',
                    method: 'POST',
                    data: {utrkaId: id, nazivU: nazivU, prijavaId: prijavaId, obrisi: obrisi},
                    success: function (response) {
                        $("#obrisi").prop("disabled", false);
                        DohvatiPrijave();
                    }
                });
            });
            break;
        case "Rezultati sudjelovanih utrka":
            alert("Rezultati sudjelovanih utrka");
            var korisnik = $("#KORIME").val();
            $("#korisnikId").val(korisnik);
            const DohvatiRezultate = () => {
                $.ajax({
                    url: "../php_funkcije/rezultatiSudjelovanihUtrka.php",
                    method: "GET",
                    dataType: "JSON",
                    data: {korime: korisnik},
                    success: (data) => {
                        let tableData = "";
                        $("#tableData").empty();
                        $.each(data, (index, value) => {
                            console.log(value);
                            tableData += "<tr id=" + value.id_korisnik + ">";
                            tableData += "<td data-target=\"biciklijada\">" + value.naziv_biciklijade + "</td>";
                            tableData += "<td data-target=\"utrka\">" + value.naziv_utrke + "</td>";
                            tableData += "<td data-target=\"vrijeme\">" + value.datum_i_vrijeme_zavrsetka + "</td>";
                            tableData += "<td data-target=\"pobjednik\">" + value.id_korisnik + "</td>";
                            tableData += "</tr>";
                        });
                        $("#tableData").append(tableData);
                    }
                });
            };
            const DohvatiDozvolu = () => {
                $.ajax({
                    url: "../php_funkcije/dohvacanjeDozvole.php",
                    method: "GET",
                    dataType: "JSON",
                    data: {korime: korisnik},
                    success: (data) => {
                        $.each(data, (index, value) => {
                            console.log(value);
                            if(value.dozvola_slika === "1"){
                                $("#dozvolaS").val("dozvoljeno");
                            }
                            else{
                                $("#dozvolaS").val("nije dozvoljeno");
                            }
                        });
                    }
                });
            };
            DohvatiRezultate();
            DohvatiDozvolu();
            $('#dozvoli').click(function () {
                var korisnik = $("#korisnikId").val();
                var dozvoli = $("#dozvoli").val();
                $.ajax({
                    url: '../php_funkcije/upload_slike.php',
                    method: 'POST',
                    data: {korisnikId: korisnik, dozvoli: dozvoli},
                    success: function (response) {
                        $("#dozvolaS").val("dozvoljeno");
                    }
                });
            });
            $('#odbij').click(function () {
                var korisnik = $("#korisnikId").val();
                var odbij = $("#odbij").val();
                $.ajax({
                    url: '../php_funkcije/upload_slike.php',
                    method: 'POST',
                    data: {korisnikId: korisnik, odbij: odbij},
                    success: function (response) {
                        $("#dozvolaS").val("nije dozvoljeno");
                    }
                });
            });
            break;
        case "Kreiraj lokacije":
            alert("Kreiraj lokacije");
            const DohvatiLokacije = () => {
                $.ajax({
                    url: "../php_funkcije/dohvatiLokacije.php",
                    method: "POST",
                    dataType: "JSON",
                    success: (data) => {
                        let tableLok = "";
                        $("#tableLok").empty();
                        $.each(data, (index, value) => {
                            console.log(value);
                            tableLok += "<tr id=" + value.id_lokacija + ">";
                            tableLok += "<td data-target=\"lokacijaId\">" + value.id_lokacija + "</td>";
                            tableLok += "<td data-target=\"mjesto\">" + value.mjesto + "</td>";
                            tableLok += "<td data-target=\"adresa\">" + value.adresa + "</td>";
                            tableLok += "<td data-target=\"adminId\">" + value.id_administrator + "</td>";
                            tableLok += "<td data-target=\"brojM\">" + value.broj_moderatora + "</td>";
                            tableLok += "<td><a href=\"#\" data-role=\"odaberi\" data-id=" + value.id_lokacija + ">Odaberi</td>";
                            tableLok += "</tr>";
                        });
                        $("#tableLok").append(tableLok);
                    }
                });
            };
            DohvatiLokacije();
            $(document).on('click', 'a[data-role=odaberi]', function () {
                //alert($(this).data('id'));
                var id = $(this).data('id');
                var mjesto = $('#' + id).children('td[data-target=mjesto]').text();
                var adresa = $('#' + id).children('td[data-target=adresa]').text();
                var adminId = $('#' + id).children('td[data-target=adminId]').text();
                $('#modId').val("");
                $('#lokacijaId').val(id);
                $('#mjesto').val(mjesto);
                $('#adresa').val(adresa);
                $('#adminId').val(adminId);
                
                $('#mjestoM').val(mjesto);
                
                $.ajax({
                    url: "../php_funkcije/dohvatiModeratore.php",
                    method: "POST",
                    dataType: "JSON",
                    data: {lokacijaId: id},
                    success: (data) => {
                        let tableMod = "";
                        $("#tableMod").empty();
                        $.each(data, (index, value) => {
                            console.log(value);
                            tableMod += "<tr id=" + value.id_korisnik + ">";
                            tableMod += "<td data-target=\"id_moderator\">" + value.id_moderator + "</td>";
                            tableMod += "<td data-target=\"ime\">" + value.ime + "</td>";
                            tableMod += "<td data-target=\"prezime\">" + value.prezime + "</td>";
                            tableMod += "<td data-target=\"email\">" + value.email + "</td>";
                            tableMod += "<td data-target=\"korIme\">" + value.korisnicko_ime + "</td>";
                            tableMod += "<td><a href=\"#\" data-role=\"odaberiK\" data-id=" + value.korisnicko_ime + ">Odaberi</td>";
                            tableMod += "</tr>";
                        });
                        $("#tableMod").append(tableMod);
                    }
                });
            });
            $(document).on('click', 'a[data-role=odaberiK]', function () {
                var id = $(this).data('id');
                $('#modId').val(id);

            });
            $('#spremi').click(function () {
                $("#spremi").prop("disabled", true);
                var id = $('#lokacijaId').val();
                var korIme = $('#modId').val();
                var spremi = $("#spremi").val();

                $.ajax({
                    url: '../php_funkcije/crudModerator.php',
                    method: 'POST',
                    data: {lokacijaId:id, modId: korIme, spremi: spremi},
                    success: function (response) {
                        $("#spremi").prop("disabled", false);
                        DohvatiLokacije();
                    }
                });
                $.ajax({
                    url: "../php_funkcije/dohvatiModeratore.php",
                    method: "POST",
                    dataType: "JSON",
                    data: {lokacijaId: id},
                    success: (data) => {
                        let tableMod = "";
                        $("#tableMod").empty();
                        $.each(data, (index, value) => {
                            console.log(value);
                            tableMod += "<tr id=" + value.id_korisnik + ">";
                            tableMod += "<td data-target=\"id_moderator\">" + value.id_moderator + "</td>";
                            tableMod += "<td data-target=\"ime\">" + value.ime + "</td>";
                            tableMod += "<td data-target=\"prezime\">" + value.prezime + "</td>";
                            tableMod += "<td data-target=\"email\">" + value.email + "</td>";
                            tableMod += "<td data-target=\"korIme\">" + value.korisnicko_ime + "</td>";
                            tableMod += "<td><a href=\"#\" data-role=\"odaberiK\" data-id=" + value.korisnicko_ime + ">Odaberi</td>";
                            tableMod += "</tr>";
                        });
                        $("#tableMod").append(tableMod);
                    }
                });
            });
            $('#ukloni').click(function () {
                $("#ukloni").prop("disabled", true);
                var id = $('#lokacijaId').val();
                var korIme = $('#modId').val();
                var ukloni = $("#ukloni").val();

                $.ajax({
                    url: '../php_funkcije/crudModerator.php',
                    method: 'POST',
                    data: {lokacijaId: id, modId: korIme, ukloni: ukloni},
                    success: function (response) {
                        $("#ukloni").prop("disabled", false);
                        DohvatiLokacije();
                    }
                });
                $.ajax({
                    url: "../php_funkcije/dohvatiModeratore.php",
                    method: "POST",
                    dataType: "JSON",
                    data: {lokacijaId: id},
                    success: (data) => {
                        let tableMod = "";
                        $("#tableMod").empty();
                        $.each(data, (index, value) => {
                            console.log(value);
                            tableMod += "<tr id=" + value.id_korisnik + ">";
                            tableMod += "<td data-target=\"id_moderator\">" + value.id_moderator + "</td>";
                            tableMod += "<td data-target=\"ime\">" + value.ime + "</td>";
                            tableMod += "<td data-target=\"prezime\">" + value.prezime + "</td>";
                            tableMod += "<td data-target=\"email\">" + value.email + "</td>";
                            tableMod += "<td data-target=\"korIme\">" + value.korisnicko_ime + "</td>";
                            tableMod += "<td><a href=\"#\" data-role=\"odaberiK\" data-id=" + value.korisnicko_ime + ">Odaberi</td>";
                            tableMod += "</tr>";
                        });
                        $("#tableMod").append(tableMod);
                    }
                });
            });
            $('#save').click(function () {
                $("#save").prop("disabled", true);
                var id = $('#lokacijaId').val();
                var mjesto = $('#mjesto').val();
                var adresa = $('#adresa').val();
                var adminId = $('#adminId').val();
                var save = $("#save").val();

                $.ajax({
                    url: '../php_funkcije/crudLokacije.php',
                    method: 'POST',
                    data: {lokacijaId:id, mjesto:mjesto, adresa:adresa, adminId:adminId, save: save},
                    success: function (response) {
                        $("#save").prop("disabled", false);
                        DohvatiLokacije();
                    }
                });
            });
            $('#register').click(function () {
                $("#register").prop("disabled", true);
                var id = $('#lokacijaId').val();
                var mjesto = $('#mjesto').val();
                var adresa = $('#adresa').val();
                var adminId = $('#adminId').val();
                var register = $("#register").val();

                $.ajax({
                    url: '../php_funkcije/crudLokacije.php',
                    method: 'POST',
                    data: {lokacijaId:id, mjesto:mjesto, adresa:adresa, adminId:adminId, register: register},
                    success: function (response) {
                        $("#register").prop("disabled", false);
                        DohvatiLokacije();
                    }
                });
            });
            $('#obrisi').click(function () {
                $("#obrisi").prop("disabled", true);
                var id = $('#lokacijaId').val();
                var obrisi = $("#obrisi").val();

                $.ajax({
                    url: '../php_funkcije/crudLokacije.php',
                    method: 'POST',
                    data: {lokacijaId:id, obrisi: obrisi},
                    success: function (response) {
                        $("#obrisi").prop("disabled", false);
                        DohvatiLokacije();
                    }
                });
            });
            break;
        case "Kreiraj događaje":
            alert("Kreiraj događaje");
            const PopisBiciklijada = () => {
                $.ajax({
                    url: "../php_funkcije/dohvatiBiciklijade.php",
                    method: "POST",
                    dataType: "JSON",
                    success: (data) => {
                        let tableBic = "";
                        $("#tableBic").empty();
                        $.each(data, (index, value) => {
                            console.log(value);
                            tableBic += "<tr id=" + value.id_biciklijada + ">";
                            tableBic += "<td data-target=\"biciklijadaId\">" + value.id_biciklijada + "</td>";
                            tableBic += "<td data-target=\"naziv\">" + value.naziv_biciklijade + "</td>";
                            tableBic += "<td data-target=\"vrijemePoc\">" + value.vrijeme_pocetka + "</td>";
                            tableBic += "<td data-target=\"vrijemeZ\">" + value.vrijeme_zavrsetka + "</td>";
                            tableBic += "<td data-target=\"brojU\">" + value.broj_utrka + "</td>";
                            tableBic += "<td data-target=\"adminId\">" + value.id_administrator + "</td>";
                            tableBic += "<td><a href=\"#\" data-role=\"odaberi\" data-id=" + value.id_biciklijada + ">Odaberi</td>";
                            tableBic += "</tr>";
                        });
                        $("#tableBic").append(tableBic);
                    }
                });
            };
            PopisBiciklijada();
            $(document).on('click', 'a[data-role=odaberi]', function () {
                //alert($(this).data('id'));
                var id = $(this).data('id');
                var nazivBic = $('#' + id).children('td[data-target=naziv]').text();
                var vrijemePoc = $('#' + id).children('td[data-target=vrijemePoc]').text();
                var vrijemeZav = $('#' + id).children('td[data-target=vrijemeZ]').text();
                var adminId = $('#' + id).children('td[data-target=adminId]').text();

                $('#biciklijadaId').val(id);
                $('#nazivBic').val(nazivBic);
                $('#biciklijadaN').val(nazivBic);
                $('#vrijemePoc').val(vrijemePoc);
                $('#vrijemeZav').val(vrijemeZav);
                $('#adminId').val(adminId);
                
                
                $.ajax({
                    url: "../php_funkcije/dohvatiUtrke.php",
                    method: "POST",
                    dataType: "JSON",
                    data: {biciklijadaId: id},
                    success: (data) => {
                        let tableUtr = "";
                        $("#tableUtr").empty();
                        $.each(data, (index, value) => {
                            console.log(value);
                            tableUtr += "<tr id=" + value.id_utrka + ">";
                            tableUtr += "<td data-target=\"utrkaId\">" + value.id_utrka + "</td>";
                            tableUtr += "<td data-target=\"nazivU\">" + value.naziv_utrke + "</td>";
                            tableUtr += "<td data-target=\"vrijemeP\">" + value.vrijeme_pocetka + "</td>";
                            tableUtr += "<td data-target=\"brojN\">" + value.broj_natjecatelja + "</td>";
                            tableUtr += "<td data-target=\"startnina\">" + value.startnina + "</td>";
                            tableUtr += "<td><a href=\"#\" data-role=\"odaberiK\" data-id=" + value.id_utrka + ">Odaberi</td>";
                            tableUtr += "</tr>";
                        });
                        $("#tableUtr").append(tableUtr);
                    }
                });
            });
            $(document).on('click', 'a[data-role=odaberiK]', function () {
                var id = $(this).data('id');
                $('#utrkaId').val(id);
            });
            $('#save').click(function () {
                $("#save").prop("disabled", true);
                var id = $("#biciklijadaId").val();
                var nazivBic = $("#nazivBic").val();
                var vrijemePoc = $("#vrijemePoc").val();
                var vrijemeZav = $("#vrijemeZav").val();

                var save = $("#save").val();

                $.ajax({
                    url: '../php_funkcije/crudBiciklijade.php',
                    method: 'POST',
                    data: {biciklijadaId: id, nazivBic: nazivBic, vrijemePoc: vrijemePoc, vrijemeZav: vrijemeZav, save: save},
                    success: function (response) {
                        $("#save").prop("disabled", false);
                        PopisBiciklijada();
                    }
                });
                
            });
            $('#register').click(function () {
                $("#register").prop("disabled", true);
                var nazivBic = $("#nazivBic").val();
                var vrijemePoc = $("#vrijemePoc").val();
                var vrijemeZav = $("#vrijemeZav").val();
                
                
                var register = $("#register").val();
                
                $.ajax({
                    url: '../php_funkcije/crudBiciklijade.php',
                    method: 'POST',
                    data: {nazivBic: nazivBic, vrijemePoc: vrijemePoc, vrijemeZav: vrijemeZav, register: register},
                    success: function (response) {
                        $("#register").prop("disabled", false);
                        PopisBiciklijada();
                    }
                });
            });
            $('#obrisi').click(function () {
                $("#obrisi").prop("disabled", true);
                var id = $("#biciklijadaId").val();
                var obrisi = $("#obrisi").val();

                $.ajax({
                    url: '../php_funkcije/crudBiciklijade.php',
                    method: 'POST',
                    data: {biciklijadaId:id, obrisi: obrisi},
                    success: function (response) {
                        $("#obrisi").prop("disabled", false);
                        PopisBiciklijada();
                    }
                });
            });
            $('#spremi').click(function () {
                $("#spremi").prop("disabled", true);
                var id = $('#biciklijadaId').val();
                var nazivUtr = $('#nazivUtr').val();
                var utrkaPoc = $('#utrkaPoc').val();
                var utrkaBroj = $('#utrkaBroj').val();
                var utrkaStart = $('#utrkaStart').val();

                var spremi = $("#spremi").val();

                $.ajax({
                    url: '../php_funkcije/crudUtrke.php',
                    method: 'POST',
                    data: {biciklijadaId:id, nazivUtr: nazivUtr, utrkaPoc: utrkaPoc, utrkaBroj: utrkaBroj, utrkaStart: utrkaStart, spremi: spremi},
                    success: function (response) {
                        $("#spremi").prop("disabled", false);
                        PopisBiciklijada();
                    }
                });
                $.ajax({
                    url: "../php_funkcije/dohvatiUtrke.php",
                    method: "POST",
                    dataType: "JSON",
                    data: {biciklijadaId: id},
                    success: (data) => {
                        let tableUtr = "";
                        $("#tableUtr").empty();
                        $.each(data, (index, value) => {
                            console.log(value);
                            tableUtr += "<tr id=" + value.id_utrka + ">";
                            tableUtr += "<td data-target=\"utrkaId\">" + value.id_utrka + "</td>";
                            tableUtr += "<td data-target=\"nazivU\">" + value.naziv_utrke + "</td>";
                            tableUtr += "<td data-target=\"vrijemeP\">" + value.vrijeme_pocetka + "</td>";
                            tableUtr += "<td data-target=\"brojN\">" + value.broj_natjecatelja + "</td>";
                            tableUtr += "<td data-target=\"startnina\">" + value.startnina + "</td>";
                            tableUtr += "<td><a href=\"#\" data-role=\"odaberiK\" data-id=" + value.id_utrka + ">Odaberi</td>";
                            tableUtr += "</tr>";
                        });
                        $("#tableUtr").append(tableUtr);
                    }
                });
            });
            $('#ukloni').click(function () {
                $("#ukloni").prop("disabled", true);
                var id = $('#utrkaId').val();
                var idBic = $('#biciklijadaId').val();
                var ukloni = $("#ukloni").val();
                $.ajax({
                    url: '../php_funkcije/crudUtrke.php',
                    method: 'POST',
                    data: {utrkaId: id, biciklijadaId: idBic, ukloni: ukloni},
                    success: function (response) {
                        $("#ukloni").prop("disabled", false);
                        PopisBiciklijada();
                    }
                });
                $.ajax({
                    url: "../php_funkcije/dohvatiUtrke.php",
                    method: "POST",
                    dataType: "JSON",
                    data: {biciklijadaId: idBic},
                    success: (data) => {
                        let tableUtr = "";
                        $("#tableUtr").empty();
                        $.each(data, (index, value) => {
                            console.log(value);
                            tableUtr += "<tr id=" + value.id_utrka + ">";
                            tableUtr += "<td data-target=\"utrkaId\">" + value.id_utrka + "</td>";
                            tableUtr += "<td data-target=\"nazivU\">" + value.naziv_utrke + "</td>";
                            tableUtr += "<td data-target=\"vrijemeP\">" + value.vrijeme_pocetka + "</td>";
                            tableUtr += "<td data-target=\"brojN\">" + value.broj_natjecatelja + "</td>";
                            tableUtr += "<td data-target=\"startnina\">" + value.startnina + "</td>";
                            tableUtr += "<td><a href=\"#\" data-role=\"odaberiK\" data-id=" + value.id_utrka + ">Odaberi</td>";
                            tableUtr += "</tr>";
                        });
                        $("#tableUtr").append(tableUtr);
                    }
                });
            });
            $('#azuriraj').click(function () {
                $("#azuriraj").prop("disabled", true);
                var id = $('#utrkaId').val();
                var nazivUtr = $('#nazivUtr').val();
                var utrkaPoc = $('#utrkaPoc').val();
                var utrkaBroj = $('#utrkaBroj').val();
                var utrkaStart = $('#utrkaStart').val();
                var idBic = $('#biciklijadaId').val();

                var azuriraj = $("#azuriraj").val();
                $.ajax({
                    url: '../php_funkcije/crudUtrke.php',
                    method: 'POST',
                    data: {utrkaId: id, biciklijadaId: idBic, nazivUtr: nazivUtr, utrkaPoc: utrkaPoc, utrkaBroj: utrkaBroj, utrkaStart: utrkaStart ,azuriraj: azuriraj},
                    success: function (response) {
                        $("#azuriraj").prop("disabled", false);
                        PopisBiciklijada();
                    }
                });
                $.ajax({
                    url: "../php_funkcije/dohvatiUtrke.php",
                    method: "POST",
                    dataType: "JSON",
                    data: {biciklijadaId: idBic},
                    success: (data) => {
                        let tableUtr = "";
                        $("#tableUtr").empty();
                        $.each(data, (index, value) => {
                            console.log(value);
                            tableUtr += "<tr id=" + value.id_utrka + ">";
                            tableUtr += "<td data-target=\"utrkaId\">" + value.id_utrka + "</td>";
                            tableUtr += "<td data-target=\"nazivU\">" + value.naziv_utrke + "</td>";
                            tableUtr += "<td data-target=\"vrijemeP\">" + value.vrijeme_pocetka + "</td>";
                            tableUtr += "<td data-target=\"brojN\">" + value.broj_natjecatelja + "</td>";
                            tableUtr += "<td data-target=\"startnina\">" + value.startnina + "</td>";
                            tableUtr += "<td><a href=\"#\" data-role=\"odaberiK\" data-id=" + value.id_utrka + ">Odaberi</td>";
                            tableUtr += "</tr>";
                        });
                        $("#tableUtr").append(tableUtr);
                    }
                });
            });
            break;
        case "Dodijela biciklijade lokaciji":
            alert("Dodijela biciklijade lokaciji");
            const DohvatiLokacijeBic = () => {
                $.ajax({
                    url: "../php_funkcije/dohvatiLokacijeBic.php",
                    method: "POST",
                    dataType: "JSON",
                    success: (data) => {
                        let tableLok = "";
                        $("#tableLok").empty();
                        $.each(data, (index, value) => {
                            console.log(value);
                            tableLok += "<tr id=" + value.id_lokacija + ">";
                            tableLok += "<td data-target=\"lokacijaId\">" + value.id_lokacija + "</td>";
                            tableLok += "<td data-target=\"mjesto\">" + value.mjesto + "</td>";
                            tableLok += "<td data-target=\"adresa\">" + value.adresa + "</td>";
                            tableLok += "<td data-target=\"brojB\">" + value.broj_biciklijada + "</td>";
                            tableLok += "<td><a href=\"#\" data-role=\"odaberi\" data-id=" + value.id_lokacija + ">Odaberi</td>";
                            tableLok += "</tr>";
                        });
                        $("#tableLok").append(tableLok);
                    }
                });
            };
            DohvatiLokacijeBic();
            $(document).on('click', 'a[data-role=odaberi]', function () {
                //alert($(this).data('id'));
                var id = $(this).data('id');
                var mjesto = $('#' + id).children('td[data-target=mjesto]').text();

                $('#lokacijaId').val(id);
                $('#mjesto').val(mjesto);

                $.ajax({
                    url: "../php_funkcije/dohvatiBiciklijadeLok.php",
                    method: "POST",
                    dataType: "JSON",
                    data: {lokacijaId: id},
                    success: (data) => {
                        let tableBic = "";
                        $("#tableBic").empty();
                        $.each(data, (index, value) => {
                            console.log(value);
                            tableBic += "<tr id=" + value.id_biciklijada + ">";
                            tableBic += "<td data-target=\"biciklijadaId\">" + value.id_biciklijada + "</td>";
                            tableBic += "<td data-target=\"nazivBic\">" + value.naziv_biciklijade + "</td>";
                            tableBic += "<td data-target=\"vrijemePoc\">" + value.vrijeme_pocetka + "</td>";
                            tableBic += "<td data-target=\"vrijemeZav\">" + value.vrijeme_zavrsetka + "</td>";
                            tableBic += "<td><a href=\"#\" data-role=\"odaberiK\" data-id=" + value.id_biciklijada + ">Odaberi</td>";
                            tableBic += "</tr>";
                        });
                        $("#tableBic").append(tableBic);
                    }
                });
            });
            $(document).on('click', 'a[data-role=odaberiK]', function () {
                var id = $(this).data('id');
                $('#biciklijadaId').val(id);
            });
            $('#spremi').click(function () {
                $("#spremi").prop("disabled", true);
                var nazivBic = $('#nazivBic').val();
                var lokacijaId = $('#lokacijaId').val();
                var spremi = $("#spremi").val();
                
                $.ajax({
                    url: '../php_funkcije/crudLokBic.php',
                    method: 'POST',
                    data: {nazivBic: nazivBic, lokacijaId: lokacijaId, spremi: spremi},
                    success: function (response) {
                        $("#spremi").prop("disabled", false);
                        DohvatiLokacijeBic();
                    }
                });
                $.ajax({
                    url: "../php_funkcije/dohvatiBiciklijadeLok.php",
                    method: "POST",
                    dataType: "JSON",
                    data: {lokacijaId: lokacijaId},
                    success: (data) => {
                        let tableBic = "";
                        $("#tableBic").empty();
                        $.each(data, (index, value) => {
                            console.log(value);
                            tableBic += "<tr id=" + value.id_biciklijada + ">";
                            tableBic += "<td data-target=\"biciklijadaId\">" + value.id_biciklijada + "</td>";
                            tableBic += "<td data-target=\"nazivBic\">" + value.naziv_biciklijade + "</td>";
                            tableBic += "<td data-target=\"vrijemePoc\">" + value.vrijeme_pocetka + "</td>";
                            tableBic += "<td data-target=\"vrijemeZav\">" + value.vrijeme_zavrsetka + "</td>";
                            tableBic += "<td><a href=\"#\" data-role=\"odaberiK\" data-id=" + value.id_biciklijada + ">Odaberi</td>";
                            tableBic += "</tr>";
                        });
                        $("#tableBic").append(tableBic);
                    }
                });
            });
            $('#ukloni').click(function () {
                $("#ukloni").prop("disabled", true);
                var id = $('#biciklijadaId').val();
                var ukloni = $("#ukloni").val();
                var lokacijaId = $('#lokacijaId').val();

                $.ajax({
                    url: '../php_funkcije/crudLokBic.php',
                    method: 'POST',
                    data: {biciklijadaId: id, ukloni: ukloni},
                    success: function (response) {
                        $("#ukloni").prop("disabled", false);
                        DohvatiLokacijeBic();
                    }
                });
                $.ajax({
                    url: "../php_funkcije/dohvatiBiciklijadeLok.php",
                    method: "POST",
                    dataType: "JSON",
                    data: {lokacijaId: lokacijaId},
                    success: (data) => {
                        let tableBic = "";
                        $("#tableBic").empty();
                        $.each(data, (index, value) => {
                            console.log(value);
                            tableBic += "<tr id=" + value.id_biciklijada + ">";
                            tableBic += "<td data-target=\"biciklijadaId\">" + value.id_biciklijada + "</td>";
                            tableBic += "<td data-target=\"nazivBic\">" + value.naziv_biciklijade + "</td>";
                            tableBic += "<td data-target=\"vrijemePoc\">" + value.vrijeme_pocetka + "</td>";
                            tableBic += "<td data-target=\"vrijemeZav\">" + value.vrijeme_zavrsetka + "</td>";
                            tableBic += "<td><a href=\"#\" data-role=\"odaberiK\" data-id=" + value.id_biciklijada + ">Odaberi</td>";
                            tableBic += "</tr>";
                        });
                        $("#tableBic").append(tableBic);
                    }
                });
            });
            break;
        case "Odabir pobjednika utrke":
            var today = new Date();
            var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
            const DohvatiGotoveUtrke = () => {
                $.ajax({
                    url: "../php_funkcije/dohvatiGotoveUtrke.php",
                    method: "POST",
                    dataType: "JSON",
                    success: (data) => {
                        let tableUt = "";
                        $("#tableUt").empty();
                        $.each(data, (index, value) => {
                            if (value.vrijeme_zavrsetka < date && value.broj_pobjednika === "0" && value.kraj_utrke === "1") {
                                console.log(value);
                                tableUt += "<tr id=" + value.id_utrka + ">";
                                tableUt += "<td data-target=\"utkraId\">" + value.id_utrka + "</td>";
                                tableUt += "<td data-target=\"nazivUtr\">" + value.naziv_utrke + "</td>";
                                tableUt += "<td data-target=\"vrijemeZav\">" + value.vrijeme_zavrsetka + "</td>";
                                tableUt += "<td><a href=\"#\" data-role=\"odaberi\" data-id=" + value.id_utrka + ">Odaberi</td>";
                                tableUt += "</tr>";
                            }
                        });
                        $("#tableUt").append(tableUt);
                    }
                });
            };
            DohvatiGotoveUtrke();
            $(document).on('click', 'a[data-role=odaberi]', function () {
                //alert($(this).data('id'));
                var id = $(this).data('id');
                var today = new Date();
                var date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
                var korisnik;
                $('#utrkaId').val(id);
                $.ajax({
                    url: "../php_funkcije/dohvatiRezultateUtrke.php",
                    method: "POST",
                    dataType: "JSON",
                    data: {utrkaId: id},
                    success: (data) => {
                        let tableRez = "";
                        $("#tableRez").empty();
                        $.each(data, (index, value) => {
                            if(date > value.datum_i_vrijeme_zavrsetka){
                                date = value.datum_i_vrijeme_zavrsetka;
                                korisnik = value.id_korisnik;
                            }
                            console.log(value);
                            tableRez += "<tr id=" + value.id_korisnik + ">";
                            tableRez += "<td data-target=\"ime\">" + value.ime + "</td>";
                            tableRez += "<td data-target=\"prezime\">" + value.prezime + "</td>";
                            tableRez += "<td data-target=\"korIme\">" + value.korisnicko_ime + "</td>";
                            tableRez += "<td data-target=\"vrijemeZ\">" + value.datum_i_vrijeme_zavrsetka + "</td>";
                            tableRez += "<td><a href=\"#\" data-role=\"odaberiK\" data-id=" + value.id_korisnik + ">Odaberi</td>";
                            tableRez += "</tr>";
                        });
                        $("#tableRez").append(tableRez);
                        $('#korisnikId').val(korisnik);
                    }
                });
            });
            $(document).on('click', 'a[data-role=odaberiK]', function () {
                var id = $(this).data('id');
                $('#korisnikId').val(id);
            });
            $('#spremi').click(function () {
                $("#spremi").prop("disabled", true);
                var utrkaId = $('#utrkaId').val();
                var korisnikId = $('#korisnikId').val();
                var textVeliki = $('#textVeliki').val();
                var spremi = $("#spremi").val();
                
                $.ajax({
                    url: '../php_funkcije/odabirPobjednikaUtrke.php',
                    method: 'POST',
                    data: {utrkaId: utrkaId, korisnikId: korisnikId, textVeliki: textVeliki, spremi: spremi},
                    success: function (response) {
                        alert("uspjesno");
                        $("#spremi").prop("disabled", false);
                        DohvatiGotoveUtrke();
                    }
                });
            });
            break;
        case "Planirane utrke":
            alert("Planirane utrke");
            var today = new Date();
            var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
            const DohvatiPlanUtrke = () => {
                $.ajax({
                    url: "../php_funkcije/dohvatiPlaniraneUtrke.php",
                    method: "POST",
                    dataType: "JSON",
                    success: (data) => {
                        let tableData = "";
                        $("#tableData").empty();
                        $.each(data, (index, value) => {
                            console.log(value);
                            if(value.vrijeme_pocetka > date){
                            tableData += "<tr id=" + value.id_utrka + ">";
                            tableData += "<td data-target=\"nazivU\">" + value.naziv_utrke + "</td>";
                            tableData += "<td data-target=\"datumPoc\">" + value.vrijeme_pocetka + "</td>";
                            tableData += "<td data-target=\"nazivBic\">" + value.naziv_biciklijade + "</td>";
                            tableData += "<td data-target=\"mjesto\">" + value.mjesto + "</td>";
                            tableData += "<td data-target=\"brojNat\">" + value.broj_natjecatelja + "</td>";
                            tableData += "</tr>";
                        }
                        });
                        $("#tableData").append(tableData);
                    }
                });
            };
            DohvatiPlanUtrke();
            $('#filter').click(function () {
                var nazivLokacije = $('#nazivLokacije').val();

                $.ajax({
                    url: '../php_funkcije/dohvatiPlaniraneUtrke.php',
                    method: 'POST',
                    dataType: "JSON",
                    //data: {nazivLokacije: nazivLokacije, filter: filter},
                    success: (data) => {
                        let tableData = "";
                        $("#tableData").empty();
                        $.each(data, (index, value) => {
                            console.log(value);
                            if (value.vrijeme_pocetka > date && nazivLokacije === "") {
                                tableData += "<tr id=" + value.id_utrka + ">";
                                tableData += "<td data-target=\"nazivU\">" + value.naziv_utrke + "</td>";
                                tableData += "<td data-target=\"datumPoc\">" + value.vrijeme_pocetka + "</td>";
                                tableData += "<td data-target=\"nazivBic\">" + value.naziv_biciklijade + "</td>";
                                tableData += "<td data-target=\"mjesto\">" + value.mjesto + "</td>";
                                tableData += "<td data-target=\"brojNat\">" + value.broj_natjecatelja + "</td>";
                                tableData += "</tr>";
                            }
                            if (value.vrijeme_pocetka > date && value.mjesto === nazivLokacije) {
                                tableData += "<tr id=" + value.id_utrka + ">";
                                tableData += "<td data-target=\"nazivU\">" + value.naziv_utrke + "</td>";
                                tableData += "<td data-target=\"datumPoc\">" + value.vrijeme_pocetka + "</td>";
                                tableData += "<td data-target=\"nazivBic\">" + value.naziv_biciklijade + "</td>";
                                tableData += "<td data-target=\"mjesto\">" + value.mjesto + "</td>";
                                tableData += "<td data-target=\"brojNat\">" + value.broj_natjecatelja + "</td>";
                                tableData += "</tr>";
                            }
                        });
                        $("#tableData").append(tableData);
                    }
                });
            });
            $('#sortDU').click(function () {
                var nazivLokacije = $('#nazivLokacije').val();
                var sortDU = $("#sortDU").val();
                $.ajax({
                    url: '../php_funkcije/dohvatiPlaniraneUtrkeSort.php',
                    method: 'POST',
                    dataType: "JSON",
                    data: {sortDU: sortDU},
                    success: (data) => {
                        let tableData = "";
                        $("#tableData").empty();
                        $.each(data, (index, value) => {
                            console.log(value);
                            if (value.vrijeme_pocetka > date && nazivLokacije === "") {
                                tableData += "<tr id=" + value.id_utrka + ">";
                                tableData += "<td data-target=\"nazivU\">" + value.naziv_utrke + "</td>";
                                tableData += "<td data-target=\"datumPoc\">" + value.vrijeme_pocetka + "</td>";
                                tableData += "<td data-target=\"nazivBic\">" + value.naziv_biciklijade + "</td>";
                                tableData += "<td data-target=\"mjesto\">" + value.mjesto + "</td>";
                                tableData += "<td data-target=\"brojNat\">" + value.broj_natjecatelja + "</td>";
                                tableData += "</tr>";
                            }
                            if (value.vrijeme_pocetka > date && value.mjesto === nazivLokacije) {
                                tableData += "<tr id=" + value.id_utrka + ">";
                                tableData += "<td data-target=\"nazivU\">" + value.naziv_utrke + "</td>";
                                tableData += "<td data-target=\"datumPoc\">" + value.vrijeme_pocetka + "</td>";
                                tableData += "<td data-target=\"nazivBic\">" + value.naziv_biciklijade + "</td>";
                                tableData += "<td data-target=\"mjesto\">" + value.mjesto + "</td>";
                                tableData += "<td data-target=\"brojNat\">" + value.broj_natjecatelja + "</td>";
                                tableData += "</tr>";
                            }
                        });
                        $("#tableData").append(tableData);
                    }
                });
            });
            $('#sortDS').click(function () {
                var nazivLokacije = $('#nazivLokacije').val();
                var sortDS = $("#sortDS").val();
                $.ajax({
                    url: '../php_funkcije/dohvatiPlaniraneUtrkeSort.php',
                    method: 'POST',
                    dataType: "JSON",
                    data: {sortDS: sortDS},
                    success: (data) => {
                        let tableData = "";
                        $("#tableData").empty();
                        $.each(data, (index, value) => {
                            console.log(value);
                            if (value.vrijeme_pocetka > date && nazivLokacije === "") {
                                tableData += "<tr id=" + value.id_utrka + ">";
                                tableData += "<td data-target=\"nazivU\">" + value.naziv_utrke + "</td>";
                                tableData += "<td data-target=\"datumPoc\">" + value.vrijeme_pocetka + "</td>";
                                tableData += "<td data-target=\"nazivBic\">" + value.naziv_biciklijade + "</td>";
                                tableData += "<td data-target=\"mjesto\">" + value.mjesto + "</td>";
                                tableData += "<td data-target=\"brojNat\">" + value.broj_natjecatelja + "</td>";
                                tableData += "</tr>";
                            }
                            if (value.vrijeme_pocetka > date && value.mjesto === nazivLokacije) {
                                tableData += "<tr id=" + value.id_utrka + ">";
                                tableData += "<td data-target=\"nazivU\">" + value.naziv_utrke + "</td>";
                                tableData += "<td data-target=\"datumPoc\">" + value.vrijeme_pocetka + "</td>";
                                tableData += "<td data-target=\"nazivBic\">" + value.naziv_biciklijade + "</td>";
                                tableData += "<td data-target=\"mjesto\">" + value.mjesto + "</td>";
                                tableData += "<td data-target=\"brojNat\">" + value.broj_natjecatelja + "</td>";
                                tableData += "</tr>";
                            }
                        });
                        $("#tableData").append(tableData);
                    }
                });
            });
            $('#sortBU').click(function () {
                var nazivLokacije = $('#nazivLokacije').val();
                var sortBU = $("#sortBU").val();
                $.ajax({
                    url: '../php_funkcije/dohvatiPlaniraneUtrkeSort.php',
                    method: 'POST',
                    dataType: "JSON",
                    data: {sortBU: sortBU},
                    success: (data) => {
                        let tableData = "";
                        $("#tableData").empty();
                        $.each(data, (index, value) => {
                            console.log(value);
                            if (value.vrijeme_pocetka > date && nazivLokacije === "") {
                                tableData += "<tr id=" + value.id_utrka + ">";
                                tableData += "<td data-target=\"nazivU\">" + value.naziv_utrke + "</td>";
                                tableData += "<td data-target=\"datumPoc\">" + value.vrijeme_pocetka + "</td>";
                                tableData += "<td data-target=\"nazivBic\">" + value.naziv_biciklijade + "</td>";
                                tableData += "<td data-target=\"mjesto\">" + value.mjesto + "</td>";
                                tableData += "<td data-target=\"brojNat\">" + value.broj_natjecatelja + "</td>";
                                tableData += "</tr>";
                            }
                            if (value.vrijeme_pocetka > date && value.mjesto === nazivLokacije) {
                                tableData += "<tr id=" + value.id_utrka + ">";
                                tableData += "<td data-target=\"nazivU\">" + value.naziv_utrke + "</td>";
                                tableData += "<td data-target=\"datumPoc\">" + value.vrijeme_pocetka + "</td>";
                                tableData += "<td data-target=\"nazivBic\">" + value.naziv_biciklijade + "</td>";
                                tableData += "<td data-target=\"mjesto\">" + value.mjesto + "</td>";
                                tableData += "<td data-target=\"brojNat\">" + value.broj_natjecatelja + "</td>";
                                tableData += "</tr>";
                            }
                        });
                        $("#tableData").append(tableData);
                    }
                });
            });
            $('#sortBS').click(function () {
                var nazivLokacije = $('#nazivLokacije').val();
                var sortBS = $("#sortBS").val();
                $.ajax({
                    url: '../php_funkcije/dohvatiPlaniraneUtrkeSort.php',
                    method: 'POST',
                    dataType: "JSON",
                    data: {sortBS: sortBS},
                    success: (data) => {
                        let tableData = "";
                        $("#tableData").empty();
                        $.each(data, (index, value) => {
                            console.log(value);
                            if (value.vrijeme_pocetka > date && nazivLokacije === "") {
                                tableData += "<tr id=" + value.id_utrka + ">";
                                tableData += "<td data-target=\"nazivU\">" + value.naziv_utrke + "</td>";
                                tableData += "<td data-target=\"datumPoc\">" + value.vrijeme_pocetka + "</td>";
                                tableData += "<td data-target=\"nazivBic\">" + value.naziv_biciklijade + "</td>";
                                tableData += "<td data-target=\"mjesto\">" + value.mjesto + "</td>";
                                tableData += "<td data-target=\"brojNat\">" + value.broj_natjecatelja + "</td>";
                                tableData += "</tr>";
                            }
                            if (value.vrijeme_pocetka > date && value.mjesto === nazivLokacije) {
                                tableData += "<tr id=" + value.id_utrka + ">";
                                tableData += "<td data-target=\"nazivU\">" + value.naziv_utrke + "</td>";
                                tableData += "<td data-target=\"datumPoc\">" + value.vrijeme_pocetka + "</td>";
                                tableData += "<td data-target=\"nazivBic\">" + value.naziv_biciklijade + "</td>";
                                tableData += "<td data-target=\"mjesto\">" + value.mjesto + "</td>";
                                tableData += "<td data-target=\"brojNat\">" + value.broj_natjecatelja + "</td>";
                                tableData += "</tr>";
                            }
                        });
                        $("#tableData").append(tableData);
                    }
                });
            });
            break;
        case "Korisnici":
            const DohvatiKorisnikePrivatno = () => {
                $.ajax({
                    url: "../php_funkcije/dohvatiKorisnike.php",
                    method: "POST",
                    dataType: "JSON",
                    success: (data) => {
                        let tableData = "";
                        $("#tableData").empty();
                        $.each(data, (index, value) => {
                            console.log(value);
                            tableData += "<tr id=" + value.id_korisnik + ">";
                            tableData += "<td data-target=\"uloga\">" + value.id_uloga + "</td>";
                            tableData += "<td data-target=\"ime\">" + value.ime + "</td>";
                            tableData += "<td data-target=\"prezime\">" + value.prezime + "</td>";
                            tableData += "<td data-target=\"godina\">" + value.godina_rodenja + "</td>";
                            tableData += "<td data-target=\"email\">" + value.email + "</td>";
                            tableData += "<td data-target=\"korisnik\">" + value.korisnicko_ime + "</td>";
                            tableData += "<td data-target=\"lozinka\">" + value.zaporka + "</td>";
                            tableData += "<td data-target=\"status\">" + value.status + "</td>";
                            tableData += "<td data-target=\"broj_prijava\">" + value.broj_prijava + "</td>";
                            tableData += "</tr>";
                        });
                        $("#tableData").append(tableData);
                    }
                });
            };
            DohvatiKorisnikePrivatno();
            break;
        case "Ažuriraj korisnika":
            alert("Ažuriraj korisnika");
            const DohvatiKorisnike = () => {
                $.ajax({
                    url: "../php_funkcije/dohvatiKorisnike.php",
                    method: "POST",
                    dataType: "JSON",
                    success: (data) => {
                        let tableData = "";
                        $("#tableData").empty();
                        $.each(data, (index, value) => {
                            console.log(value);
                            tableData += "<tr id=" + value.id_korisnik + ">";
                            tableData += "<td data-target=\"uloga\">" + value.id_uloga + "</td>";
                            tableData += "<td data-target=\"ime\">" + value.ime + "</td>";
                            tableData += "<td data-target=\"prezime\">" + value.prezime + "</td>";
                            tableData += "<td data-target=\"godina\">" + value.godina_rodenja + "</td>";
                            tableData += "<td data-target=\"email\">" + value.email + "</td>";
                            tableData += "<td data-target=\"korisnik\">" + value.korisnicko_ime + "</td>";
                            tableData += "<td data-target=\"lozinka\">" + value.zaporka + "</td>";
                            tableData += "<td data-target=\"status\">" + value.status + "</td>";
                            tableData += "<td data-target=\"broj_prijava\">" + value.broj_prijava + "</td>";
                            tableData += "<td><a href=\"#\" data-role=\"update\" data-id=" + value.id_korisnik + ">Odaberi</td>";
                            tableData += "</tr>";
                        });
                        $("#tableData").append(tableData);
                    }
                });
            };
            //dodavanje vrijednosti u polje za input
            $(document).on('click', 'a[data-role=update]', function () {
                //alert($(this).data('id'));
                var id = $(this).data('id');
                var uloga = $('#' + id).children('td[data-target=uloga]').text();
                var ime = $('#' + id).children('td[data-target=ime]').text();
                var prezime = $('#' + id).children('td[data-target=prezime]').text();
                var godina = $('#' + id).children('td[data-target=godina]').text();
                var email = $('#' + id).children('td[data-target=email]').text();
                var korisnik = $('#' + id).children('td[data-target=korisnik]').text();
                var lozinka = $('#' + id).children('td[data-target=lozinka]').text();
                var status = $('#' + id).children('td[data-target=status]').text();
                var broj_prijava = $('#' + id).children('td[data-target=broj_prijava]').text();
                //alert(ime);
                //alert(godina);
                $('#uloga').val(uloga);
                $('#ime').val(ime);
                $('#prezime').val(prezime);
                $('#godina').val(godina);
                $('#email').val(email);
                $('#korisnik').val(korisnik);
                $('#lozinka').val(lozinka);
                $('#status').val(status);
                $('#broj_prijava').val(broj_prijava);
                $('#userId').val(id);
                //$('#myModal').modal('toggle');
            });

            $('#save').click(function () {
                $("#save").prop("disabled", true);
                var id = $('#userId').val();
                var uloga = $('#uloga').val();
                var ime = $('#ime').val();
                var prezime = $('#prezime').val();
                var godina = $('#godina').val();
                var email = $('#email').val();
                var korisnik = $('#korisnik').val();
                var lozinka = $('#lozinka').val();
                var status = $('#status').val();
                var broj_prijava = $('#broj_prijava').val();
                var save = $("#save").val();


                $.ajax({
                    url: '../php_funkcije/crudKorisnike.php',
                    method: 'POST',
                    data: {uloga: uloga, ime: ime, prezime: prezime, godina: godina, email: email, korisnik: korisnik, lozinka: lozinka, status: status, broj_prijava: broj_prijava, userId: id, save: save},
                    success: function (response) {
                        $("#save").prop("disabled", false);
                        DohvatiKorisnike();
                    }
                });
            });
            $('#register').click(function () {
                $("#register").prop("disabled", true);
                //var id= $('#userId').val();
                var uloga = $('#uloga').val();
                var ime = $('#ime').val();
                var prezime = $('#prezime').val();
                var godina = $('#godina').val();
                var email = $('#email').val();
                var korisnik = $('#korisnik').val();
                var lozinka = $('#lozinka').val();
                var status = $('#status').val();
                var broj_prijava = $('#broj_prijava').val();
                var register = $("#register").val();

                /*alert(uloga);            
                 alert(ime);
                 alert(prezime);
                 alert(godina);            
                 alert(email);
                 alert(korisnik);
                 alert(lozinka);            
                 alert(status);
                 alert(broj_prijava);
                 alert(register);*/

                $.ajax({
                    url: '../php_funkcije/crudKorisnike.php',
                    method: 'POST',
                    data: {uloga: uloga, ime: ime, prezime: prezime, godina: godina, email: email, korisnik: korisnik, lozinka: lozinka, status: status, broj_prijava: broj_prijava, register: register},
                    success: function (response) {
                        $("#register").prop("disabled", false);
                        DohvatiKorisnike();
                    }
                });
            });
            $('#obrisi').click(function () {
                //$("#obrisi").prop("disabled", true);
                var id = $('#userId').val();
                var uloga = $('#uloga').val();
                var ime = $('#ime').val();
                var prezime = $('#prezime').val();
                var godina = $('#godina').val();
                var email = $('#email').val();
                var korisnik = $('#korisnik').val();
                var lozinka = $('#lozinka').val();
                var status = $('#status').val();
                var broj_prijava = $('#broj_prijava').val();
                var obrisi = $("#obrisi").val();


                $.ajax({
                    url: '../php_funkcije/crudKorisnike.php',
                    method: 'POST',
                    data: {uloga: uloga, ime: ime, prezime: prezime, godina: godina, email: email, korisnik: korisnik, lozinka: lozinka, status: status, broj_prijava: broj_prijava, userId: id, obrisi: obrisi},
                    success: function (response) {
                        //$("#obrisi").prop("disabled", false);
                        DohvatiKorisnike();
                    }
                });
            });
            DohvatiKorisnike();
            break;
        case "Evidentiranje rezultata utrke":
            alert("Evidentiranje rezultata utrke");
            var korisnik = $("#KORIME").val();
            const DohvatiZavrseneUtrke = () => {
                $.ajax({
                    url: "../php_funkcije/dohvatiUtrkeZaRezultate.php",
                    method: "POST",
                    dataType: "JSON",
                    data: {korime: korisnik},
                    success: (data) => {
                        let tableUt = "";
                        $("#tableUt").empty();
                        $.each(data, (index, value) => {
                            console.log(value);
                            tableUt += "<tr id=" + value.id_utrka + ">";
                            tableUt += "<td data-target=\"utrkaId\">" + value.id_utrka + "</td>";
                            tableUt += "<td data-target=\"nazivUtr\">" + value.naziv_utrke + "</td>";
                            tableUt += "<td data-target=\"vrijemeZav\">" + value.vrijeme_zavrsetka + "</td>";
                            if(value.kraj_utrke === "0"){
                                tableUt += "<td data-target=\"statusUtr\">Utrka aktivna</td>";
                            }
                            if(value.kraj_utrke === "1"){
                                tableUt += "<td data-target=\"statusUtr\">Utrka neaktivna</td>";
                            }
                            tableUt += "<td><a href=\"#\" data-role=\"odaberi\" data-id=" + value.id_utrka + ">Odaberi</td>";
                            tableUt += "</tr>";
                        });
                        $("#tableUt").append(tableUt);
                    }
                });
            };
            DohvatiZavrseneUtrke();
            $(document).on('click', 'a[data-role=odaberi]', function () {
                //alert($(this).data('id'));
                var id = $(this).data('id');
                
                var utrkaStat = $('#' + id).children('td[data-target=statusUtr]').text();
                if (utrkaStat === "Utrka neaktivna") {
                    $('#utrkaStat').val("1");
                }
                if (utrkaStat === "Utrka aktivna") {
                    $('#utrkaStat').val("0");
                }
                $('#utrkaId').val(id);
                $.ajax({
                    url: "../php_funkcije/dohvatiRezultateUtrke.php",
                    method: "POST",
                    dataType: "JSON",
                    data: {utrkaId: id},
                    success: (data) => {
                        let tableRez = "";
                        $("#tableRez").empty();
                        $.each(data, (index, value) => {
                            if(date > value.datum_i_vrijeme_zavrsetka){
                                date = value.datum_i_vrijeme_zavrsetka;
                                korisnik = value.id_korisnik;
                            }
                            console.log(value);
                            tableRez += "<tr id=" + value.id_korisnik + ">";
                            tableRez += "<td data-target=\"ime\">" + value.ime + "</td>";
                            tableRez += "<td data-target=\"prezime\">" + value.prezime + "</td>";
                            tableRez += "<td data-target=\"korIme\">" + value.korisnicko_ime + "</td>";
                            tableRez += "<td data-target=\"vrijemeZ\">" + value.datum_i_vrijeme_zavrsetka + "</td>";
                            tableRez += "<td><a href=\"#\" data-role=\"odaberiK\" data-id=" + value.id_korisnik + ">Odaberi</td>";
                            tableRez += "</tr>";
                        });
                        $("#tableRez").append(tableRez);
                    }
                });
            });
            $(document).on('click', 'a[data-role=odaberiK]', function () {
                var id = $(this).data('id');
                $('#korisnikId').val(id);
            });
            $('#zavrsi').click(function () {
                var id = $('#utrkaId').val();
                var utrkaStat = $('#utrkaStat').val();

                var zavrsi = $("#zavrsi").val();

                $.ajax({
                    url: '../php_funkcije/crudModUtrke.php',
                    method: 'POST',
                    data: {utrkaId: id, utrkaStat: utrkaStat, zavrsi: zavrsi},
                    success: function (response) {
                        DohvatiZavrseneUtrke();
                    }
                });
            });
            $('#zapocni').click(function () {
                var id = $('#utrkaId').val();
                var utrkaStat = $('#utrkaStat').val();

                var zapocni = $("#zapocni").val();

                $.ajax({
                    url: '../php_funkcije/crudModUtrke.php',
                    method: 'POST',
                    data: {utrkaId: id, utrkaStat: utrkaStat, zapocni: zapocni},
                    success: function (response) {
                        DohvatiZavrseneUtrke();
                    }
                });
            });
            $('#spremi').click(function () {
                var utrkaId = $('#utrkaId').val();
                var utrkaStat = $('#utrkaStat').val();
                var spremi = $("#spremi").val();
                if (utrkaStat === "1") {
                    $("#spremi").prop("disabled", true);
                }
                if (utrkaStat === "0") {
                    $("#spremi").prop("disabled", false);
                    var korisnikRac = $('#korisnikRac').val();
                    var vrijemeZ = $('#vrijemeZ').val();

                    $.ajax({
                        url: '../php_funkcije/crudModUtrke.php',
                        method: 'POST',
                        data: {utrkaId: utrkaId, korisnikRac: korisnikRac, vrijemeZ: vrijemeZ, spremi: spremi},
                        success: function (response) {
                        }
                    });
                    $.ajax({
                    url: "../php_funkcije/dohvatiRezultateUtrke.php",
                    method: "POST",
                    dataType: "JSON",
                    data: {utrkaId: utrkaId},
                    success: (data) => {
                        let tableRez = "";
                        $("#tableRez").empty();
                        $.each(data, (index, value) => {
                            if(date > value.datum_i_vrijeme_zavrsetka){
                                date = value.datum_i_vrijeme_zavrsetka;
                                korisnik = value.id_korisnik;
                            }
                            console.log(value);
                            tableRez += "<tr id=" + value.id_korisnik + ">";
                            tableRez += "<td data-target=\"ime\">" + value.ime + "</td>";
                            tableRez += "<td data-target=\"prezime\">" + value.prezime + "</td>";
                            tableRez += "<td data-target=\"korIme\">" + value.korisnicko_ime + "</td>";
                            tableRez += "<td data-target=\"vrijemeZ\">" + value.datum_i_vrijeme_zavrsetka + "</td>";
                            tableRez += "<td><a href=\"#\" data-role=\"odaberiK\" data-id=" + value.id_korisnik + ">Odaberi</td>";
                            tableRez += "</tr>";
                        });
                        $("#tableRez").append(tableRez);
                    }
                });
                }
            });
            $('#azuriraj').click(function () {
                var utrkaId = $('#utrkaId').val();
                var utrkaStat = $('#utrkaStat').val();
                var azuriraj = $("#azuriraj").val();
                if (utrkaStat === "1") {
                    $("#azuriraj").prop("disabled", true);
                }
                if (utrkaStat === "0") {
                    
                    var korisnikId = $('#korisnikId').val();
                    var vrijemeZ = $('#vrijemeZ').val();

                    $("#azuriraj").prop("disabled", false);
                    $.ajax({
                        url: '../php_funkcije/crudModUtrke.php',
                        method: 'POST',
                        data: {utrkaId: utrkaId, korisnikId: korisnikId, vrijemeZ: vrijemeZ, azuriraj: azuriraj},
                        success: function (response) {
                        }
                    });
                    $.ajax({
                    url: "../php_funkcije/dohvatiRezultateUtrke.php",
                    method: "POST",
                    dataType: "JSON",
                    data: {utrkaId: utrkaId},
                    success: (data) => {
                        let tableRez = "";
                        $("#tableRez").empty();
                        $.each(data, (index, value) => {
                            if(date > value.datum_i_vrijeme_zavrsetka){
                                date = value.datum_i_vrijeme_zavrsetka;
                                korisnik = value.id_korisnik;
                            }
                            console.log(value);
                            tableRez += "<tr id=" + value.id_korisnik + ">";
                            tableRez += "<td data-target=\"ime\">" + value.ime + "</td>";
                            tableRez += "<td data-target=\"prezime\">" + value.prezime + "</td>";
                            tableRez += "<td data-target=\"korIme\">" + value.korisnicko_ime + "</td>";
                            tableRez += "<td data-target=\"vrijemeZ\">" + value.datum_i_vrijeme_zavrsetka + "</td>";
                            tableRez += "<td><a href=\"#\" data-role=\"odaberiK\" data-id=" + value.id_korisnik + ">Odaberi</td>";
                            tableRez += "</tr>";
                        });
                        $("#tableRez").append(tableRez);
                    }
                });
                }
            });
            $('#obrisi').click(function () {
                var utrkaId = $('#utrkaId').val();
                var utrkaStat = $('#utrkaStat').val();
                var obrisi = $("#obrisi").val();
                if (utrkaStat === "1") {
                    $("#obrisi").prop("disabled", true);
                }
                if (utrkaStat === "0") {
                    
                    var korisnikId = $('#korisnikId').val();
                    var vrijemeZ = $('#vrijemeZ').val();

                    $("#obrisi").prop("disabled", false);
                    $.ajax({
                        url: '../php_funkcije/crudModUtrke.php',
                        method: 'POST',
                        data: {utrkaId: utrkaId, korisnikId: korisnikId, vrijemeZ: vrijemeZ, obrisi: obrisi},
                        success: function (response) {
                        }
                    });
                    $.ajax({
                    url: "../php_funkcije/dohvatiRezultateUtrke.php",
                    method: "POST",
                    dataType: "JSON",
                    data: {utrkaId: utrkaId},
                    success: (data) => {
                        let tableRez = "";
                        $("#tableRez").empty();
                        $.each(data, (index, value) => {
                            if(date > value.datum_i_vrijeme_zavrsetka){
                                date = value.datum_i_vrijeme_zavrsetka;
                                korisnik = value.id_korisnik;
                            }
                            console.log(value);
                            tableRez += "<tr id=" + value.id_korisnik + ">";
                            tableRez += "<td data-target=\"ime\">" + value.ime + "</td>";
                            tableRez += "<td data-target=\"prezime\">" + value.prezime + "</td>";
                            tableRez += "<td data-target=\"korIme\">" + value.korisnicko_ime + "</td>";
                            tableRez += "<td data-target=\"vrijemeZ\">" + value.datum_i_vrijeme_zavrsetka + "</td>";
                            tableRez += "<td><a href=\"#\" data-role=\"odaberiK\" data-id=" + value.id_korisnik + ">Odaberi</td>";
                            tableRez += "</tr>";
                        });
                        $("#tableRez").append(tableRez);
                    }
                });
                }
            });
            break;
        case "Odobravanje prijava":
            alert("Odobravanje prijava");
            var korisnik = $("#KORIME").val();
            var today = new Date();
            var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
            const DohvatiBuduceUtrke = () => {
                $.ajax({
                    url: "../php_funkcije/dohvatiPlaniraneUtrkeMod.php",
                    method: "POST",
                    dataType: "JSON",
                    data: {korime: korisnik},
                    success: (data) => {
                        let tableData = "";
                        $("#tableData").empty();
                        $.each(data, (index, value) => {
                            console.log(value);
                            tableData += "<tr id=" + value.id_utrka + ">";
                            tableData += "<td data-target=\"utrkaId\">" + value.id_utrka + "</td>";
                            tableData += "<td data-target=\"nazivU\">" + value.naziv_utrke + "</td>";
                            tableData += "<td data-target=\"datumPoc\">" + value.vrijeme_pocetka + "</td>";
                            tableData += "<td data-target=\"nazivBic\">" + value.naziv_biciklijade + "</td>";
                            tableData += "<td data-target=\"brojNat\">" + value.broj_natjecatelja + "</td>";
                            if(value.kraj_utrke === "0") {
                                tableData += "<td data-target=\"statusUtr\">Aktivna</td>";
                            }
                            if(value.kraj_utrke === "1") {
                                tableData += "<td data-target=\"statusUtr\">Neaktivna</td>";
                            }
                            tableData += "<td><a href=\"#\" data-role=\"odaberi\" data-id=" + value.id_utrka + ">Odaberi</td>";
                            tableData += "</tr>";
                        });
                        $("#tableData").append(tableData);
                    }
                });
            };
            DohvatiBuduceUtrke();
            $(document).on('click', 'a[data-role=odaberi]', function () {
                var id = $(this).data('id');
                var status = $('#' + id).children('td[data-target=statusUtr]').text();
                $('#utrkaId').val(id);
                $('#utrkaStat').val(status);
                
                if(status === "Aktivna") {
                    $("#prihvati").prop("disabled", false);
                    $("#odbij").prop("disabled", false);
                }
                if (status === "Neaktivna") {
                    $("#prihvati").prop("disabled", true);
                    $("#odbij").prop("disabled", true);
                }
                $.ajax({
                    url: "../php_funkcije/dohvatiPrijaveUtrke.php",
                    method: "POST",
                    dataType: "JSON",
                    data: {utrkaId: id},
                    success: (data) => {
                        let tableRez = "";
                        $("#tableRez").empty();
                        $.each(data, (index, value) => {
                            console.log(value);
                            tableRez += "<tr id=" + value.id_korisnik + ">";
                            tableRez += "<td data-target=\"ime\">" + value.ime + "</td>";
                            tableRez += "<td data-target=\"prezime\">" + value.prezime + "</td>";
                            tableRez += "<td data-target=\"mjesto\">" + value.mjesto + "</td>";
                            tableRez += "<td data-target=\"prijavaPrih\">" + value.prijava_prihvacena + "</td>";
                            tableRez += "<td><a href=\"#\" data-role=\"odaberiK\" data-id=" + value.id_prijava + ">Odaberi</td>";
                            tableRez += "</tr>";
                        });
                        $("#tableRez").append(tableRez);
                    }
                });
            });
            $(document).on('click', 'a[data-role=odaberiK]', function () {
                var id = $(this).data('id');
                $('#korisnikId').val(id);
            });
            $('#prihvati').click(function () {
                var utrkaId = $('#utrkaId').val();
                var korisnikId = $('#korisnikId').val();
                var prihvati = $("#prihvati").val();

                $.ajax({
                    url: '../php_funkcije/odgovorNaPrijave.php',
                    method: 'POST',
                    data: {utrkaId: utrkaId, korisnikId: korisnikId, prihvati: prihvati},
                    success: function (response) {
                    }
                });
                $.ajax({
                    url: "../php_funkcije/dohvatiPrijaveUtrke.php",
                    method: "POST",
                    dataType: "JSON",
                    data: {utrkaId: utrkaId},
                    success: (data) => {
                        let tableRez = "";
                        $("#tableRez").empty();
                        $.each(data, (index, value) => {
                            console.log(value);
                            tableRez += "<tr id=" + value.id_korisnik + ">";
                            tableRez += "<td data-target=\"ime\">" + value.ime + "</td>";
                            tableRez += "<td data-target=\"prezime\">" + value.prezime + "</td>";
                            tableRez += "<td data-target=\"mjesto\">" + value.mjesto + "</td>";
                            tableRez += "<td data-target=\"prijavaPrih\">" + value.prijava_prihvacena + "</td>";
                            tableRez += "<td><a href=\"#\" data-role=\"odaberiK\" data-id=" + value.id_prijava + ">Odaberi</td>";
                            tableRez += "</tr>";
                        });
                        $("#tableRez").append(tableRez);
                    }
                });
            });
            $('#odbij').click(function () {
                var utrkaId = $('#utrkaId').val();
                var korisnikId = $('#korisnikId').val();
                var odbij = $("#odbij").val();

                $.ajax({
                    url: '../php_funkcije/odgovorNaPrijave.php',
                    method: 'POST',
                    data: {utrkaId: utrkaId, korisnikId: korisnikId, odbij: odbij},
                    success: function (response) {
                    }
                });
                $.ajax({
                    url: "../php_funkcije/dohvatiPrijaveUtrke.php",
                    method: "POST",
                    dataType: "JSON",
                    data: {utrkaId: utrkaId},
                    success: (data) => {
                        let tableRez = "";
                        $("#tableRez").empty();
                        $.each(data, (index, value) => {
                            console.log(value);
                            tableRez += "<tr id=" + value.id_korisnik + ">";
                            tableRez += "<td data-target=\"ime\">" + value.ime + "</td>";
                            tableRez += "<td data-target=\"prezime\">" + value.prezime + "</td>";
                            tableRez += "<td data-target=\"mjesto\">" + value.mjesto + "</td>";
                            tableRez += "<td data-target=\"prijavaPrih\">" + value.prijava_prihvacena + "</td>";
                            tableRez += "<td><a href=\"#\" data-role=\"odaberiK\" data-id=" + value.id_prijava + ">Odaberi</td>";
                            tableRez += "</tr>";
                        });
                        $("#tableRez").append(tableRez);
                    }
                });
            });
            break;
        case "Odustali od utrke":
            alert("odustali od utrke");
             var korisnik = $("#KORIME").val();
            const DohvatiUtrkeZaKorisnike = () => {
                $.ajax({
                    url: "../php_funkcije/dohvatiPlaniraneUtrkeMod.php",
                    method: "POST",
                    dataType: "JSON",
                    data: {korime: korisnik},
                    success: (data) => {
                        let tableData = "";
                        $("#tableData").empty();
                        $.each(data, (index, value) => {
                            console.log(value);
                            tableData += "<tr id=" + value.id_utrka + ">";
                            tableData += "<td data-target=\"utrkaId\">" + value.id_utrka + "</td>";
                            tableData += "<td data-target=\"nazivU\">" + value.naziv_utrke + "</td>";
                            tableData += "<td data-target=\"datumPoc\">" + value.vrijeme_pocetka + "</td>";
                            tableData += "<td data-target=\"nazivBic\">" + value.naziv_biciklijade + "</td>";
                            tableData += "<td data-target=\"brojNat\">" + value.broj_natjecatelja + "</td>";
                            if(value.kraj_utrke === "0") {
                                tableData += "<td data-target=\"statusUtr\">Aktivna</td>";
                            }
                            if(value.kraj_utrke === "1") {
                                tableData += "<td data-target=\"statusUtr\">Neaktivna</td>";
                            }
                            tableData += "<td><a href=\"#\" data-role=\"odaberi\" data-id=" + value.id_utrka + ">Odaberi</td>";
                            tableData += "</tr>";
                        });
                        $("#tableData").append(tableData);
                    }
                });
            };
            DohvatiUtrkeZaKorisnike();
            $(document).on('click', 'a[data-role=odaberi]', function () {
                var id = $(this).data('id');
                $('#utrkaId').val(id);
                
                $.ajax({
                    url: "../php_funkcije/dohvatiOdustale.php",
                    method: "POST",
                    dataType: "JSON",
                    data: {utrkaId: id},
                    success: (data) => {
                        let tableRez = "";
                        $("#tableRez").empty();
                        $.each(data, (index, value) => {
                            console.log(value);
                            tableRez += "<tr id=" + value.id_korisnik + ">";
                            tableRez += "<td data-target=\"ime\">" + value.ime + "</td>";
                            tableRez += "<td data-target=\"prezime\">" + value.prezime + "</td>";
                            tableRez += "<td data-target=\"korIme\">" + value.korisnicko_ime + "</td>";
                            tableRez += "<td data-target=\"razlog\">" + value.razlog_odustajanja + "</td>";
                            tableRez += "</tr>";
                        });
                        $("#tableRez").append(tableRez);
                    }
                });
            });
            break;
        case "Zaboravljena lozinka":
            alert("Zaboravljena lozinka");
            break;
        default:
            break;
    }
});
    