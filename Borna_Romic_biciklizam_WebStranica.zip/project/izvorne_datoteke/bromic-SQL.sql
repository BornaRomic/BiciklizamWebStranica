-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema WebDiP2019x111
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema WebDiP2019x111
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `WebDiP2019x111` DEFAULT CHARACTER SET utf8 ;
USE `WebDiP2019x111` ;

-- -----------------------------------------------------
-- Table `WebDiP2019x111`.`uloga`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `WebDiP2019x111`.`uloga` (
  `id_uloga` INT NOT NULL AUTO_INCREMENT,
  `naziv` VARCHAR(30) NOT NULL,
  `opis` TEXT NOT NULL,
  PRIMARY KEY (`id_uloga`),
  UNIQUE INDEX `naziv_UNIQUE` (`naziv` ASC))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `WebDiP2019x111`.`korisnik`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `WebDiP2019x111`.`korisnik` (
  `id_korisnik` INT NOT NULL AUTO_INCREMENT,
  `ime` VARCHAR(45) NOT NULL,
  `prezime` VARCHAR(45) NOT NULL,
  `korisnicko_ime` VARCHAR(25) NOT NULL,
  `e-mail` VARCHAR(45) NOT NULL,
  `zaporka` VARCHAR(25) NOT NULL,
  `lozinka_sha1` CHAR(40) NULL,
  `uvjeti` DATETIME NOT NULL,
  `status` TINYINT(1) NOT NULL,
  `id_uloga` INT NOT NULL,
  PRIMARY KEY (`id_korisnik`),
  UNIQUE INDEX `korisnicko_ime_UNIQUE` (`korisnicko_ime` ASC),
  UNIQUE INDEX `e-mail_UNIQUE` (`e-mail` ASC),
  INDEX `fk_korisnik_uloga_idx` (`id_uloga` ASC),
  CONSTRAINT `fk_korisnik_uloga`
    FOREIGN KEY (`id_uloga`)
    REFERENCES `WebDiP2019x111`.`uloga` (`id_uloga`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `WebDiP2019x111`.`tip radnje`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `WebDiP2019x111`.`tip radnje` (
  `id_tip` INT NOT NULL AUTO_INCREMENT,
  `naziv_radnje` VARCHAR(25) NOT NULL,
  PRIMARY KEY (`id_tip`))
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `WebDiP2019x111`.`dnevnik`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `WebDiP2019x111`.`dnevnik` (
  `id_dnevnik` INT NOT NULL AUTO_INCREMENT,
  `radnja` TEXT NOT NULL,
  `upit` TEXT NOT NULL,
  `datum_vrijeme` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `id_korisnik` INT NOT NULL,
  `id_tip` INT NOT NULL,
  PRIMARY KEY (`id_dnevnik`, `id_korisnik`, `id_tip`),
  INDEX `fk_dnevnik_korisnik1_idx` (`id_korisnik` ASC),
  INDEX `fk_dnevnik_tip_radnje1_idx` (`id_tip` ASC),
  CONSTRAINT `fk_dnevnik_korisnik1`
    FOREIGN KEY (`id_korisnik`)
    REFERENCES `WebDiP2019x111`.`korisnik` (`id_korisnik`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `fk_dnevnik_tip_radnje1`
    FOREIGN KEY (`id_tip`)
    REFERENCES `WebDiP2019x111`.`tip radnje` (`id_tip`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `WebDiP2019x111`.`lokacija`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `WebDiP2019x111`.`lokacija` (
  `id_lokacija` INT NOT NULL AUTO_INCREMENT,
  `mjesto` VARCHAR(45) NOT NULL,
  `adresa` VARCHAR(45) NOT NULL,
  `id_administrator` INT NOT NULL,
  PRIMARY KEY (`id_lokacija`),
  INDEX `fk_lokacija_korisnik1_idx` (`id_administrator` ASC),
  CONSTRAINT `fk_lokacija_korisnik1`
    FOREIGN KEY (`id_administrator`)
    REFERENCES `WebDiP2019x111`.`korisnik` (`id_korisnik`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `WebDiP2019x111`.`biciklijada`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `WebDiP2019x111`.`biciklijada` (
  `id_biciklijada` INT NOT NULL AUTO_INCREMENT,
  `naziv_biciklijade` VARCHAR(45) NOT NULL,
  `vrijeme_pocetka` DATETIME NOT NULL,
  `vrijeme_zavrsetka` DATETIME NOT NULL,
  `id_administrator` INT NOT NULL,
  PRIMARY KEY (`id_biciklijada`),
  INDEX `fk_biciklijada_korisnik1_idx` (`id_administrator` ASC),
  CONSTRAINT `fk_biciklijada_korisnik1`
    FOREIGN KEY (`id_administrator`)
    REFERENCES `WebDiP2019x111`.`korisnik` (`id_korisnik`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `WebDiP2019x111`.`lokacija/biciklijada`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `WebDiP2019x111`.`lokacija/biciklijada` (
  `id_lokacija_biciklijada` INT NOT NULL AUTO_INCREMENT,
  `id_biciklijada` INT NOT NULL,
  `id_lokacija` INT NOT NULL,
  PRIMARY KEY (`id_lokacija_biciklijada`, `id_biciklijada`, `id_lokacija`),
  INDEX `fk_biciklijada_has_lokacija_lokacija1_idx` (`id_lokacija` ASC),
  INDEX `fk_biciklijada_has_lokacija_biciklijada1_idx` (`id_biciklijada` ASC),
  CONSTRAINT `fk_biciklijada_has_lokacija_biciklijada1`
    FOREIGN KEY (`id_biciklijada`)
    REFERENCES `WebDiP2019x111`.`biciklijada` (`id_biciklijada`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `fk_biciklijada_has_lokacija_lokacija1`
    FOREIGN KEY (`id_lokacija`)
    REFERENCES `WebDiP2019x111`.`lokacija` (`id_lokacija`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `WebDiP2019x111`.`moderator/lokacija`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `WebDiP2019x111`.`moderator/lokacija` (
  `id_moderator_lokacija` INT NOT NULL AUTO_INCREMENT,
  `id_lokacija` INT NOT NULL,
  `id_moderator` INT NOT NULL,
  PRIMARY KEY (`id_moderator_lokacija`, `id_lokacija`, `id_moderator`),
  INDEX `fk_lokacija_has_korisnik_korisnik1_idx` (`id_moderator` ASC),
  INDEX `fk_lokacija_has_korisnik_lokacija1_idx` (`id_lokacija` ASC),
  CONSTRAINT `fk_lokacija_has_korisnik_lokacija1`
    FOREIGN KEY (`id_lokacija`)
    REFERENCES `WebDiP2019x111`.`lokacija` (`id_lokacija`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `fk_lokacija_has_korisnik_korisnik1`
    FOREIGN KEY (`id_moderator`)
    REFERENCES `WebDiP2019x111`.`korisnik` (`id_korisnik`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `WebDiP2019x111`.`utrka`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `WebDiP2019x111`.`utrka` (
  `id_utrka` INT NOT NULL AUTO_INCREMENT,
  `naziv_utrke` VARCHAR(45) NOT NULL,
  `startnina` INT NOT NULL,
  `broj_natjecatelja` INT NOT NULL,
  `vrijeme_pocetka` DATETIME NOT NULL,
  `id_biciklijada` INT NOT NULL,
  PRIMARY KEY (`id_utrka`),
  INDEX `fk_utrka_biciklijada1_idx` (`id_biciklijada` ASC),
  CONSTRAINT `fk_utrka_biciklijada1`
    FOREIGN KEY (`id_biciklijada`)
    REFERENCES `WebDiP2019x111`.`biciklijada` (`id_biciklijada`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `WebDiP2019x111`.`prijava`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `WebDiP2019x111`.`prijava` (
  `id_prijava` INT NOT NULL AUTO_INCREMENT,
  `ime` VARCHAR(30) NOT NULL,
  `prezime` VARCHAR(30) NOT NULL,
  `prijava_prihvacena` TINYINT(1) NOT NULL,
  `mjesto` VARCHAR(45) NOT NULL,
  `id_korisnik` INT NOT NULL,
  `id_utrka` INT NOT NULL,
  `id_moderator` INT NOT NULL,
  PRIMARY KEY (`id_prijava`, `id_korisnik`, `id_utrka`, `id_moderator`),
  INDEX `fk_prijava_korisnik1_idx` (`id_korisnik` ASC),
  INDEX `fk_prijava_utrka1_idx` (`id_utrka` ASC),
  INDEX `index4` (`id_moderator` ASC),
  CONSTRAINT `fk_prijava_korisnik1`
    FOREIGN KEY (`id_korisnik`)
    REFERENCES `WebDiP2019x111`.`korisnik` (`id_korisnik`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `fk_prijava_utrka1`
    FOREIGN KEY (`id_utrka`)
    REFERENCES `WebDiP2019x111`.`utrka` (`id_utrka`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `fk_prijava_1`
    FOREIGN KEY (`id_moderator`)
    REFERENCES `WebDiP2019x111`.`korisnik` (`id_korisnik`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `WebDiP2019x111`.`prijava prihvacena`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `WebDiP2019x111`.`prijava prihvacena` (
  `id_prijava_prihvacena` INT NOT NULL AUTO_INCREMENT,
  `potvrda_o_placanju` TINYINT(1) NOT NULL,
  `racun` TEXT NOT NULL,
  `id_prijava` INT NOT NULL,
  PRIMARY KEY (`id_prijava_prihvacena`),
  INDEX `fk_prijava prihvacena_prijava1_idx` (`id_prijava` ASC),
  CONSTRAINT `fk_prijava prihvacena_prijava1`
    FOREIGN KEY (`id_prijava`)
    REFERENCES `WebDiP2019x111`.`prijava` (`id_prijava`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `WebDiP2019x111`.`odabir pobjednika`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `WebDiP2019x111`.`odabir pobjednika` (
  `id_pobjednik` INT NOT NULL AUTO_INCREMENT,
  `name` TEXT NOT NULL,
  `id_korisnik` INT NOT NULL,
  `id_administrator` INT NOT NULL,
  `id_utrka` INT NOT NULL,
  PRIMARY KEY (`id_pobjednik`),
  INDEX `fk_odabir pobjednika_korisnik1_idx` (`id_korisnik` ASC),
  INDEX `fk_odabir pobjednika_korisnik2_idx` (`id_administrator` ASC),
  INDEX `fk_odabir pobjednika_utrka1_idx` (`id_utrka` ASC),
  CONSTRAINT `fk_odabir pobjednika_korisnik1`
    FOREIGN KEY (`id_korisnik`)
    REFERENCES `WebDiP2019x111`.`korisnik` (`id_korisnik`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `fk_odabir pobjednika_korisnik2`
    FOREIGN KEY (`id_administrator`)
    REFERENCES `WebDiP2019x111`.`korisnik` (`id_korisnik`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `fk_odabir pobjednika_utrka1`
    FOREIGN KEY (`id_utrka`)
    REFERENCES `WebDiP2019x111`.`utrka` (`id_utrka`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `WebDiP2019x111`.`rezultati utrke`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `WebDiP2019x111`.`rezultati utrke` (
  `id_rezultat` INT NOT NULL AUTO_INCREMENT,
  `datum_i_vrijeme_zavrsetka` DATETIME NOT NULL,
  `id_korisnik` INT NOT NULL,
  `id_utrka` INT NOT NULL,
  `id_moderator` INT NOT NULL,
  PRIMARY KEY (`id_rezultat`),
  INDEX `fk_rezultati utrke_korisnik1_idx` (`id_korisnik` ASC),
  INDEX `fk_rezultati utrke_utrka1_idx` (`id_utrka` ASC),
  INDEX `fk_rezultati utrke_korisnik2_idx` (`id_moderator` ASC),
  CONSTRAINT `fk_rezultati utrke_korisnik1`
    FOREIGN KEY (`id_korisnik`)
    REFERENCES `WebDiP2019x111`.`korisnik` (`id_korisnik`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_rezultati utrke_utrka1`
    FOREIGN KEY (`id_utrka`)
    REFERENCES `WebDiP2019x111`.`utrka` (`id_utrka`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_rezultati utrke_korisnik2`
    FOREIGN KEY (`id_moderator`)
    REFERENCES `WebDiP2019x111`.`korisnik` (`id_korisnik`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
DEFAULT CHARACTER SET = utf8;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
