-- phpMyAdmin SQL Dump
-- version 4.5.4.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 05, 2020 at 06:59 PM
-- Server version: 5.5.62-0+deb8u1
-- PHP Version: 7.2.25-1+0~20191128.32+debian8~1.gbp108445

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `WebDiP2019x111`
--

-- --------------------------------------------------------

--
-- Table structure for table `biciklijada`
--

CREATE TABLE `biciklijada` (
  `id_biciklijada` int(11) NOT NULL,
  `naziv_biciklijade` varchar(45) NOT NULL,
  `vrijeme_pocetka` datetime NOT NULL,
  `vrijeme_zavrsetka` datetime NOT NULL,
  `id_administrator` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `biciklijada`
--

INSERT INTO `biciklijada` (`id_biciklijada`, `naziv_biciklijade`, `vrijeme_pocetka`, `vrijeme_zavrsetka`, `id_administrator`) VALUES
(1, '4 Islands', '2020-04-29 08:00:00', '2020-05-05 20:00:00', 1),
(2, 'Bic Pak', '2020-04-16 10:00:00', '2020-04-21 19:00:00', 1),
(3, 'Weekend Bike & Gourmet Tour', '2020-04-18 06:00:00', '2020-04-19 15:00:00', 1),
(4, 'BIMEP', '2020-06-09 08:00:00', '2020-06-12 09:00:00', 5),
(5, 'E-BIKE', '2020-04-30 08:00:00', '2020-05-01 18:00:00', 5),
(6, 'Gora Bike', '2020-04-24 07:00:00', '2020-04-24 21:00:00', 6),
(7, 'Limes Bike Tour', '2020-04-28 06:00:00', '2020-04-28 15:00:00', 6),
(8, 'Zabok Bike Tour', '2020-04-30 11:00:00', '2020-04-30 19:00:00', 6),
(9, '1-2-3-4 VirBike', '2020-03-30 06:00:00', '2020-03-30 23:00:00', 1),
(10, 'Karlovačke 4 rijeke', '2020-08-11 08:00:00', '2020-08-12 21:00:00', 5);

-- --------------------------------------------------------

--
-- Table structure for table `dnevnik`
--

CREATE TABLE `dnevnik` (
  `id_dnevnik` int(11) NOT NULL,
  `radnja` text NOT NULL,
  `upit` text NOT NULL,
  `datum_vrijeme` datetime NOT NULL,
  `id_korisnik` int(11) NOT NULL,
  `id_tip` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `dnevnik`
--

INSERT INTO `dnevnik` (`id_dnevnik`, `radnja`, `upit`, `datum_vrijeme`, `id_korisnik`, `id_tip`) VALUES
(1, 'prijava.html', 'SELECT * FROM korisnik;', '2020-04-04 15:00:00', 1, 1),
(2, 'obrazac.html', 'SELECT * FROM biciklijada;', '2020-04-06 13:00:00', 1, 2),
(3, 'prijava.html', 'SELECT * FROM korisnik;', '2020-04-08 12:00:00', 4, 1),
(4, 'prijava.html', 'SELECT * FROM korisnik;', '2020-04-09 09:00:00', 7, 1),
(5, 'prijava.html', 'SELECT * FROM korisnik;', '2020-04-01 13:00:00', 9, 1),
(6, 'prijava.html', 'SELECT * FROM korisnik;', '0000-00-00 00:00:00', 5, 1),
(7, 'obrazac.html', 'SELECT * FROM korisnik, utrka;', '2020-04-03 09:00:00', 10, 3),
(8, 'prijava.html', 'SELECT * FROM korisnik;', '2020-04-01 11:21:18', 6, 1),
(9, 'prijava.html', 'SELECT * FROM korisnik;', '2020-04-01 23:00:00', 2, 1),
(10, 'prijava.html', 'SELECT * FROM korisnik;', '2020-02-12 01:00:00', 3, 1);

-- --------------------------------------------------------

--
-- Table structure for table `korisnik`
--

CREATE TABLE `korisnik` (
  `id_korisnik` int(11) NOT NULL,
  `ime` varchar(45) NOT NULL,
  `prezime` varchar(45) NOT NULL,
  `korisnicko_ime` varchar(25) NOT NULL,
  `e-mail` varchar(45) NOT NULL,
  `zaporka` varchar(25) NOT NULL,
  `lozinka_sha1` char(40) DEFAULT NULL,
  `uvjeti` datetime NOT NULL,
  `status` tinyint(1) NOT NULL,
  `id_uloga` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `korisnik`
--

INSERT INTO `korisnik` (`id_korisnik`, `ime`, `prezime`, `korisnicko_ime`, `e-mail`, `zaporka`, `lozinka_sha1`, `uvjeti`, `status`, `id_uloga`) VALUES
(1, 'Borna', 'Romić', 'bromic', 'bromic@foi.hr', 'bromiclozinka', '42acfb5a1b049160405bca8e6b9a23a06f810ed4', '2020-03-30 12:00:00', 1, 1),
(2, 'Sven', 'Petrović', 'spetrovic', 'spetrovic@foi.hr', 'spetroviclozinka', '54d786b0883ac7029a7c413ab76a074f87db8060', '2020-03-30 15:00:00', 1, 2),
(3, 'Emil', 'Mihalić', 'emihalic', 'emihalic@foi.hr', 'emihaliczaporka', '6c8dc4fe0961a35a1ad7002b7dd1139aa9100a58', '2020-04-02 20:00:00', 1, 2),
(4, 'Luka', 'Mrkonjić', 'lukamrko', 'lukamrko@foi.hr', 'lukamrkolozinka', NULL, '2020-04-03 23:00:00', 1, 2),
(5, 'Luka', 'Rožić', 'lrozic', 'lrozic@foi.hr', 'lroziczaporka', '77367bc0f3e8e4272fffbb773a2460141f0f07f5', '2020-04-05 03:00:00', 1, 1),
(6, 'Martina', 'Ricijaš', 'mricijas', 'mricijas@foi.hr', 'mricijaszaporka', '405ee1c0897db9a7d7c847b47dd53b65d0b4f111', '2020-04-05 08:00:00', 1, 1),
(7, 'Tomislav', 'Periša', 'tperisa', 'tperisa@foi.hr', 'tperisazaporka', NULL, '2020-04-03 09:05:32', 1, 3),
(8, 'Josip', 'Matoković', 'jmatokovic', 'jmatokovic@foi.hr', 'jmatokoviczaporka', NULL, '2020-04-05 09:00:00', 0, 3),
(9, 'Karlo', 'Nenadić', 'knenadic', 'knenadic@foi.hr', 'knenadiczaporka', '3219cbbfff8a1880226b8211f7ca71fbc556f031', '2020-04-02 08:00:00', 1, 3),
(10, 'Zvonimir', 'Petričušić', 'zpetricusic', 'zpetricusic@foi.hr', 'zpetricusiczaporka', NULL, '2020-04-03 06:00:00', 1, 3);

-- --------------------------------------------------------

--
-- Table structure for table `lokacija`
--

CREATE TABLE `lokacija` (
  `id_lokacija` int(11) NOT NULL,
  `mjesto` varchar(45) NOT NULL,
  `adresa` varchar(45) NOT NULL,
  `id_administrator` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `lokacija`
--

INSERT INTO `lokacija` (`id_lokacija`, `mjesto`, `adresa`, `id_administrator`) VALUES
(1, 'Virovitica', 'Ulica Nikole Tricka', 1),
(2, 'Varaždin', 'Ulica Julija Merlića', 5),
(3, 'Zabok', 'Ulica Matije Gupca', 6),
(4, 'Zagreb', 'Trnjanska ulica', 1),
(5, 'Vir', 'Krčevine', 1),
(6, 'Zadar', 'Benkovačka cesta', 5),
(7, 'Split', 'Marmontova ulica', 6),
(8, 'Koprivnica', 'Ulica Ivana Meštrovića', 1),
(9, 'Osijek', 'Vodenička ulica', 6),
(10, 'Karlovac', 'Ulica Ivanja Banjevčića', 5);

-- --------------------------------------------------------

--
-- Table structure for table `lokacija/biciklijada`
--

CREATE TABLE `lokacija/biciklijada` (
  `id_lokacija_biciklijada` int(11) NOT NULL,
  `id_biciklijada` int(11) NOT NULL,
  `id_lokacija` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `lokacija/biciklijada`
--

INSERT INTO `lokacija/biciklijada` (`id_lokacija_biciklijada`, `id_biciklijada`, `id_lokacija`) VALUES
(6, 9, 1),
(9, 5, 2),
(10, 7, 2),
(4, 8, 3),
(8, 5, 3),
(1, 1, 5),
(2, 1, 6),
(3, 1, 7),
(7, 9, 8),
(5, 10, 10);

-- --------------------------------------------------------

--
-- Table structure for table `moderator/lokacija`
--

CREATE TABLE `moderator/lokacija` (
  `id_moderator_lokacija` int(11) NOT NULL,
  `id_lokacija` int(11) NOT NULL,
  `id_moderator` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `moderator/lokacija`
--

INSERT INTO `moderator/lokacija` (`id_moderator_lokacija`, `id_lokacija`, `id_moderator`) VALUES
(1, 1, 2),
(3, 2, 2),
(6, 4, 2),
(9, 5, 2),
(2, 2, 3),
(8, 8, 3),
(10, 3, 3),
(4, 2, 4),
(5, 6, 4),
(7, 7, 4);

-- --------------------------------------------------------

--
-- Table structure for table `odabir pobjednika`
--

CREATE TABLE `odabir pobjednika` (
  `id_pobjednik` int(11) NOT NULL,
  `opis` text NOT NULL,
  `id_korisnik` int(11) NOT NULL,
  `id_administrator` int(11) NOT NULL,
  `id_utrka` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `odabir pobjednika`
--

INSERT INTO `odabir pobjednika` (`id_pobjednik`, `opis`, `id_korisnik`, `id_administrator`, `id_utrka`) VALUES
(1, 'Pobjednik je Karlo Nenadić', 9, 1, 1),
(2, 'Pobjednik je Karlo Nenadić', 9, 1, 4),
(3, 'Pobjednik je Zvonimir Petričušić jer je Tomislav Periša uhvaćen u varanju', 10, 5, 10),
(4, 'Pobjednik je Karlo Nenadić', 9, 6, 8),
(5, 'Pobjednik je Tomislav Periša', 7, 1, 2),
(6, 'Pobjednik je Tomislav Periša', 7, 1, 6),
(7, 'Pobjednik je Karlo Nenadić', 9, 5, 3),
(8, 'Pobjednik je Zvonimir Petričušić', 10, 1, 5),
(9, 'Pobjednik je Tomislav Periša', 7, 5, 9),
(10, 'Pobjednik je Karlo Nenadić', 9, 1, 7);

-- --------------------------------------------------------

--
-- Table structure for table `prijava`
--

CREATE TABLE `prijava` (
  `id_prijava` int(11) NOT NULL,
  `ime` varchar(30) NOT NULL,
  `prezime` varchar(30) NOT NULL,
  `prijava_prihvacena` tinyint(1) NOT NULL,
  `mjesto` varchar(45) NOT NULL,
  `id_korisnik` int(11) NOT NULL,
  `id_utrka` int(11) NOT NULL,
  `id_moderator` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `prijava`
--

INSERT INTO `prijava` (`id_prijava`, `ime`, `prezime`, `prijava_prihvacena`, `mjesto`, `id_korisnik`, `id_utrka`, `id_moderator`) VALUES
(1, 'Karlo', 'Nenadić', 1, 'Osijek', 9, 1, 2),
(2, 'Zvonimir', 'Petričušić', 1, 'Posušje', 10, 1, 2),
(3, 'Tomislav', 'Periša', 1, 'Virovitica', 7, 1, 2),
(4, 'Josip', 'Matoković', 0, 'Virovitica', 8, 1, 2),
(5, 'Karlo', 'Nenadić', 1, 'Osijek', 9, 4, 3),
(6, 'Zvonimir', 'Petričušić', 1, 'Posušje', 10, 4, 3),
(7, 'Tomislav', 'Periša', 1, 'Virovitica', 7, 10, 3),
(8, 'Karlo', 'Nenadić', 1, 'Osijek', 9, 8, 4),
(9, 'Tomislav', 'Periša', 1, 'Virovitica', 7, 2, 2),
(10, 'Josip', 'Matoković', 0, 'Virovitica', 8, 10, 3),
(11, 'Zvonimir', 'Petričušić', 1, 'Posušje', 10, 10, 3),
(12, 'Tomislav', 'Periša', 1, 'Virovitica', 7, 6, 3),
(13, 'Karlo', 'Nenadić', 1, 'Osijek', 9, 3, 2),
(14, 'Zvonimir', 'Petričušić', 1, 'Posušje', 10, 5, 2),
(15, 'Tomislav', 'Periša', 1, 'Virovitica', 7, 9, 3),
(16, 'Karlo', 'Nenadić', 1, 'Osijek', 9, 7, 2);

-- --------------------------------------------------------

--
-- Table structure for table `prijava prihvacena`
--

CREATE TABLE `prijava prihvacena` (
  `id_prijava_prihvacena` int(11) NOT NULL,
  `potvrda_o_placanju` tinyint(1) NOT NULL,
  `racun` text NOT NULL,
  `id_prijava` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `prijava prihvacena`
--

INSERT INTO `prijava prihvacena` (`id_prijava_prihvacena`, `potvrda_o_placanju`, `racun`, `id_prijava`) VALUES
(1, 1, 'Molim vas uplatite 50 kn na racun broj \nHR 89 2484008 1102131080', 1),
(2, 1, 'Molim vas uplatite 50 kn na racun broj \nHR 89 2484008 1102131080', 2),
(3, 1, 'Molim vas uplatite 50 kn na racun broj \r\nHR 89 2484008 1102131080', 3),
(4, 1, 'Molim vas uplatite 30 kn na racun broj \r\nHR 89 2484008 1102131080', 5),
(5, 1, 'Molim vas uplatite 30 kn na racun broj \r\nHR 89 2484008 1102131080', 6),
(6, 1, 'Molim vas uplatite 20 kn na racun broj \nHR 89 2484008 1102131080', 7),
(7, 1, 'Molim vas uplatite 20 kn na racun broj \r\nHR 89 2484008 1102131080', 9),
(8, 0, 'Nije potrebna uplata za utrku', 8),
(9, 0, 'Nije potrebna uplata za utrku', 11),
(10, 0, 'Nije potrebna uplata za utrku', 12),
(11, 1, 'Molim vas uplatite 50 kn na racun broj \r\nHR 89 2484008 1102131080', 13),
(12, 0, 'Nije potrebna uplata za utrku', 14),
(13, 0, 'Nije potrebna uplata za utrku', 15),
(14, 1, 'Molim vas uplatite 50 kn na racun broj \r\nHR 89 2484008 1102131080', 16);

-- --------------------------------------------------------

--
-- Table structure for table `rezultati utrke`
--

CREATE TABLE `rezultati utrke` (
  `id_rezultat` int(11) NOT NULL,
  `datum_i_vrijeme_zavrsetka` datetime NOT NULL,
  `id_korisnik` int(11) NOT NULL,
  `id_utrka` int(11) NOT NULL,
  `id_moderator` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `rezultati utrke`
--

INSERT INTO `rezultati utrke` (`id_rezultat`, `datum_i_vrijeme_zavrsetka`, `id_korisnik`, `id_utrka`, `id_moderator`) VALUES
(1, '2020-04-30 16:00:00', 9, 1, 2),
(2, '2020-04-30 17:00:00', 10, 1, 2),
(3, '2020-04-30 17:08:00', 7, 1, 2),
(4, '2020-04-24 10:00:00', 9, 4, 3),
(5, '2020-04-24 10:11:00', 10, 4, 3),
(6, '2020-04-07 10:00:00', 7, 10, 3),
(7, '2020-05-02 09:00:00', 9, 8, 4),
(8, '2020-03-30 10:00:00', 7, 2, 2),
(9, '2020-04-07 12:00:00', 10, 10, 3),
(10, '2020-04-07 10:00:00', 7, 6, 2),
(11, '2020-04-29 15:28:00', 9, 3, 2),
(12, '2020-03-30 11:12:00', 10, 5, 2),
(13, '2020-04-28 07:00:00', 7, 9, 3),
(14, '2020-04-17 13:00:00', 9, 7, 2);

-- --------------------------------------------------------

--
-- Table structure for table `tip radnje`
--

CREATE TABLE `tip radnje` (
  `id_tip` int(11) NOT NULL,
  `naziv_radnje` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tip radnje`
--

INSERT INTO `tip radnje` (`id_tip`, `naziv_radnje`) VALUES
(1, 'prijava / odjava'),
(2, 'rad s bazom'),
(3, 'ostale radnje');

-- --------------------------------------------------------

--
-- Table structure for table `uloga`
--

CREATE TABLE `uloga` (
  `id_uloga` int(11) NOT NULL,
  `naziv` varchar(30) NOT NULL,
  `opis` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `uloga`
--

INSERT INTO `uloga` (`id_uloga`, `naziv`, `opis`) VALUES
(1, 'Administrator', 'Osoba odgovorna za provođenje funkcionalnosti ili organizacije aplikacije.'),
(2, 'Moderator', 'Osoba koja pregledava događaje radi postizanja dosljednosti, tj. nadzire odvijanje događaja.'),
(3, 'Korisnik', 'Osoba koja koristi uslugu stranice.');

-- --------------------------------------------------------

--
-- Table structure for table `utrka`
--

CREATE TABLE `utrka` (
  `id_utrka` int(11) NOT NULL,
  `naziv_utrke` varchar(45) NOT NULL,
  `startnina` int(11) NOT NULL,
  `broj_natjecatelja` int(11) NOT NULL,
  `vrijeme_pocetka` datetime NOT NULL,
  `id_biciklijada` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `utrka`
--

INSERT INTO `utrka` (`id_utrka`, `naziv_utrke`, `startnina`, `broj_natjecatelja`, `vrijeme_pocetka`, `id_biciklijada`) VALUES
(1, '2Fast', 50, 100, '2020-04-30 11:00:00', 5),
(2, 'Hrvatska – Slovenija @ Zagreb', 20, 300, '2020-03-30 06:00:00', 9),
(3, 'CRO Race', 50, 50, '2020-04-29 15:00:00', 2),
(4, 'BikeHill', 30, 40, '2020-04-24 07:00:00', 6),
(5, 'Nizinske trke', 0, 100, '2020-03-30 11:00:00', 9),
(6, 'Week OFF', 20, 400, '2020-04-19 07:00:00', 3),
(7, 'Big Race', 50, 50, '2020-04-17 11:00:00', 2),
(8, 'SeaSide Cycle', 0, 300, '2020-05-02 08:00:00', 1),
(9, 'Utrka u magli', 0, 30, '2020-04-28 06:00:00', 7),
(10, 'VN Varaždinske županije', 20, 400, '2020-04-07 08:30:00', 7);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `biciklijada`
--
ALTER TABLE `biciklijada`
  ADD PRIMARY KEY (`id_biciklijada`),
  ADD KEY `fk_biciklijada_korisnik1_idx` (`id_administrator`);

--
-- Indexes for table `dnevnik`
--
ALTER TABLE `dnevnik`
  ADD PRIMARY KEY (`id_dnevnik`,`id_korisnik`,`id_tip`),
  ADD KEY `fk_dnevnik_korisnik1_idx` (`id_korisnik`),
  ADD KEY `fk_dnevnik_tip_radnje1_idx` (`id_tip`);

--
-- Indexes for table `korisnik`
--
ALTER TABLE `korisnik`
  ADD PRIMARY KEY (`id_korisnik`),
  ADD UNIQUE KEY `korisnicko_ime_UNIQUE` (`korisnicko_ime`),
  ADD UNIQUE KEY `e-mail_UNIQUE` (`e-mail`),
  ADD KEY `fk_korisnik_uloga_idx` (`id_uloga`);

--
-- Indexes for table `lokacija`
--
ALTER TABLE `lokacija`
  ADD PRIMARY KEY (`id_lokacija`),
  ADD KEY `fk_lokacija_korisnik1_idx` (`id_administrator`);

--
-- Indexes for table `lokacija/biciklijada`
--
ALTER TABLE `lokacija/biciklijada`
  ADD PRIMARY KEY (`id_lokacija_biciklijada`,`id_biciklijada`,`id_lokacija`),
  ADD KEY `fk_biciklijada_has_lokacija_lokacija1_idx` (`id_lokacija`),
  ADD KEY `fk_biciklijada_has_lokacija_biciklijada1_idx` (`id_biciklijada`);

--
-- Indexes for table `moderator/lokacija`
--
ALTER TABLE `moderator/lokacija`
  ADD PRIMARY KEY (`id_moderator_lokacija`,`id_lokacija`,`id_moderator`),
  ADD KEY `fk_lokacija_has_korisnik_korisnik1_idx` (`id_moderator`),
  ADD KEY `fk_lokacija_has_korisnik_lokacija1_idx` (`id_lokacija`);

--
-- Indexes for table `odabir pobjednika`
--
ALTER TABLE `odabir pobjednika`
  ADD PRIMARY KEY (`id_pobjednik`),
  ADD KEY `fk_odabir pobjednika_korisnik1_idx` (`id_korisnik`),
  ADD KEY `fk_odabir pobjednika_korisnik2_idx` (`id_administrator`),
  ADD KEY `fk_odabir pobjednika_utrka1_idx` (`id_utrka`);

--
-- Indexes for table `prijava`
--
ALTER TABLE `prijava`
  ADD PRIMARY KEY (`id_prijava`,`id_korisnik`,`id_utrka`,`id_moderator`),
  ADD KEY `fk_prijava_korisnik1_idx` (`id_korisnik`),
  ADD KEY `fk_prijava_utrka1_idx` (`id_utrka`),
  ADD KEY `index4` (`id_moderator`);

--
-- Indexes for table `prijava prihvacena`
--
ALTER TABLE `prijava prihvacena`
  ADD PRIMARY KEY (`id_prijava_prihvacena`),
  ADD KEY `fk_prijava prihvacena_prijava1_idx` (`id_prijava`);

--
-- Indexes for table `rezultati utrke`
--
ALTER TABLE `rezultati utrke`
  ADD PRIMARY KEY (`id_rezultat`),
  ADD KEY `fk_rezultati utrke_korisnik1_idx` (`id_korisnik`),
  ADD KEY `fk_rezultati utrke_utrka1_idx` (`id_utrka`),
  ADD KEY `fk_rezultati utrke_korisnik2_idx` (`id_moderator`);

--
-- Indexes for table `tip radnje`
--
ALTER TABLE `tip radnje`
  ADD PRIMARY KEY (`id_tip`);

--
-- Indexes for table `uloga`
--
ALTER TABLE `uloga`
  ADD PRIMARY KEY (`id_uloga`),
  ADD UNIQUE KEY `naziv_UNIQUE` (`naziv`);

--
-- Indexes for table `utrka`
--
ALTER TABLE `utrka`
  ADD PRIMARY KEY (`id_utrka`),
  ADD KEY `fk_utrka_biciklijada1_idx` (`id_biciklijada`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `biciklijada`
--
ALTER TABLE `biciklijada`
  MODIFY `id_biciklijada` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `dnevnik`
--
ALTER TABLE `dnevnik`
  MODIFY `id_dnevnik` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `korisnik`
--
ALTER TABLE `korisnik`
  MODIFY `id_korisnik` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `lokacija`
--
ALTER TABLE `lokacija`
  MODIFY `id_lokacija` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `lokacija/biciklijada`
--
ALTER TABLE `lokacija/biciklijada`
  MODIFY `id_lokacija_biciklijada` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `moderator/lokacija`
--
ALTER TABLE `moderator/lokacija`
  MODIFY `id_moderator_lokacija` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `odabir pobjednika`
--
ALTER TABLE `odabir pobjednika`
  MODIFY `id_pobjednik` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `prijava`
--
ALTER TABLE `prijava`
  MODIFY `id_prijava` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `prijava prihvacena`
--
ALTER TABLE `prijava prihvacena`
  MODIFY `id_prijava_prihvacena` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `rezultati utrke`
--
ALTER TABLE `rezultati utrke`
  MODIFY `id_rezultat` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `tip radnje`
--
ALTER TABLE `tip radnje`
  MODIFY `id_tip` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `uloga`
--
ALTER TABLE `uloga`
  MODIFY `id_uloga` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `utrka`
--
ALTER TABLE `utrka`
  MODIFY `id_utrka` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `biciklijada`
--
ALTER TABLE `biciklijada`
  ADD CONSTRAINT `fk_biciklijada_korisnik1` FOREIGN KEY (`id_administrator`) REFERENCES `korisnik` (`id_korisnik`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `dnevnik`
--
ALTER TABLE `dnevnik`
  ADD CONSTRAINT `fk_dnevnik_korisnik1` FOREIGN KEY (`id_korisnik`) REFERENCES `korisnik` (`id_korisnik`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_dnevnik_tip_radnje1` FOREIGN KEY (`id_tip`) REFERENCES `tip radnje` (`id_tip`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `korisnik`
--
ALTER TABLE `korisnik`
  ADD CONSTRAINT `fk_korisnik_uloga` FOREIGN KEY (`id_uloga`) REFERENCES `uloga` (`id_uloga`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `lokacija`
--
ALTER TABLE `lokacija`
  ADD CONSTRAINT `fk_lokacija_korisnik1` FOREIGN KEY (`id_administrator`) REFERENCES `korisnik` (`id_korisnik`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `lokacija/biciklijada`
--
ALTER TABLE `lokacija/biciklijada`
  ADD CONSTRAINT `fk_biciklijada_has_lokacija_biciklijada1` FOREIGN KEY (`id_biciklijada`) REFERENCES `biciklijada` (`id_biciklijada`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_biciklijada_has_lokacija_lokacija1` FOREIGN KEY (`id_lokacija`) REFERENCES `lokacija` (`id_lokacija`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `moderator/lokacija`
--
ALTER TABLE `moderator/lokacija`
  ADD CONSTRAINT `fk_lokacija_has_korisnik_lokacija1` FOREIGN KEY (`id_lokacija`) REFERENCES `lokacija` (`id_lokacija`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_lokacija_has_korisnik_korisnik1` FOREIGN KEY (`id_moderator`) REFERENCES `korisnik` (`id_korisnik`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `odabir pobjednika`
--
ALTER TABLE `odabir pobjednika`
  ADD CONSTRAINT `fk_odabir pobjednika_korisnik1` FOREIGN KEY (`id_korisnik`) REFERENCES `korisnik` (`id_korisnik`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_odabir pobjednika_korisnik2` FOREIGN KEY (`id_administrator`) REFERENCES `korisnik` (`id_korisnik`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_odabir pobjednika_utrka1` FOREIGN KEY (`id_utrka`) REFERENCES `utrka` (`id_utrka`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `prijava`
--
ALTER TABLE `prijava`
  ADD CONSTRAINT `fk_prijava_korisnik1` FOREIGN KEY (`id_korisnik`) REFERENCES `korisnik` (`id_korisnik`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_prijava_utrka1` FOREIGN KEY (`id_utrka`) REFERENCES `utrka` (`id_utrka`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_prijava_1` FOREIGN KEY (`id_moderator`) REFERENCES `korisnik` (`id_korisnik`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `prijava prihvacena`
--
ALTER TABLE `prijava prihvacena`
  ADD CONSTRAINT `fk_prijava prihvacena_prijava1` FOREIGN KEY (`id_prijava`) REFERENCES `prijava` (`id_prijava`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `rezultati utrke`
--
ALTER TABLE `rezultati utrke`
  ADD CONSTRAINT `fk_rezultati utrke_korisnik1` FOREIGN KEY (`id_korisnik`) REFERENCES `korisnik` (`id_korisnik`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_rezultati utrke_utrka1` FOREIGN KEY (`id_utrka`) REFERENCES `utrka` (`id_utrka`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_rezultati utrke_korisnik2` FOREIGN KEY (`id_moderator`) REFERENCES `korisnik` (`id_korisnik`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `utrka`
--
ALTER TABLE `utrka`
  ADD CONSTRAINT `fk_utrka_biciklijada1` FOREIGN KEY (`id_biciklijada`) REFERENCES `biciklijada` (`id_biciklijada`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
