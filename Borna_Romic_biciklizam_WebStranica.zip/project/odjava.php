<?php
include './sesija.class.php';

Sesija::obrisiSesiju();
/*ini_set('session.gc_max_lifetime', 0);
ini_set('session.gc_probability', 1);
ini_set('session.gc_divisor', 1);*/
/*if (isset($_SESSION["uloga"]) && $_SESSION["uloga"] <4){
    $_SESSION["uloga"] = 4;
}*/
setcookie("prijava_sesija", "", time() - 1, '/');
header("Location: index.php");
?>