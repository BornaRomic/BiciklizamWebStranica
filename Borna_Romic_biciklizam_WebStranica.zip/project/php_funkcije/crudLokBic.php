<?php

$putanja = dirname($_SERVER["REQUEST_URI"], 2);
$direktorij = dirname(getcwd());
require '../zaglavlje.php';

if (!isset($_SESSION["uloga"]) || $_SESSION["uloga"] !== "1") {
    header("Location: ../obrasci/prijava.php");
    exit();
}
/*
  if (isset($_POST['save'])) {

  $bp = new Baza();
  $bp->spojiDB();

  $lokacijaId = $_POST['lokacijaId'];
  $mjesto = $_POST['mjesto'];
  $adresa = $_POST['adresa'];
  $adminId = $_POST['adminId'];

  $upitUpdate = "UPDATE lokacija SET mjesto='$mjesto', adresa='$adresa' WHERE id_lokacija='$lokacijaId'";
  $rezultat = $bp->selectDB($upitUpdate);
  $bp->updateDB($upitUpdate);
  $bp->zatvoriDB();
  }
 */
if (isset($_POST['spremi'])) {
    $bp = new Baza();
    $bp->spojiDB();

    $zauzeto = false;

    $lokacijaId = $_POST['lokacijaId'];
    $nazivBic = $_POST['nazivBic'];

    $upitKorisnik = "SELECT id_biciklijada FROM `biciklijada` WHERE naziv_biciklijade = '$nazivBic';";
    $rezultatispisa = $bp->selectDB($upitKorisnik);

    while ($redbroj = mysqli_fetch_array($rezultatispisa)) {
        if ($redbroj) {
            $idBic = $redbroj["id_biciklijada"];
        }
    }

    $upit = "SELECT * FROM `lokacija/biciklijada` WHERE id_biciklijada = '$idBic';";
    $rez = $bp->selectDB($upit);
    $rez = mysqli_fetch_array($rez);
    if ($rez == NULL) {
        $zauzeto = false;
    } else {
        $zauzeto = true;
    }

    if (!$zauzeto) {
        $upitNew = "insert into `lokacija/biciklijada` VALUES (default, '$idBic', '$lokacijaId');";
        $bp->updateDB($upitNew);
    }
    $bp->zatvoriDB();
}
if (isset($_POST['ukloni'])) {
    $bp = new Baza();
    $bp->spojiDB();

    $biciklijadaId = $_POST['biciklijadaId'];

    $upitObrisi = "DELETE FROM `lokacija/biciklijada` WHERE id_biciklijada = '$biciklijadaId'";
    $bp->updateDB($upitObrisi);
    $bp->zatvoriDB();
}
?>