<?php

$putanja = dirname($_SERVER["REQUEST_URI"], 2);
$direktorij = dirname(getcwd());
require '../zaglavlje.php';

if (!isset($_SESSION["uloga"]) || $_SESSION["uloga"] !== "1") {
    header("Location: ../obrasci/prijava.php");
    exit();
}


if (isset($_POST['save'])) {

    $bp = new Baza();
    $bp->spojiDB();

    $uloga = $_POST['uloga'];
    $ime = $_POST['ime'];
    $prezime = $_POST['prezime'];
    $godina = $_POST['godina'];
    $email = $_POST['email'];
    $korisnik = $_POST['korisnik'];
    $lozinka = $_POST['lozinka'];
    $status = $_POST['status'];
    $broj_prijava = $_POST['broj_prijava'];
    $id = $_POST['userId'];


    $upitUpdate = "UPDATE korisnik SET ime='$ime', prezime='$prezime', godina_rodenja='$godina', korisnicko_ime='$korisnik', email='$email', zaporka='$lozinka', status='$status', id_uloga='$uloga', broj_prijava='$broj_prijava' WHERE id_korisnik='$id'";
    $rezultat = $bp->selectDB($upitUpdate);
    $bp->updateDB($upitUpdate);
    $bp->zatvoriDB();
} 
if (isset($_POST['register'])) {
    $bp = new Baza();
    $bp->spojiDB();
    
    $dobar = true;
    $greska = "";
    $uspjeh = "";
    $zauzeto = false;

    $uloga = $_POST['uloga'];
    $ime = $_POST['ime'];
    $prezime = $_POST['prezime'];
    $godina = $_POST['godina'];
    $email = $_POST['email'];
    $korisnik = $_POST['korisnik'];
    $lozinka = $_POST['lozinka'];
    $status = $_POST['status'];
    $broj_prijava = $_POST['broj_prijava'];
    
    $upit = "select * from korisnik where email='$email' or korisnicko_ime='$korisnik'";
    $rez = $bp->selectDB($upit);
    $rez = mysqli_fetch_assoc($rez);
    if ($rez == NULL) {
        $zauzeto = false;
    } else {
        $zauzeto = true;
        $dobar = false;
    }
    
    if ($dobar) {
        if (!$zauzeto) {
            $uspjeh .= "Registracija uspješno obavljena.";
            $salt = '}#f4ga~g%7hjg4&j(7mk?/!bj30ab-wi\/Č=6^7-$^R9F|GK5J#E6WT;IO[JN';
            $crypt = sha1($salt . $lozinka);
            $upitNew = "insert into korisnik VALUES (default, '$ime', '$prezime', '$godina', '$korisnik', '$email', '$lozinka' ,'$crypt', NULL , '$status' ,'$uloga', '$broj_prijava');";
            //$captcha = $_POST['g-recaptcha-response'];
            /* if (!$captcha) {
              echo '<h2>Molimo, potvrdite da niste robot.</h2>';
              exit;
              } */
            $bp->updateDB($upitNew);
        }
    $bp->zatvoriDB();
    }
}

if (isset($_POST['obrisi'])) {
    echo '<script type="text/javascript">alert("hello!");</script>';
    $bp = new Baza();
    $bp->spojiDB();

    $uloga = $_POST['uloga'];
    $ime = $_POST['ime'];
    $prezime = $_POST['prezime'];
    $godina = $_POST['godina'];
    $email = $_POST['email'];
    $korisnik = $_POST['korisnik'];
    $lozinka = $_POST['lozinka'];
    $status = $_POST['status'];
    $broj_prijava = $_POST['broj_prijava'];
    $id = $_POST['userId'];

    $upitObrisi = "DELETE FROM korisnik WHERE korisnicko_ime = '$korisnik'";
    $bp->updateDB($upitObrisi);
    $bp->zatvoriDB();
} 



/*
  $veza = new Baza();
  $veza->spojiDB();

  $dohvatKorisnika = $_GET['upit'];
  $rez = $veza-selectDb($dohvatKorisnika);
  $veza->updateDB($dohvatKorisnika);
  $veza->zatvoriDB(); */

/*
  if (isset($_POST["action"])) {
  $bp = new Baza();
  $bp->spojiDB();
  if ($_POST["action"] === "create") {
  $upit2 = "UPDATE korisnik SET status = '1', broj_prijava = '0' WHERE korisnicko_ime = {$_POST["username"]}";
  } else if ($_POST["action"] === "update") {
  $upit2 = "UPDATE korisnik SET status = '1', broj_prijava = '0' WHERE korisnicko_ime = {$_POST["username"]}";
  } else if ($_POST["action"] === "delete") {
  $upit2 = "DELETE FROM korisnik WHERE id_korisnik = {$_POST["userId"]}";
  }
  $rezultat = $bp->selectDB($upit2);
  $bp->updateDB($upit2);
  $bp->zatvoriDB();

  exit();
  } else {
  echo "nothing to see here :)";
  }

  /*
  $korIme = $_POST['korIme'];

  $bp = new Baza();
  $bp->spojiDB();
  $upit2 = "UPDATE korisnik SET status = '1', broj_prijava = '0' WHERE korisnicko_ime = '$korIme'";
  if($upit2){
  echo "Uspjeg";
  echo "$korIme";
  } else
  echo "neusphej";
 */
/*
  $trazeniKor = $_POST["trazeniKor"];

  if (isset($_POST["submit"])) {
  $bp = new Baza();
  $bp->spojiDB();
  $upit2 = "UPDATE korisnik SET status = '1', broj_prijava = '0' WHERE korisnicko_ime = '$trazeniKor'";
  $bp->updateDB($upit2);
  $bp->zatvoriDB();

  exit();
  } */
?>