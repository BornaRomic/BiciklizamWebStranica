<?php

$putanja = dirname($_SERVER["REQUEST_URI"], 2);
$direktorij = dirname(getcwd());
require '../zaglavlje.php';

if (!isset($_SESSION["uloga"]) || $_SESSION["uloga"] !== "1") {
    header("Location: ../obrasci/prijava.php");
    exit();
}

if (isset($_POST['spremi'])) {
    $bp = new Baza();
    $bp->spojiDB();

    $dobar = true;
    $greska = "";
    $uspjeh = "";
    $zauzeto = false;

    $utrkaId = $_POST['utrkaId'];
    $korisnikId = $_POST['korisnikId'];
    $textVeliki = $_POST['textVeliki'];
    
    $korIme = Sesija::dajKorisnika();

    $upitKorisnik = "SELECT id_korisnik FROM `korisnik` WHERE korisnicko_ime = '{$korIme['korisnik']}';";
    $rezultatispisa = $bp->selectDB($upitKorisnik);
    
    while ($redbroj = mysqli_fetch_array($rezultatispisa)) {
        if ($redbroj) {
            $korId = $redbroj["id_korisnik"];
        }
    }

    $upitNew = "insert into `odabir pobjednika` VALUES (default, '$textVeliki', '$korisnikId', '$korId', '$utrkaId');";

    $bp->updateDB($upitNew);

    $bp->zatvoriDB();
}
?>