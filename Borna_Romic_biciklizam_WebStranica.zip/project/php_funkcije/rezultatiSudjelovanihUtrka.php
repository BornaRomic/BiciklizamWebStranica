<?php

$putanja = dirname($_SERVER["REQUEST_URI"], 2);
$direktorij = dirname(getcwd());
require '../zaglavlje.php';

$bp = new Baza();
$bp->spojiDB();

$korIme = $_GET["korime"];



$upit = "SELECT b.naziv_biciklijade, u.naziv_utrke, u.id_utrka, r.datum_i_vrijeme_zavrsetka, op.id_korisnik, k.dozvola_slika FROM  `biciklijada` b INNER JOIN `utrka` u ON b.id_biciklijada = u.id_biciklijada
INNER JOIN `rezultati utrke` r ON r.id_utrka=u.id_utrka
INNER JOIN `korisnik` k ON r.id_korisnik = k.id_korisnik
INNER JOIN `odabir pobjednika` op ON op.id_utrka = r.id_utrka
WHERE k.korisnicko_ime = '{$korIme}'
ORDER BY b.naziv_biciklijade;";
$rezultat = $bp->selectDB($upit);
$data = $rezultat->fetch_all(MYSQLI_ASSOC);
$bp->zatvoriDB();

$json_object = (object) array();
$json_object->users = $data;
echo json_encode($data);
?>