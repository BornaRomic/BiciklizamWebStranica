<?php

$putanja = dirname($_SERVER['REQUEST_URI'], 2);
$direktorij = dirname(getcwd());

require '../zaglavlje.php';



if (isset($_GET['prijava'])) {
    $veza = new Baza();
    $veza->spojiDB();

    $email = $_GET['email'];

    $alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
    $pass = array(); //remember to declare $pass as an array
    $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
    for ($i = 0; $i < 8; $i++) {
        $n = rand(0, $alphaLength);
        $pass[] = $alphabet[$n];
    }
    $novi = implode($pass);

    $upitUpdate = "UPDATE `korisnik` SET zaporka='$novi' WHERE email='$email'";
    $rezultat = $veza->selectDB($upitUpdate);
    $veza->updateDB($upitUpdate);

    $mail_to = $email;
    $mail_from = "From: WebDiP2019@foi.unizg.hr";
    $mail_subject = "Novi password";
    $mail_body = "Vas novi password je: '{$novi}'";
    mail($mail_to, $mail_subject, $mail_body, $mail_from);

    $veza->zatvoriDB();
    header("Location: ../obrasci/prijava.php");
}
?>
