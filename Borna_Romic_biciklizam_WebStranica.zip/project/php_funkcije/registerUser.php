<?php

$putanja = dirname($_SERVER['REQUEST_URI'], 2);
$direktorij = dirname(getcwd());

require '../zaglavlje.php';


if (isset($_POST['register'])) {
    $bp = new Baza();
    $bp->spojiDB();

    $dobar = true;
    $greska = "";
    $uspjeh = "";
    $zauzeto = false;

    $ime = $_POST['ime'];
    $prezime = $_POST['prezime'];
    $korIme = $_POST['korIme'];
    $godina = $_POST['godina'];
    $email = $_POST['email'];
    $lozinka = $_POST['lozinka'];
    $lozinka2 = $_POST['lozinka2'];

    echo "<script>alert('$korIme');</script>";

    $prviIme = $ime[0];
    $prviPrezime = $prezime[0];

    if (ctype_upper($prviIme) === false) {
        $greska = "Prvo slovo imena nije veliko";
    }
    if (ctype_upper($prviPrezime) === false) {
        $greska = "Prvo slovo prezimena nije veliko";
    }

    if (strlen($korIme) < 5) {
        $greska .= "Korisničko ime mora biti duže od 5 znakova";
    }

    if (strlen($godina) === 0) {
        $greska .= "Godina mora biti unesena";
    }

    if (!preg_match('/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/', $email)) {
        $greska .= "Email nije dobrog formata";
    }

    if (!preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.{8,})/', $lozinka)) {
        $greska .= "Lozinka nije dobrog formata";
    }


    if (strcmp($lozinka, $lozinka2) !== 0) {
        $greska .= "Lozinke moraju biti iste";
    }


    if ($greska === "") {
        $upit = "select * from korisnik where email='$email' or korisnicko_ime='$korIme'";
        $rez = $bp->selectDB($upit);
        $rez = mysqli_fetch_assoc($rez);
        if ($rez == NULL) {
            $zauzeto = false;
        } else {
            $zauzeto = true;
            $dobar = false;
        }

        if ($dobar) {
            if (!$zauzeto) {

                $uspjeh .= "Registracija uspješno obavljena.";
                $salt = '}#f4ga~g%7hjg4&j(7mk?/!bj30ab-wi\/Č=6^7-$^R9F|GK5J#E6WT;IO[JN';
                $crypt = sha1($salt . $lozinka);
                //$captcha = $_POST['g-recaptcha-response'];
                /* if (!$captcha) {
                  echo '<h2>Molimo, potvrdite da niste robot.</h2>';
                  exit;
                  } */

                $alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
                $pass = array(); //remember to declare $pass as an array
                $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
                for ($i = 0; $i < 8; $i++) {
                    $n = rand(0, $alphaLength);
                    $pass[] = $alphabet[$n];
                }
                $novi = implode($pass);

                $upitNew = "insert into korisnik VALUES (default, '$ime', '$prezime', '$godina', '$korIme', '$email', '$lozinka' ,'$crypt', NULL , '0', '$novi', '3', '0', '0');";

                $mail_to = $email;
                $mail_from = "From: WebDiP2019@foi.unizg.hr";
                $mail_subject = "Aktivacija računa";
                $mail_body = "Vas novi aktivacijski kod je: '{$novi}'";
                mail($mail_to, $mail_subject, $mail_body, $mail_from);

                $bp->updateDB($upitNew);
            }
        }
    }
    $bp->zatvoriDB();
}

if (isset($_POST['aktiviraj'])) {
    $bp = new Baza();
    $bp->spojiDB();


    $aktKod = $_POST['aktKod'];

    $upitUpdate = "UPDATE `korisnik` SET status='1' WHERE aktivacijski_kod='$aktKod'";
    $rezultat = $bp->selectDB($upitUpdate);
    $bp->updateDB($upitUpdate);
    $bp->zatvoriDB();
}
?>

