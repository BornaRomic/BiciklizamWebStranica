<?php

$putanja = dirname($_SERVER["REQUEST_URI"], 2);
$direktorij = dirname(getcwd());
require '../zaglavlje.php';

$bp = new Baza();
$bp->spojiDB();

$korIme = $_POST["korime"];

$upitKorisnik = "SELECT id_korisnik FROM `korisnik` WHERE korisnicko_ime = '$korIme';";
$rezultatispisa = $bp->selectDB($upitKorisnik);

while ($redbroj = mysqli_fetch_assoc($rezultatispisa)) {
    if ($redbroj) {
        $korId = $redbroj["id_korisnik"];
    }
}


$upit = "SELECT u.id_utrka, u.naziv_utrke, u.kraj_utrke, b.vrijeme_zavrsetka, ml.id_moderator FROM `utrka` u LEFT JOIN `biciklijada` b ON b.id_biciklijada = u.id_biciklijada LEFT JOIN `lokacija/biciklijada` lb ON lb.id_biciklijada = b.id_biciklijada LEFT JOIN `moderator/lokacija` ml ON ml.id_lokacija = lb.id_lokacija 
WHERE ml.id_moderator = '$korId'
ORDER BY u.kraj_utrke, b.vrijeme_zavrsetka";
$rezultat = $bp->selectDB($upit);
$data = $rezultat->fetch_all(MYSQLI_ASSOC);
$bp->zatvoriDB();

$json_object = (object) array();
$json_object->users = $data;
echo json_encode($data);
?>

