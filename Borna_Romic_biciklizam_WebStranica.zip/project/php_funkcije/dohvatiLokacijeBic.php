<?php

$putanja = dirname($_SERVER["REQUEST_URI"], 2);
$direktorij = dirname(getcwd());
require '../zaglavlje.php';

$bp = new Baza();
$bp->spojiDB();
$upit = "SELECT l.id_lokacija, l.mjesto, l.adresa, l.id_administrator, COUNT(lb.id_lokacija) AS 'broj_biciklijada' FROM `lokacija` l 
LEFT JOIN `lokacija/biciklijada` lb ON l.id_lokacija = lb.id_lokacija
GROUP BY l.id_lokacija";
$rezultat = $bp->selectDB($upit);
$data = $rezultat->fetch_all(MYSQLI_ASSOC);
$bp->zatvoriDB();

$json_object = (object)array();
$json_object -> users = $data;
echo json_encode($data);
?>

