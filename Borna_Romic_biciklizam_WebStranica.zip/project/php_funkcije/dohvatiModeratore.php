<?php

$putanja = dirname($_SERVER["REQUEST_URI"], 2);
$direktorij = dirname(getcwd());
require '../zaglavlje.php';

$bp = new Baza();
$bp->spojiDB();


$lokacijaId = $_POST['lokacijaId'];

$upit = "SELECT ml.id_lokacija, ml.id_moderator, k.ime, k.prezime, k.email, k.korisnicko_ime, k.id_korisnik FROM korisnik k
INNER JOIN `moderator/lokacija` ml ON ml.id_moderator = k.id_korisnik
WHERE ml.id_lokacija = '$lokacijaId'";
$rezultat = $bp->selectDB($upit);
$data = $rezultat->fetch_all(MYSQLI_ASSOC);
$bp->zatvoriDB();

$json_object = (object)array();
$json_object -> users = $data;
echo json_encode($data);
?>

