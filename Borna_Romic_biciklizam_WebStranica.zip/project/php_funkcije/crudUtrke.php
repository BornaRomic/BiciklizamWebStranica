<?php

$putanja = dirname($_SERVER["REQUEST_URI"], 2);
$direktorij = dirname(getcwd());
require '../zaglavlje.php';

if (!isset($_SESSION["uloga"]) || $_SESSION["uloga"] !== "1") {
    header("Location: ../obrasci/prijava.php");
    exit();
}
if (isset($_POST['azuriraj'])) {

    $bp = new Baza();
    $bp->spojiDB();

    $utrkaId = $_POST['utrkaId'];
    $nazivUtr = $_POST['nazivUtr'];
    $utrkaPoc = $_POST['utrkaPoc'];
    $utrkaBroj = $_POST['utrkaBroj'];
    $utrkaStart = $_POST['utrkaStart'];

    $upitUpdate = "UPDATE utrka SET naziv_utrke='$nazivUtr', startnina='$utrkaStart', broj_natjecatelja = '$utrkaBroj', vrijeme_pocetka='$utrkaPoc' WHERE id_utrka='$utrkaId'";
    $rezultat = $bp->selectDB($upitUpdate);
    $bp->updateDB($upitUpdate);
    $bp->zatvoriDB();
}

if (isset($_POST['spremi'])) {
    $bp = new Baza();
    $bp->spojiDB();

    $dobar = true;
    $greska = "";
    $uspjeh = "";
    $zauzeto = false;

    $biciklijadaId = $_POST['biciklijadaId'];
    $nazivUtr = $_POST['nazivUtr'];
    $utrkaPoc = $_POST['utrkaPoc'];
    $utrkaBroj = $_POST['utrkaBroj'];
    $utrkaStart = $_POST['utrkaStart'];

    $korIme = Sesija::dajKorisnika();

    

    $upit = "select * from utrka where naziv_utrke='$nazivUtr'";
    $rez = $bp->selectDB($upit);
    $rez = mysqli_fetch_assoc($rez);
    if ($rez == NULL) {
        $zauzeto = false;
    } else {
        $zauzeto = true;
        $dobar = false;
    }

    if ($dobar && $nazivUtr != "" && $utrkaPoc != "" && $utrkaBroj != "" && $utrkaStart != "") {
        if (!$zauzeto) {
            $uspjeh .= "Unos utrke uspjesan.";
            $upitNew = "insert into utrka VALUES (default, '$nazivUtr', '$utrkaStart', '$utrkaBroj', '$utrkaPoc', '$biciklijadaId', '0');";

            $bp->updateDB($upitNew);
        }
        $bp->zatvoriDB();
    }
}
if (isset($_POST['ukloni'])) {
    $bp = new Baza();
    $bp->spojiDB();

    $utrkaId = $_POST['utrkaId'];

    
    $upitObrisi = "DELETE FROM utrka WHERE id_utrka = '$utrkaId'";
    $bp->updateDB($upitObrisi);
    $bp->zatvoriDB();
}
?>