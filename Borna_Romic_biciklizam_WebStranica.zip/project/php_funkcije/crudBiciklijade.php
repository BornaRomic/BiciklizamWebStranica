<?php

$putanja = dirname($_SERVER["REQUEST_URI"], 2);
$direktorij = dirname(getcwd());
require '../zaglavlje.php';

if (!isset($_SESSION["uloga"]) || $_SESSION["uloga"] !== "1") {
    header("Location: ../obrasci/prijava.php");
    exit();
}

if (isset($_POST['save'])) {

    $bp = new Baza();
    $bp->spojiDB();

    $biciklijadaId = $_POST['biciklijadaId'];
    $nazivBic = $_POST['nazivBic'];
    $vrijemePoc = $_POST['vrijemePoc'];
    $vrijemeZav = $_POST['vrijemeZav'];

    $upitUpdate = "UPDATE biciklijada SET naziv_biciklijade='$nazivBic', vrijeme_pocetka='$vrijemePoc', vrijeme_zavrsetka='$vrijemeZav' WHERE id_biciklijada='$biciklijadaId'";
    $rezultat = $bp->selectDB($upitUpdate);
    $bp->updateDB($upitUpdate);
    $bp->zatvoriDB();
}
if (isset($_POST['register'])) {
    $bp = new Baza();
    $bp->spojiDB();

    $dobar = true;
    $greska = "";
    $uspjeh = "";
    $zauzeto = false;

    $biciklijadaId = $_POST['biciklijadaId'];
    $nazivBic = $_POST['nazivBic'];
    $vrijemePoc = $_POST['vrijemePoc'];
    $vrijemeZav = $_POST['vrijemeZav'];

    $korIme = Sesija::dajKorisnika();

    $upitKorisnik = "SELECT id_korisnik FROM `korisnik` WHERE korisnicko_ime = '{$korIme['korisnik']}';";
    $rezultatispisa = $bp->selectDB($upitKorisnik);

    while ($redbroj = mysqli_fetch_array($rezultatispisa)) {
        if ($redbroj) {
            $korId = $redbroj["id_korisnik"];
        }
    }

    $upit = "select * from biciklijada where naziv_biciklijade='$nazivBic'";
    $rez = $bp->selectDB($upit);
    $rez = mysqli_fetch_assoc($rez);
    if ($rez == NULL) {
        $zauzeto = false;
    } else {
        $zauzeto = true;
        $dobar = false;
    }

    if ($dobar && $nazivBic != "" && $vrijemePoc != "" && $vrijemeZav != "") {
        if (!$zauzeto) {
            $uspjeh .= "Unos biciklijade uspjesan.";
            $upitNew = "insert into biciklijada VALUES (default, '$nazivBic', '$vrijemePoc', '$vrijemeZav', '$korId');";

            $bp->updateDB($upitNew);
        }
        $bp->zatvoriDB();
    }
}
if (isset($_POST['obrisi'])) {
    $bp = new Baza();
    $bp->spojiDB();

    $biciklijadaId = $_POST['biciklijadaId'];


    $upitUkloniMod = "DELETE FROM `lokacija/biciklijada` WHERE id_biciklijada = '$biciklijadaId';";
    $bp->updateDB($upitUkloniMod);
    $upitObrisi = "DELETE FROM biciklijada WHERE id_biciklijada = '$biciklijadaId'";
    $bp->updateDB($upitObrisi);
    $bp->zatvoriDB();
}
?>