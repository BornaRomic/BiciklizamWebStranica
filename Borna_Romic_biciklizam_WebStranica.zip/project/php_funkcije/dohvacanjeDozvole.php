<?php

$putanja = dirname($_SERVER["REQUEST_URI"], 2);
$direktorij = dirname(getcwd());
require '../zaglavlje.php';

$bp = new Baza();
$bp->spojiDB();

$korIme = $_GET["korime"];



$upit = "SELECT dozvola_slika from `korisnik`
WHERE korisnicko_ime = '{$korIme}'";
$rezultat = $bp->selectDB($upit);
$data = $rezultat->fetch_all(MYSQLI_ASSOC);
$bp->zatvoriDB();

$json_object = (object) array();
$json_object->users = $data;
echo json_encode($data);
?>