<?php

$putanja = dirname($_SERVER["REQUEST_URI"], 2);
$direktorij = dirname(getcwd());
require '../zaglavlje.php';

if (!isset($_SESSION["uloga"]) || $_SESSION["uloga"] !== "1") {
    header("Location: ../obrasci/prijava.php");
    exit();
}

if (isset($_POST['save'])) {

    $bp = new Baza();
    $bp->spojiDB();

    $lokacijaId = $_POST['lokacijaId'];
    $mjesto = $_POST['mjesto'];
    $adresa = $_POST['adresa'];
    $adminId = $_POST['adminId'];

    $upitUpdate = "UPDATE lokacija SET mjesto='$mjesto', adresa='$adresa' WHERE id_lokacija='$lokacijaId'";
    $rezultat = $bp->selectDB($upitUpdate);
    $bp->updateDB($upitUpdate);
    $bp->zatvoriDB();
} 

if (isset($_POST['register'])) {
    $bp = new Baza();
    $bp->spojiDB();
    
    $dobar = true;
    $greska = "";
    $uspjeh = "";
    $zauzeto = false;

    $lokacijaId = $_POST['lokacijaId'];
    $mjesto = $_POST['mjesto'];
    $adresa = $_POST['adresa'];
    $adminId = $_POST['adminId'];
    
    $korIme = Sesija::dajKorisnika();

    $upitKorisnik = "SELECT id_korisnik FROM `korisnik` WHERE korisnicko_ime = '{$korIme['korisnik']}';";
    $rezultatispisa = $bp->selectDB($upitKorisnik);
    
    while ($redbroj = mysqli_fetch_array($rezultatispisa)) {
        if ($redbroj) {
            $korId = $redbroj["id_korisnik"];
        }
    }
    
    $upit = "select * from lokacija where mjesto='$mjesto'";
    $rez = $bp->selectDB($upit);
    $rez = mysqli_fetch_assoc($rez);
    if ($rez == NULL) {
        $zauzeto = false;
    } else {
        $zauzeto = true;
        $dobar = false;
    }
    
    if ($dobar && $mjesto != "" && $adresa != "") {
        if (!$zauzeto) {
            $uspjeh .= "Registracija uspješno obavljena.";
            $upitNew = "insert into lokacija VALUES (default, '$mjesto', '$adresa', '$korId');";
            
            $bp->updateDB($upitNew);
        }
    $bp->zatvoriDB();
    }
}
if (isset($_POST['obrisi'])) {
    $bp = new Baza();
    $bp->spojiDB();

    $lokacijaId = $_POST['lokacijaId'];
    
    $upitUkloniMod = "DELETE FROM `moderator/lokacija` WHERE id_lokacija = '$lokacijaId';";
    $bp->updateDB($upitUkloniMod);
    $upitObrisi = "DELETE FROM lokacija WHERE id_lokacija = '$lokacijaId'";
    $bp->updateDB($upitObrisi);
    $bp->zatvoriDB();
}
?>