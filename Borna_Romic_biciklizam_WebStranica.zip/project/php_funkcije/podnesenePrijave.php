<?php

$putanja = dirname($_SERVER["REQUEST_URI"], 2);
$direktorij = dirname(getcwd());
require '../zaglavlje.php';

$bp = new Baza();
$bp->spojiDB();

$korIme = $_GET["korime"];


$upit = "SELECT u.id_utrka, u.naziv_utrke, u.vrijeme_pocetka, p.id_prijava, p.prijava_prihvacena, k.korisnicko_ime, pp.potvrda_o_placanju, pp.racun, b.vrijeme_zavrsetka FROM `utrka` u INNER JOIN
`prijava` p ON u.id_utrka = p.id_utrka 
INNER JOIN `korisnik` k on p.id_korisnik = k.id_korisnik
INNER JOIN `prijava prihvacena` pp ON p.id_prijava = pp.id_prijava
INNER JOIN `biciklijada` b ON u.id_biciklijada = b.id_biciklijada
WHERE k.korisnicko_ime = '{$korIme}' ORDER BY u.id_utrka";
$rezultat = $bp->selectDB($upit);
$data = $rezultat->fetch_all(MYSQLI_ASSOC);
$bp->zatvoriDB();

$json_object = (object)array();
$json_object -> users = $data;
echo json_encode($data);

?>

