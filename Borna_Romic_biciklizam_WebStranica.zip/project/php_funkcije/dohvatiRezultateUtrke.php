<?php

$putanja = dirname($_SERVER["REQUEST_URI"], 2);
$direktorij = dirname(getcwd());
require '../zaglavlje.php';

$bp = new Baza();
$bp->spojiDB();


$utrkaId = $_POST['utrkaId'];

$upit = "SELECT r.id_rezultat, r.datum_i_vrijeme_zavrsetka, r.id_korisnik, k.ime, k.prezime, k.korisnicko_ime FROM `rezultati utrke` r INNER JOIN `korisnik` k ON r.id_korisnik = k.id_korisnik WHERE r.id_utrka = '$utrkaId' AND r.odustao = '0'"
        . "ORDER BY r.datum_i_vrijeme_zavrsetka";
$rezultat = $bp->selectDB($upit);
$data = $rezultat->fetch_all(MYSQLI_ASSOC);
$bp->zatvoriDB();

$json_object = (object)array();
$json_object -> users = $data;
echo json_encode($data);
?>

