<?php

$putanja = dirname($_SERVER["REQUEST_URI"], 2);
$direktorij = dirname(getcwd());
require '../zaglavlje.php';

$bp = new Baza();
$bp->spojiDB();
$upit= "SELECT u.id_utrka, u.naziv_utrke, u.broj_natjecatelja, u.vrijeme_pocetka, b.naziv_biciklijade, l.mjesto, l.id_lokacija FROM `utrka` u
INNER JOIN `biciklijada` b ON b.id_biciklijada = u.id_biciklijada 
INNER JOIN `lokacija/biciklijada` lb on lb.id_biciklijada = b.id_biciklijada 
INNER JOIN `lokacija` l on l.id_lokacija = lb.id_lokacija 
GROUP BY u.id_utrka
ORDER BY u.vrijeme_pocetka";
$rezultat = $bp->selectDB($upit);
$data = $rezultat->fetch_all(MYSQLI_ASSOC);
$bp->zatvoriDB();

$json_object = (object)array();
$json_object -> users = $data;
echo json_encode($data);
?>

