<?php

$putanja = dirname($_SERVER["REQUEST_URI"], 2);
$direktorij = dirname(getcwd());
require '../zaglavlje.php';


if (isset($_POST['odustaniUtr'])) {

    $bp = new Baza();
    $bp->spojiDB();
    $zauzeto = false;
    $utrkaIdO = $_POST['utrkaIdO'];
    $razlog = $_POST['razlog'];
    $korIme = $_POST['korime'];

    $upitKorisnik = "SELECT id_korisnik FROM `korisnik` WHERE korisnicko_ime = '{$korIme}';";
    $rezultatispisa = $bp->selectDB($upitKorisnik);

    while ($redbroj = mysqli_fetch_array($rezultatispisa)) {
        if ($redbroj) {
            $korId = $redbroj["id_korisnik"];
        }
    }
    
    $upit = "select * from `rezultati utrke` where id_korisnik='$korId' AND id_utrka='$utrkaIdO'";
    $rez = $bp->selectDB($upit);
    $rez = mysqli_fetch_assoc($rez);
    if ($rez == NULL) {
        $zauzeto = false;
    } else {
        $zauzeto = true;
    }
    if($zauzeto === false){
    $upitUpdate = "INSERT INTO `rezultati utrke` VALUES (default, 'null', '1', '$razlog', '$korId', '$utrkaIdO', '2')";
    $rezultat = $bp->selectDB($upitUpdate);
    }
    $bp->zatvoriDB();
}

?>