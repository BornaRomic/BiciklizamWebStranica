<?php

$putanja = dirname($_SERVER["REQUEST_URI"], 2);
$direktorij = dirname(getcwd());
require '../zaglavlje.php';

$bp = new Baza();
$bp->spojiDB();
$upit = "SELECT b.id_biciklijada, b.naziv_biciklijade, b.vrijeme_pocetka, b.vrijeme_zavrsetka, b.id_administrator, COUNT(u.id_biciklijada) AS 'broj_utrka' FROM `biciklijada` b 
LEFT JOIN `utrka` u ON b.id_biciklijada = u.id_biciklijada
GROUP BY b.id_biciklijada";
$rezultat = $bp->selectDB($upit);
$data = $rezultat->fetch_all(MYSQLI_ASSOC);
$bp->zatvoriDB();

$json_object = (object)array();
$json_object -> users = $data;
echo json_encode($data);
?>

