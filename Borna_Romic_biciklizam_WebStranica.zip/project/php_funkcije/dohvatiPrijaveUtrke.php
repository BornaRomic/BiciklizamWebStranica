<?php

$putanja = dirname($_SERVER["REQUEST_URI"], 2);
$direktorij = dirname(getcwd());
require '../zaglavlje.php';

$bp = new Baza();
$bp->spojiDB();

$utrkaId = $_POST['utrkaId'];

$upit= "SELECT p.id_prijava, p.ime, p.prezime, p.prijava_prihvacena, p.id_korisnik, p.mjesto, p.id_utrka, u.id_utrka, u.naziv_utrke FROM `prijava` p 
INNER JOIN `utrka` u ON u.id_utrka = p.id_utrka
WHERE p.id_utrka = '$utrkaId'";
$rezultat = $bp->selectDB($upit);
$data = $rezultat->fetch_all(MYSQLI_ASSOC);
$bp->zatvoriDB();

$json_object = (object)array();
$json_object -> users = $data;
echo json_encode($data);
?>

