<?php

$putanja = dirname($_SERVER["REQUEST_URI"], 2);
$direktorij = dirname(getcwd());
require '../zaglavlje.php';

$bp = new Baza();
$bp->spojiDB();
$upit= "SELECT l.mjesto, b.naziv_biciklijade, u.id_utrka, u.naziv_utrke, u.vrijeme_pocetka FROM  `lokacija` l INNER JOIN `lokacija/biciklijada` lb ON 
lb.id_lokacija = l.id_lokacija INNER JOIN `biciklijada` b ON
b.id_biciklijada = lb.id_biciklijada INNER JOIN `utrka` u ON
b.id_biciklijada = u.id_biciklijada ORDER BY l.mjesto;";
$rezultat = $bp->selectDB($upit);
$data = $rezultat->fetch_all(MYSQLI_ASSOC);
$bp->zatvoriDB();

$json_object = (object)array();
$json_object -> users = $data;
echo json_encode($data);
?>

