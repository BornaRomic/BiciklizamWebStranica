<?php

$putanja = dirname($_SERVER["REQUEST_URI"], 2);
$direktorij = dirname(getcwd());
require '../zaglavlje.php';

$bp = new Baza();
$bp->spojiDB();

$lokacijaId = $_POST['lokacijaId'];

$upit = "SELECT b.id_biciklijada, b.naziv_biciklijade, b.vrijeme_pocetka, b.vrijeme_zavrsetka FROM `biciklijada` b 
INNER JOIN `lokacija/biciklijada` lb ON b.id_biciklijada = lb.id_biciklijada WHERE lb.id_lokacija = '$lokacijaId'
GROUP BY b.id_biciklijada";

$rezultat = $bp->selectDB($upit);
$data = $rezultat->fetch_all(MYSQLI_ASSOC);
$bp->zatvoriDB();

$json_object = (object)array();
$json_object -> users = $data;
echo json_encode($data);
?>

