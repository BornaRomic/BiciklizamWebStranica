<?php

$putanja = dirname($_SERVER["REQUEST_URI"], 2);
$direktorij = dirname(getcwd());
require '../zaglavlje.php';

if (!isset($_SESSION["uloga"]) || $_SESSION["uloga"] > "2") {
    header("Location: ../obrasci/prijava.php");
    exit();
}
if (isset($_POST['zavrsi'])) {

    $bp = new Baza();
    $bp->spojiDB();

    $utrkaId = $_POST['utrkaId'];
    $utrkaStat = $_POST['utrkaStat'];

    $upitUpdate = "UPDATE `utrka` SET kraj_utrke='1' WHERE id_utrka='$utrkaId'";
    $rezultat = $bp->selectDB($upitUpdate);
    $bp->updateDB($upitUpdate);
    $bp->zatvoriDB();
}
if (isset($_POST['zapocni'])) {

    $bp = new Baza();
    $bp->spojiDB();

    $utrkaId = $_POST['utrkaId'];
    $utrkaStat = $_POST['utrkaStat'];

    $upitUpdate = "UPDATE `utrka` SET kraj_utrke='0' WHERE id_utrka='$utrkaId'";
    $rezultat = $bp->selectDB($upitUpdate);
    $bp->updateDB($upitUpdate);
    $bp->zatvoriDB();
}
if (isset($_POST['spremi'])) {
    $bp = new Baza();
    $bp->spojiDB();

    $zauzeto = false;
    $zauzeto2 = false;


    $utrkaId = $_POST['utrkaId'];
    $korIme = $_POST['korisnikRac'];
    $vrijemeZ = $_POST['vrijemeZ'];

    
    
    $upitKorisnik = "SELECT id_korisnik FROM `korisnik` WHERE korisnicko_ime = '$korIme';";
    $rezultatispisa = $bp->selectDB($upitKorisnik);
    
    while ($redbroj = mysqli_fetch_array($rezultatispisa)) {
        if ($redbroj) {
            $korId = $redbroj["id_korisnik"];
        }
    }
    $korisnik = $_POST["korime"];

    $upitKorisnik = "SELECT id_korisnik FROM `korisnik` WHERE korisnicko_ime = '$korIme';";
    $rezultatispisa = $bp->selectDB($upitKorisnik);

    while ($redbroj = mysqli_fetch_assoc($rezultatispisa)) {
        if ($redbroj) {
            $modId = $redbroj["id_korisnik"];
        }
    }
/*
    $upit = "select * from `rezultati utrke` where id_utrka='$utrkaId' AND id_korisnik = '$korId'";
    $rez = $bp->selectDB($upit);
    while ($redbroj = mysqli_fetch_assoc($rez)) {
        if ($redbroj) {
            $odustao = $redbroj["odustao"];
        }
    }
    */
    $upit = "select * from `rezultati utrke` where id_utrka='$utrkaId' AND id_korisnik = '$korId'";
    $rez = $bp->selectDB($upit);
    $rez = mysqli_fetch_assoc($rez);
    if ($rez == NULL) {
        $zauzeto = false;
    } else {
        $zauzeto = true;
    }

    $upit = "select * from `prijava` where id_utrka='$utrkaId' AND id_korisnik = '$korId' AND prijava_prihvacena = '1'";
    $rez = $bp->selectDB($upit);
    $rez = mysqli_fetch_assoc($rez);
    if ($rez == NULL) {
        $zauzeto2 = true;
    } else {
        $zauzeto2 = false;
    }
    
    if (!$zauzeto && !$zauzeto2) {
            $upitNew = "insert into `rezultati utrke` VALUES (default, '$vrijemeZ', '0', null, '$korId', '$utrkaId', '$modId')";

            $bp->updateDB($upitNew);
       
    }
    $bp->zatvoriDB();
}
if (isset($_POST['azuriraj'])) {
    $bp = new Baza();
    $bp->spojiDB();

    $utrkaId = $_POST['utrkaId'];
    $korisnikId = $_POST['korisnikId'];
    $vrijemeZ = $_POST['vrijemeZ'];
    
    $upitUpdate = "UPDATE `rezultati utrke` SET datum_i_vrijeme_zavrsetka = '$vrijemeZ' WHERE id_utrka = '$utrkaId' AND id_korisnik = '$korisnikId'";
    $bp->updateDB($upitUpdate);
    $bp->zatvoriDB();
}

if (isset($_POST['obrisi'])) {
    $bp = new Baza();
    $bp->spojiDB();

    $utrkaId = $_POST['utrkaId'];
    $korisnikId = $_POST['korisnikId'];
    $vrijemeZ = $_POST['vrijemeZ'];

    
    $upitObrisi = "DELETE FROM `rezultati utrke` WHERE id_utrka = '$utrkaId' AND id_korisnik = '$korisnikId'";
    $bp->updateDB($upitObrisi);
    $bp->zatvoriDB();
}
?>