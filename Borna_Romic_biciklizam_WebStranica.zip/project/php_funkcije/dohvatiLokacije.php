<?php

$putanja = dirname($_SERVER["REQUEST_URI"], 2);
$direktorij = dirname(getcwd());
require '../zaglavlje.php';

$bp = new Baza();
$bp->spojiDB();
$upit = "SELECT l.id_lokacija, l.mjesto, l.adresa, l.id_administrator, COUNT(ml.id_lokacija) AS 'broj_moderatora' FROM `lokacija` l 
LEFT JOIN `moderator/lokacija` ml ON l.id_lokacija = ml.id_lokacija
GROUP BY l.id_lokacija";
$rezultat = $bp->selectDB($upit);
$data = $rezultat->fetch_all(MYSQLI_ASSOC);
$bp->zatvoriDB();

$json_object = (object)array();
$json_object -> users = $data;
echo json_encode($data);
?>

