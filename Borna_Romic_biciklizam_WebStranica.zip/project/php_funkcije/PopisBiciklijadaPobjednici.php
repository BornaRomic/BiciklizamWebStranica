<?php

$putanja = dirname($_SERVER["REQUEST_URI"], 2);
$direktorij = dirname(getcwd());
require '../zaglavlje.php';

$bp = new Baza();
$bp->spojiDB();

$id = $_POST['userId'];


$upitPobjednici = "SELECT lb.id_lokacija, b.id_biciklijada, b.naziv_biciklijade, u.id_utrka, u.naziv_utrke, k.id_korisnik, k.korisnicko_ime, k.ime, k.prezime, k.dozvola_slika FROM `biciklijada` b INNER JOIN `lokacija/biciklijada` lb on b.id_biciklijada = lb.id_biciklijada INNER JOIN `utrka` u ON b.id_biciklijada = u.id_biciklijada INNER JOIN `odabir pobjednika` op ON u.id_utrka = op.id_utrka INNER JOIN `korisnik` k ON op.id_korisnik = k.id_korisnik WHERE id_lokacija = '$id' ORDER BY b.id_biciklijada;";
$rezultat = $bp->selectDB($upitPobjednici);
$data = $rezultat->fetch_all(MYSQLI_ASSOC);
$bp->zatvoriDB();

$json_object = (object)array();
$json_object -> users = $data;
echo json_encode($data);

?>

