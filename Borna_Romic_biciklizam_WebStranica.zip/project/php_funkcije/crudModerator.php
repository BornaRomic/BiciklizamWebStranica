<?php

$putanja = dirname($_SERVER["REQUEST_URI"], 2);
$direktorij = dirname(getcwd());
require '../zaglavlje.php';

if (!isset($_SESSION["uloga"]) || $_SESSION["uloga"] !== "1") {
    header("Location: ../obrasci/prijava.php");
    exit();
}
/*
  if (isset($_POST['save'])) {

  $bp = new Baza();
  $bp->spojiDB();

  $lokacijaId = $_POST['lokacijaId'];
  $mjesto = $_POST['mjesto'];
  $adresa = $_POST['adresa'];
  $adminId = $_POST['adminId'];

  $upitUpdate = "UPDATE lokacija SET mjesto='$mjesto', adresa='$adresa' WHERE id_lokacija='$lokacijaId'";
  $rezultat = $bp->selectDB($upitUpdate);
  $bp->updateDB($upitUpdate);
  $bp->zatvoriDB();
  }
 */
if (isset($_POST['spremi'])) {
    $bp = new Baza();
    $bp->spojiDB();

    $dobar = true;
    $greska = "";
    $uspjeh = "";
    $zauzeto = false;

    $lokacijaId = $_POST['lokacijaId'];
    $korIme = $_POST['modId'];

    $upitKorisnik = "SELECT id_korisnik, id_uloga FROM `korisnik` WHERE korisnicko_ime = '$korIme';";
    $rezultatispisa = $bp->selectDB($upitKorisnik);

    while ($redbroj = mysqli_fetch_array($rezultatispisa)) {
        if ($redbroj) {
            $korId = $redbroj["id_korisnik"];
            $ulogaM = $redbroj["id_uloga"];
        }
    }
    if ($ulogaM > '2') {
        $dobar = false;
    }

    $upit = "SELECT ml.id_moderator_lokacija, ml.id_lokacija, ml.id_moderator FROM `moderator/lokacija` ml
  INNER JOIN `korisnik` k ON ml.id_moderator = k.id_korisnik
  WHERE id_lokacija = '$lokacijaId' AND k.korisnicko_ime = '$korIme';";
    $rez = $bp->selectDB($upit);
    $rez = mysqli_fetch_array($rez);
    if ($rez == NULL) {
        $zauzeto = false;
    } else {
        $zauzeto = true;
    }

    if ($dobar) {
        if (!$zauzeto) {
            $uspjeh .= "Registracija uspješno obavljena.";
            $upitNew = "insert into `moderator/lokacija` VALUES (default, '$lokacijaId', '$korId');";

            $bp->updateDB($upitNew);
        }
    }
    $bp->zatvoriDB();
}
if (isset($_POST['ukloni'])) {
    $bp = new Baza();
    $bp->spojiDB();

    $lokacijaId = $_POST['lokacijaId'];
    $korIme = $_POST['modId'];

    $upitKorisnik = "SELECT id_korisnik FROM `korisnik` WHERE korisnicko_ime = '$korIme';";
    $rezultatispisa = $bp->selectDB($upitKorisnik);

    while ($redbroj = mysqli_fetch_array($rezultatispisa)) {
        if ($redbroj) {
            $korId = $redbroj["id_korisnik"];
        }
    }

    $upitObrisi = "DELETE FROM `moderator/lokacija` WHERE id_lokacija = '$lokacijaId' AND id_moderator = '$korId'";
    $bp->updateDB($upitObrisi);
    $bp->zatvoriDB();
}
?>