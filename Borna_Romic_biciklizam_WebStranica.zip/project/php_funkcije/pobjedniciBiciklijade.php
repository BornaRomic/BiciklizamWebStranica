
<?php

$putanja = dirname($_SERVER["REQUEST_URI"], 2);
$direktorij = dirname(getcwd());
require '../zaglavlje.php';

$bp = new Baza();
$bp->spojiDB();
$upit = "select l.mjesto, COUNT(*) AS 'Broj_biciklijada', l.id_lokacija from `lokacija` l inner join `lokacija/biciklijada` lb on l.id_lokacija = lb.id_lokacija GROUP BY l.mjesto, l.id_lokacija order by l.mjesto;";
$rezultat = $bp->selectDB($upit);
$data = $rezultat->fetch_all(MYSQLI_ASSOC);
$bp->zatvoriDB();

$json_object = (object)array();
$json_object -> users = $data;
echo json_encode($data);
?>