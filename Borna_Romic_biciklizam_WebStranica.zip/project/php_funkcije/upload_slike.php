<?php

$putanja = dirname($_SERVER["REQUEST_URI"], 2);
$direktorij = dirname(getcwd());
require '../zaglavlje.php';

if (!isset($_SESSION["uloga"]) || $_SESSION["uloga"] > "3") {
    header("Location: ../obrasci/prijava.php");
    exit();
}

if (isset($_POST['dozvoli'])) {

    $bp = new Baza();
    $bp->spojiDB();

    $korisnikId = $_POST['korisnikId'];

    $upitUpdate = "UPDATE `korisnik` SET dozvola_slika='1' WHERE korisnicko_ime='$korisnikId'";
    $rezultat = $bp->selectDB($upitUpdate);
    $bp->updateDB($upitUpdate);
    $bp->zatvoriDB();
}
if (isset($_POST['odbij'])) {

    $bp = new Baza();
    $bp->spojiDB();

    $korisnikId = $_POST['korisnikId'];

    $upitUpdate = "UPDATE `korisnik` SET dozvola_slika='0' WHERE korisnicko_ime='$korisnikId'";
    $rezultat = $bp->selectDB($upitUpdate);
    $bp->updateDB($upitUpdate);
    $bp->zatvoriDB();
}
?>