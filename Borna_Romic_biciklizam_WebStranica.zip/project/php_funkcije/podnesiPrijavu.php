<?php

$putanja = dirname($_SERVER["REQUEST_URI"], 2);
$direktorij = dirname(getcwd());
require '../zaglavlje.php';

//echo 'bok';

if (isset($_POST['prijavi'])) {

    $bp = new Baza();
    $bp->spojiDB();
    
    //echo "<script>alert(\"nešto\");</script>";

    $zauzeto = false;
    
    $nazivU = $_POST['nazivU'];
    $ime = $_POST['ime'];
    $prezime = $_POST['prezime'];
    $prebivaliste = $_POST['prebivaliste'];
    $email = $_POST['email'];
    $utrkaId = $_POST['utrkaId'];
    $korIme = Sesija::dajKorisnika();

    $upitKorisnik = "SELECT id_korisnik FROM `korisnik` WHERE korisnicko_ime = '{$korIme['korisnik']}';";
    $rezultatispisa = $bp->selectDB($upitKorisnik);
    
    while ($redbroj = mysqli_fetch_array($rezultatispisa)) {
        if ($redbroj) {
            $korId = $redbroj["id_korisnik"];
        }
    }
    //echo "<script>alert('$korIme');</script>";

    $upit = "select * from prijava where id_korisnik='$korId' && id_utrka = '$utrkaId'";
    $rez = $bp->selectDB($upit);
    $rez = mysqli_fetch_assoc($rez);
    if ($rez == NULL) {
        $zauzeto = false;
    } else {
        $zauzeto = true;
    }

    if(!$zauzeto){
    $upitPrijava = "INSERT INTO `prijava` VALUES (default, '$ime', '$prezime', 0, '$prebivaliste', '$korId', '$utrkaId', 2);";
    $rezultat = $bp->selectDB($upitPrijava);
    
    $upitID = "SELECT id_prijava FROM `prijava` WHERE id_korisnik = '$korId';";
    $rezultatID = $bp->selectDB($upitID);
    
    while ($redbroj = mysqli_fetch_array($rezultatID)) {
        if ($redbroj) {
            $IDprijava = $redbroj["id_prijava"];
        }
    }
    
    $upitPrijava2 = "INSERT INTO `prijava prihvacena` VALUES(default, 0, \"\", '$IDprijava');";
    $rezultatPrijava2 = $bp->selectDB($upitPrijava2);
    }
    $bp->zatvoriDB();
}
?>

