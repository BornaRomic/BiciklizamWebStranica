<?php

$putanja = dirname($_SERVER["REQUEST_URI"], 2);
$direktorij = dirname(getcwd());
require '../zaglavlje.php';

if (!isset($_SESSION["uloga"]) || $_SESSION["uloga"] > "2") {
    header("Location: ../obrasci/prijava.php");
    exit();
}
if (isset($_POST['prihvati'])) {

    $bp = new Baza();
    $bp->spojiDB();

    $utrkaId = $_POST['utrkaId'];
    $korisnikId = $_POST['korisnikId'];

    $upitUtrka = "SELECT startnina, broj_natjecatelja from `utrka` WHERE id_utrka = '$utrkaId'";
    $rezultatispisa = $bp->selectDB($upitUtrka);

    while ($redbroj = mysqli_fetch_array($rezultatispisa)) {
        if ($redbroj) {
            $startnina = $redbroj["startnina"];
            $broj_natjecatelja = $redbroj["$broj_natjecatelja"];
        }
    }

    $upitUpdate = "UPDATE `prijava` SET prijava_prihvacena='1' WHERE id_prijava='$korisnikId'";
    $rezultat = $bp->selectDB($upitUpdate);
    $bp->updateDB($upitUpdate);
    
    if ($startnina === "0") {
        $upitUpdate = "UPDATE `prijava prihvacena` SET potvrda_o_placanju = '1', racun='Nije potrebna uplata za utrku' WHERE id_prijava='$korisnikId'";
        $rezultat = $bp->selectDB($upitUpdate);
        $bp->updateDB($upitUpdate);
    } elseif ($startnina !== "0") {
        $upitUpdate = "UPDATE `prijava prihvacena` SET racun='Molim vas uplatite $startnina kn na racun broj HR 89 2484008 1102131080' WHERE id_prijava='$korisnikId'";
        $rezultat = $bp->selectDB($upitUpdate);
        $bp->updateDB($upitUpdate);
    }



    $bp->zatvoriDB();
}

if (isset($_POST['odbij'])) {

    $bp = new Baza();
    $bp->spojiDB();

    $utrkaId = $_POST['utrkaId'];
    $korisnikId = $_POST['korisnikId'];

    $upitUtrka = "SELECT potvrda_o_placanju, racun from `prijava prihvacena` WHERE id_prijava = '$korisnikId'";
    $rezultatispisa = $bp->selectDB($upitUtrka);

    while ($redbroj = mysqli_fetch_array($rezultatispisa)) {
        if ($redbroj) {
            $potvrda = $redbroj["potvrda_o_placanju"];
            $racun = $redbroj["racun"];
        }
    }

    
    
    if ($potvrda === "0") {
        $upitUpdate = "UPDATE `prijava prihvacena` SET racun='' WHERE id_prijava='$korisnikId'";
        $rezultat = $bp->selectDB($upitUpdate);
        $bp->updateDB($upitUpdate);
        $upitUpdate = "UPDATE `prijava` SET prijava_prihvacena='0' WHERE id_prijava='$korisnikId'";
        $rezultat = $bp->selectDB($upitUpdate);
        $bp->updateDB($upitUpdate);
    } elseif ($potvrda === "1" && $racun !== "Nije potrebna uplata za utrku") {
        echo "Korisnik je već uplatio račun!";
    } elseif ($potvrda === "1" && $racun === "Nije potrebna uplata za utrku"){
        $upitUpdate = "UPDATE `prijava` SET prijava_prihvacena='0' WHERE id_prijava='$korisnikId'";
        $rezultat = $bp->selectDB($upitUpdate);
        $bp->updateDB($upitUpdate);
        $upitUpdate = "UPDATE `prijava prihvacena` SET potvrda_o_placanju = '0', racun='' WHERE id_prijava='$korisnikId'";
        $rezultat = $bp->selectDB($upitUpdate);
        $bp->updateDB($upitUpdate);
    }



    $bp->zatvoriDB();
}
?>