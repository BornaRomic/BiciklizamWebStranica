<?php

$putanja = dirname($_SERVER["REQUEST_URI"], 2);
$direktorij = dirname(getcwd());
require '../zaglavlje.php';

//echo 'bok';

if (isset($_POST['uplati'])) {

    $bp = new Baza();
    $bp->spojiDB();
  
    $prijavaId = $_POST['prijavaId'];
   

    $upitUplata = "UPDATE `prijava prihvacena` SET potvrda_o_placanju = 1 WHERE id_prijava = '$prijavaId'";
    $rezultat = $bp->selectDB($upitUplata);
    $bp->updateDB($upitUplata);
    $bp->zatvoriDB();
}

if (isset($_POST['obrisi'])) {

    $bp = new Baza();
    $bp->spojiDB();
  
    $prijavaId = $_POST['prijavaId'];
   

    
    
    $upitObrisi = "DELETE FROM `prijava prihvacena` WHERE id_prijava = '$prijavaId'";
    $bp->updateDB($upitObrisi);
    
    $upitObrisi = "DELETE FROM `prijava` WHERE id_prijava = '$prijavaId'";
    $bp->updateDB($upitObrisi);
    
    $bp->zatvoriDB();
    
}


?>