<?php
    $putanja = dirname($_SERVER["REQUEST_URI"], 2);
    $direktorij = dirname(getcwd());
    include '../zaglavlje.php';
    
    if (!isset($_SESSION["uloga"]) || $_SESSION["uloga"] > 3) {
    header("Location: ../obrasci/prijava.php");
    exit();
    }
    error_reporting(E_ERROR | E_PARSE);
    $korIme = Sesija::dajKorisnika();
    

if(isset($_POST["predaj"])){
        $userfile = $_FILES['slikaU']['tmp_name'];
        $userfile_name = $_FILES['slikaU']['name'];
        $userfile_size = $_FILES['slikaU']['size'];
        $userfile_type = $_FILES['slikaU']['type'];
        $userfile_error = $_FILES['slikaU']['error'];
        if ($userfile_error > 0) {
            echo 'Problem: ';
            switch ($userfile_error) {
                case 1: echo 'Veličina veća od ' . ini_get('upload_max_filesize');
                    break;
                case 2: echo 'Veličina veća od ' . $_POST["MAX_FILE_SIZE"] . 'B';
                    break;
                case 3: echo 'Datoteka djelomično prenesena';
                    break;
                case 4: echo 'Datoteka nije prenesena';
                    break;
            }
            exit;
        }
        /*
        if ($userfile_type != 'png') {
            echo 'Problem: datoteka nije plain text' . $userfile;
            exit;
        }*/
        $upfile = '../multimedija/slike_korisnika/' . $userfile_name;

        if (is_uploaded_file($userfile)) {
            if (!move_uploaded_file($userfile, $upfile)) {
                echo 'Problem: nije moguće prenijeti datoteku na odredište';
                exit;
            }
        } else {
            echo 'Problem: mogući napad prijenosom. Datoteka: ' . $userfile_name;
        exit;
    }
}
?>

<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html lang="hr">

    <head>
        <title>Rezultati sudjelovanih utrka</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="author" content="Borna Romić">
        <meta name="keywords" content="FOI, WebDiP, 2020.">
        <link href="../css/bromic.css" rel="stylesheet" type="text/css" />
        <link href="../css/bromic_prilagodbe.css" rel="stylesheet" type="text/css" media="screen and (max-width:1024px)" />
        <link href="../css/bromic_ispis.css" rel="stylesheet" type="text/css" />
        <meta name="author" content="Borna Romić">
        <meta name="keywords" content="FOI, WebDiP, 2020.">
        <meta name="description" content="Stranica s tablicom.">
        <style type="text/css">
            .bicDogadjaji{
                font-size: 30pt;
            }

            .tablicaEventovi{
                border: 0.5vw solid;
                border-radius: 3vw;
                flex-wrap: wrap;
                justify-content: center;
            }

            th,td{
                padding: 15px;
                height:20px;
            }
            #boja1{
                background-color: #66ffcc;
            }
            #boja2{
                background-color: #429bf5;
            }
            #boja3{
                background-color: #8a42f5;
            }
            #boja4{
                background-color: #f54272;
            }
            #boja5{
                background-color: #7542f5;
            }
            #boja6{
                background-color: #4a5e52;
            }
            #sadrzaj{
                font-family: "Palatino Linotype", "Book Antiqua", Palatino, serif;
            }
            h2{
                text-align: center;
            }
            
            .spojiStupce{
                grid-column: 1 / span 3;
                grid-row: 3;
                display: flex;
                flex-wrap: wrap;
                justify-content: center;
            }
            
            #imageTable{
                grid-column: 3;
                grid-row: 3;
                display: flex;
                flex-wrap: wrap;
                justify-content: center;
            }
            
            #formaUnosa{
                grid-column: 1;
                grid-row: 3;
                display: flex;
                flex-wrap: wrap;
                justify-content: center;
            }
           
        </style>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="//code.jquery.com/jquery-1.12.4.js"></script>
        <script type="text/javascript" src="../javascript/bromic_jquery.js"></script>
    </head>
    <body class="resetka">
        <header class="spojiSveStupceZaglavlje">
            <p><img class="slika" usemap="#mapa1" src="../multimedija/logo_bicikl.png" alt="stranica logo" width="130" height="80" />
                <map name="mapa1">
                    <area href="../index.php" alt="pravokutnik" shape="rect" coords="0,0,130,80"/></map>
            </p>
            <h1>Rezultati sudjelovanih utrka</h1>
            <form name = "pretrazivanje" id="pretrazivanje" method= "post"
                  action = "http://barka.foi.hr/WebDiP/2019/materijali/zadace/ispis_forme.php">
                <?php
                if (isset($_SESSION["uloga"]) && $_SESSION["uloga"] <4){
                    echo "<a href=\"../odjava.php\">Odjava</a>";
                }
                else{
                    echo "<a href=\"../obrasci/prijava.php\">Prijava</a>";
                }
                ?>

            </form>
        </header>
        <?php
        
        include '../meni.php';
        ?>
        <div id="sadrzaj" class="spojiStupce" style="overflow-x:auto;">
            <table border="1" >
                <caption>Ispis rezultata</caption>
                <thead>
                    <tr>
                        <th>Biciklijada</th>
                        <th>Utrka</th>
                        <th>Vlastiti datum i vrijeme završetka</th>
                        <th>Pobjednik</th>
                    </tr>
                </thead>
                <tbody class="tableData" id="tableData">

                </tbody>
            </table> 
            <form method="POST" class="formaUnosa" enctype="multipart/form-data">
                <div id="myModal" class="" role="dialog">
                    <div class="">
                        <div class="">
                            <div class="">
                                <h4 class="">Unos vaše slike</h4>
                            </div>
                            <div class="">
                                <div class="">
                                    <label>Upload slike:</label>
                                    <label>Slika mora biti u obliku (vaše "korisnickoime" + ".png")</label>
                                    <input type="file" id="slikaU" name="slikaU" class="">
                                    <input type="hidden" name="MAX_FILE_SIZE" value="30000"/>
                                </div>
                            </div>
                            <div class="">
                                <input type="submit" id="predaj" name="predaj" class="predaj" value="Predaj"><br><br>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
            <form method="POST" action="">
            <div id="myModal" class="" role="dialog">
                <div class="">
                    <div class="">
                        <div class="">
                        </div>
                            <div class="">
                                <div class="">
                                </div>
                            </div>
                        <fieldset>
                            <div class="">
                                <fieldset>
                                    <label>Korisničko ime:</label>
                                    <input readonly type="text" id="korisnikId" name="korisnikId" class=""><br><br>
                                    <label>Dozvola prikaza slike:</label>
                                    <input readonly type="text" id="dozvolaS" name="dozvolaS" class=""><br>
                                    <br><input type="button" id="dozvoli" name="dozvoli" class="dozvoli" value="Dozvoli">
                                    <input type="button" id="odbij" name="odbij" class="odbij" value="Odbij"><br>
                                </fieldset>
                            </div>
                        </fieldset>
                    </div>
                </div>
            </div>
        </form>
        </div>

        <div>
            <input type="hidden" value="<?php echo $korIme['korisnik']; ?>" id ="KORIME"/>
        </div>
        <footer class="spojiSveStupcePodnozja">
            <address>Kontakt:<a href="mailto:bromic@foi.hr">Borna Romić</a></address>
            <p class="tekst"> Ime i prezime: Borna Romić</p>
            <p class="tekst">Datum rođenja: 30.03.1998.</p>
            <p><small>&copy; 2020. B. Romić</small></p>
        </footer>
    </body>
</html>