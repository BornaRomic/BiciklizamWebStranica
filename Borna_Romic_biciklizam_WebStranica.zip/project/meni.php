<?php

echo "
    <nav id=\"izbornik\" class=\"stupac_1\">
            <ul>
                <li><a href=\"$putanja/index.php\" >Početna stranica</a></li>
                <li><a href=\"$putanja/ostalo/PopisLokacijaBiciklijada.php\" >Popis lokacija biciklijada</a></li>";
if (!isset($_SESSION["uloga"]) || $_SESSION["uloga"] == 4){
echo"    <li><a href = \"$putanja/ostalo/planirane_utrke.php\" >Planirane utrke</a></li>
            <li><a href=\"$putanja/obrasci/prijava.php\" >Prijava</a></li>
                <li><a href=\"$putanja/obrasci/registracija.php\" >Registracija</a></li>";                
                
}

if (isset($_SESSION["uloga"]) && $_SESSION["uloga"] <4) {
echo
                "<div class=\"dropdown\">
                  <button class=\"dropbtn\">Utrke</button>
                  <div class=\"dropdown-content\">
                    <li><a href = \"$putanja/ostalo/planirane_utrke.php\" >Planirane utrke</a></li>
                    <li><a href=\"$putanja/obrasci/prijavaUtrka.php\">Prijava na utrke</a></li>
                    <li><a href=\"$putanja/ostalo/pregledPrijava.php\">Pregled prijava</a></li>
                    <li><a href=\"$putanja/ostalo/rezultati_sudjelovanih_utrka.php\">Rezultati sudjelovanih utrka</a></li>
                  </div>
                </div>";
}  
if (isset($_SESSION["uloga"]) && $_SESSION["uloga"] <3 ) {
echo            
                "<div class=\"dropdown\">
                  <button class=\"dropbtn\">Upravljanje utrkama</button>
                  <div class=\"dropdown-content\">
                    <li><a href=\"$putanja/funkcije_moderatora/evidentiranje_rezultata.php\">Evidentiranje rezultata utrke</a></li>
                    <li><a href=\"$putanja/funkcije_moderatora/odobravanje_prijava.php\">Odobravanje prijava</a></li>
                    <li><a href=\"$putanja/funkcije_moderatora/odustali_od_utrke.php\">Odustali od utrke</a></li>
                  </div>
                </div>";

} 
if (isset($_SESSION["uloga"]) && $_SESSION["uloga"] === "1") {

echo            

                  "<div class=\"dropdown\">
                  <button class=\"dropbtn\">Upravljanje stranice</button>
                  <div class=\"dropdown-content\">
                    <li><a href=\"$putanja/upravljanje_korisnicima/azuriraj_korisnika.php\">Ažuriraj korisnika</a></li>
                    <li><a href=\"$putanja/upravljanje_korisnicima/kreiraj_lokacije.php\">Kreiraj lokacije</a></li>
                    <li><a href=\"$putanja/upravljanje_korisnicima/kreiraj_dogadaje.php\">Kreiraj događaje</a></li>
                    <li><a href=\"$putanja/upravljanje_korisnicima/dodijeli_biciklijade_lokaciji.php\">Dodijela biciklijade lokaciji</a></li>
                    <li><a href=\"$putanja/upravljanje_korisnicima/odabir_pobjednika.php\">Odabir pobjednika utrke</a></li>
                  </div>
                </div>";

}   
echo "
            </ul>
        </nav>
 ";
