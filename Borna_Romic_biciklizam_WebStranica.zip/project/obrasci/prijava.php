<?php
$putanja = dirname($_SERVER['REQUEST_URI'], 2);
$direktorij = dirname(getcwd());
include '../zaglavlje.php';
error_reporting(E_ERROR | E_PARSE);
if (isset($_GET['prijava'])) {
    $greska = "";
    $poruka = "";
    foreach ($_GET as $k => $v) {
        if(empty($v)){
            $greska .= "Nije popunjeno: " . $k . "<br>";
        }
    }
    if(empty($greska)){
        //$poruka = "Nema greške";
        $veza = new Baza();
        $veza->spojiDB();
        
        $korIme = $_GET['korIme'];
        $lozinka = $_GET['lozinka'];
        $ispisi = "SELECT broj_prijava, status FROM korisnik WHERE korisnicko_ime = '$korIme'";
        $rezultatispisa= $veza->selectDB($ispisi); 
        
        while($redbroj = mysqli_fetch_assoc($rezultatispisa)){
            if($redbroj){
            $broj = $redbroj["broj_prijava"];
            $status = $redbroj["status"];
            }
        }
        //echo "<script>alert('$status');</script>";
        $upit = "SELECT * FROM korisnik WHERE "
                . "korisnicko_ime='{$korIme}' "
                . "AND zaporka='{$lozinka}';";
                
        $rezultat = $veza->selectDB($upit);
        //var_dump($rezultat);
        $autenticiran = false;
        while ($red = mysqli_fetch_array($rezultat)) {
            if($red){
                if($broj < 4 && $status != 0){
                    $autenticiran = true;
                }
                $tip = $red["id_uloga"]; //tip/uloga korisnika
                $email = $red['email'];
            }
            
        }
        if ($autenticiran) {
            if (empty($_COOKIE['autenticiran'])) {
                $mail_to = $email;
                $mail_from = "From: WebDiP2019@foi.unizg.hr";
                $mail_subject = "Slanje maila";
                $mail_body = "Prijava u sustav!";
                //mail($mail_to, $mail_subject, $mail_body, $mail_from);
            }
            $poruka = "Uspješna prijava!";
            $broj = 0;
            $bp = new Baza();
            $bp->spojiDB();
            $upit = "UPDATE korisnik SET broj_prijava = '$broj' WHERE korisnicko_ime = '$korIme'";
            $rez = $bp->selectDB($upit);
            //$rez = mysqli_fetch_assoc($rez);
            $bp->updateDB($upit);
            
            Sesija::kreirajKorisnika($korIme, $tip);
            
            
        }
        else{
            $poruka = "Neuspješna prijava! ";
            $broj = $broj + 1;
            //echo "<script>alert('$korIme');</script>";

            if ($broj > 3) {
                $zakljucan = "Korisnički račun $korIme je zaključan! ";
            }
            $bp = new Baza();
            $bp->spojiDB();
            $upit = "UPDATE korisnik SET broj_prijava = '$broj' WHERE korisnicko_ime = '$korIme'";
            $rez = $bp->selectDB($upit);
            //$rez = mysqli_fetch_assoc($rez);
            $bp->updateDB($upit);
        }
    }
    $veza -> zatvoriDB();
}

?>

<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html lang="hr">

    <head>
        <title>Prijava</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="../css/bromic.css" rel="stylesheet" type="text/css" />
        <link href="../css/bromic_prilagodbe.css" rel="stylesheet" type="text/css" media="screen and (max-width:1024px)" />
        <link href="../css/bromic_ispis.css" rel="stylesheet" type="text/css" />
        <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/smoothness/jquery-ui.css">
        
        <meta name="author" content="Borna Romić">
        <meta name="keywords" content="FOI, WebDiP, 2020.">
        <meta name="description" content="Stranica za prijavu.">
        <style type="text/css">

            .stupacSadrzaj{
                grid-column: 2;
                grid-row: 3;
                display: flex;
                flex-wrap: wrap;
                justify-content: center;
            }
            #greske{
                grid-column: 1;
                grid-row: 3;
                display: flex;
                flex-wrap: wrap;
                justify-content: center;
            }
            
            #poruka{
                grid-column: 2;
                grid-row: 4;
                display: flex;
                flex-wrap: wrap;
                justify-content: center;
            }

        </style>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="//code.jquery.com/jquery-1.12.4.js"></script>
        <script type="text/javascript" src="../javascript/bromic_jquery.js"></script>
    </head>
    <body class="resetka" onload="kreirajDogadaje();">
        <header class="spojiSveStupceZaglavlje">
            <p><img class="slika" usemap="#mapa1" src="../multimedija/logo_bicikl.png" alt="stranica logo" width="130" height="80" />
                <map name="mapa1">
                    <area href="../index.php" alt="pravokutnik" shape="rect" coords="0,0,130,80"/></map>
            </p>
            <h1>Prijava</h1>
            <form name = "pretrazivanje" id="pretrazivanje" method= "post"
                  action = "http://barka.foi.hr/WebDiP/2019/materijali/zadace/ispis_forme.php">
                <label> Pretraživanje:</label>
                <input name="pretrazivanje" id="pretrazi" type="search" placeholder="pretraživanje"  maxlength ="20" size="20"/>
                <input name ="submit" type ="submit" value="pretraži" />
                <?php
                if (isset($_SESSION["uloga"]) && $_SESSION["uloga"] <4){
                    echo "<a href=\"../odjava.php\">Odjava</a>";
                    //$kor= $_SESSION["korisnik"];
                    //echo "$kor";
                }
                else{
                    echo "<a href=\"../obrasci/prijava.php\">Prijava</a>";
                }
                ?>

            </form>
        </header>
       
        <?php
        
        include '../meni.php';
        ?>
        <div id="sadrzaj" class="stupacSadrzaj">
            <div id="greske" style ="color:red">
            <?php
                if(isset($greska)){
                    echo "<p>$greska</p>";
                }
            ?>
        </div>
            <form novalidate name="prijava" id="prijava" method="get" enctype="multipart/form-data"
                  action="<?php echo $_SERVER['PHP_SELF']; ?>">
                <fieldset>
                    <legend>Prijava</legend><br>
                    <p>
                        <label>Korisničko ime:</label>
                        <input id="korIme" type="text" name="korIme" required="required" size="20" maxlength="15"/><br><br>
                    </p>

                    <p>
                        <label>Lozinka:</label>
                        <input id="lozinka" type="password" name="lozinka" required="required" size="20"> <br><br>
                    </p>
                    <div id="greske"></div>
                    <p>
                        <input type="submit" name="prijava" id="prijava" class="prijava" value="Prijavi se" />
                        <input name ="reset" type ="reset" value="Resetiraj" />
                    </p>
                </fieldset> 
            </form>
            <ul>
                <li><a href="../obrasci/zaboravljena_lozinka.php" >Zaboravljena lozinka</a></li>
            </ul>
        </div>
        <div id="poruka" style="color:green">
            <?php
                if(isset($poruka)){
                    echo "<p>$poruka</p>";
                }
                if(isset($zakljucan)){
                    echo "<p>$zakljucan</p>";
                }
                if(isset($greska)){
                    echo"<p>$greska</p></br>";
                    echo"<p>$broj</p>";
                }
            ?>
        </div>
        
        <footer class="spojiSveStupcePodnozja">
            <address>Kontakt:<a href="mailto:bromic@foi.hr">Borna Romić</a></address>
            <p class="tekst"> Ime i prezime: Borna Romić</p>
            <p class="tekst">Datum rođenja: 30.03.1998.</p>
            <p><small>&copy; 2020. B. Romić</small></p>
        </footer>
    </body>
</html>