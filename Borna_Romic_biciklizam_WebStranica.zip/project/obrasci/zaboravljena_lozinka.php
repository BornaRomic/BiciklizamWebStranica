<?php
$putanja = dirname($_SERVER['REQUEST_URI'], 2);
$direktorij = dirname(getcwd());
include '../zaglavlje.php';

if (isset($_GET['prijava'])) {
    $veza = new Baza();
    $veza->spojiDB();

    $korIme = $_GET['korIme'];
    $email = $korIme;

    $alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
    $pass = array(); //remember to declare $pass as an array
    $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
    for ($i = 0; $i < 8; $i++) {
        $n = rand(0, $alphaLength);
        $pass[] = $alphabet[$n];
    }
    $novi = implode($pass);

    $upitUpdate = "UPDATE `korisnik` SET zaporka='$novi' WHERE email='$email'";
    $rezultat = $veza->selectDB($upitUpdate);
    $veza->updateDB($upitUpdate);

    $mail_to = $email;
    $mail_from = "From: WebDiP2019@foi.unizg.hr";
    $mail_subject = "Novi password";
    $mail_body = "Vas novi password je: '{$novi}'";
    mail($mail_to, $mail_subject, $mail_body, $mail_from);

    $veza->zatvoriDB();
    header("Location: ../obrasci/prijava.php");
}
?>

<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html lang="hr">

    <head>
        <title>Zaboravljena lozinka</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="../css/bromic.css" rel="stylesheet" type="text/css" />
        <link href="../css/bromic_prilagodbe.css" rel="stylesheet" type="text/css" media="screen and (max-width:1024px)" />
        <link href="../css/bromic_ispis.css" rel="stylesheet" type="text/css" />
        <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/smoothness/jquery-ui.css">
        <meta name="author" content="Borna Romić">
        <meta name="keywords" content="FOI, WebDiP, 2020.">
        <meta name="description" content="Stranica za prijavu.">
        <style type="text/css">

            .stupacSadrzaj{
                grid-column: 2;
                grid-row: 3;
                display: flex;
                flex-wrap: wrap;
                justify-content: center;
            }
            #greske{
                grid-column: 1;
                grid-row: 3;
                display: flex;
                flex-wrap: wrap;
                justify-content: center;
            }

            #poruka{
                grid-column: 2;
                grid-row: 4;
                display: flex;
                flex-wrap: wrap;
                justify-content: center;
            }

        </style>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="//code.jquery.com/jquery-1.12.4.js"></script>
        <script type="text/javascript" src="../javascript/bromic_jquery.js"></script>
    </head>
    <body class="resetka" onload="kreirajDogadaje();">
        <header class="spojiSveStupceZaglavlje">
            <p><img class="slika" usemap="#mapa1" src="../multimedija/logo_bicikl.png" alt="stranica logo" width="130" height="80" />
                <map name="mapa1">
                    <area href="../index.php" alt="pravokutnik" shape="rect" coords="0,0,130,80"/></map>
            </p>
            <h1>Zaboravljena lozinka</h1>
            <form name = "pretrazivanje" id="pretrazivanje" method= "post"
                  action = "http://barka.foi.hr/WebDiP/2019/materijali/zadace/ispis_forme.php">
                <?php
                if (isset($_SESSION["uloga"]) && $_SESSION["uloga"] < 4) {
                    echo "<a href=\"../odjava.php\">Odjava</a>";
                    //$kor= $_SESSION["korisnik"];
                    //echo "$kor";
                } else {
                    echo "<a href=\"../obrasci/prijava.php\">Prijava</a>";
                }
                ?>

            </form>
        </header>

        <?php
        include '../meni.php';
        ?>
        <div id="greske" style ="color:red">

        </div>

        <form novalidate name="prijava" id="prijava" method="get" enctype="multipart/form-data"
                  action="">
                    <legend>Zaboravljena lozinka</legend><br>
                    <p>
                        <label>Unesite email adresu: </label>
                        <input id="korIme" type="text" name="korIme" required="required" size="20" maxlength="15"/><br><br>
                    </p>
                    <div id="greske"></div>
                    <p>
                        <input type="submit" name="prijava" id="prijava" class="prijava" value="Pošalji novu lozinku" />
                        <input name ="reset" type ="reset" value="Resetiraj" />
                    </p>
            </form>
    <div id="poruka" style="color:green">
    </div>

    <footer class="spojiSveStupcePodnozja">
        <address>Kontakt:<a href="mailto:bromic@foi.hr">Borna Romić</a></address>
        <p class="tekst"> Ime i prezime: Borna Romić</p>
        <p class="tekst">Datum rođenja: 30.03.1998.</p>
        <p><small>&copy; 2020. B. Romić</small></p>
    </footer>
</body>
</html>