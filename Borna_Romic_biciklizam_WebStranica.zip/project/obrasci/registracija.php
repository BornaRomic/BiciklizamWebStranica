<?php
$putanja = dirname($_SERVER['REQUEST_URI'], 2);
$direktorij = dirname(getcwd());

include '../zaglavlje.php';
?>

<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html lang="hr">

    <head>
        <title>Registracija</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="../css/bromic.css" rel="stylesheet" type="text/css" />
        <link href="../css/bromic_prilagodbe.css" rel="stylesheet" type="text/css" media="screen and (max-width:1024px)" />
        <link href="../css/bromic_ispis.css" rel="stylesheet" type="text/css" />
        <script type="text/javascript" src="../javascript/bromic.js"></script>
        <meta name="author" content="Borna Romić">
        <meta name="keywords" content="FOI, WebDiP, 2020.">
        <meta name="description" content="Stranica za registraciju.">
        <style type="text/css">

            .stupacSadrzaj{
                grid-column: 2;
                grid-row: 3;
                display: flex;
                flex-wrap: wrap;
                justify-content: center;
            }

        </style>

        <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="//code.jquery.com/jquery-1.12.4.js"></script>
        <script src="//code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
        <script type="text/javascript" src="../javascript/bromic_jquery.js"></script>
    </head>
    <body class="resetka" onload="kreirajRegistraciju();">
        <header class="spojiSveStupceZaglavlje">
            <p><img class="slika" usemap="#mapa1" src="../multimedija/logo_bicikl.png" alt="stranica logo" width="130" height="80" />
                <map name="mapa1">
                    <area href="../index.php" alt="pravokutnik" shape="rect" coords="0,0,130,80"/></map>
            </p>
            <h1>Registracija</h1>
            <form name = "pretrazivanje" id="pretrazivanje" method= "post"
                  action = "http://barka.foi.hr/WebDiP/2019/materijali/zadace/ispis_forme.php">
                <?php
                if (isset($_SESSION["uloga"]) && $_SESSION["uloga"] < 4) {
                    echo "<a href=\"../odjava.php\">Odjava</a>";
                    //$kor= $_SESSION["korisnik"];
                    //echo "$kor";
                } else {
                    echo "<a href=\"../obrasci/prijava.php\">Prijava</a>";
                }
                ?>
            </form>
        </header>
        <?php
        include '../meni.php';
        ?>
        <div id="sadrzaj" class="stupacSadrzaj">
            <form novalidate name="registracija" id="registracija" method="get" enctype="multipart/form-data"
                  action="">
                <fieldset>
                    <legend>Registracija</legend><br>
                    <p>
                        <label>Ime: </label>
                        <input type="text" id="ime" name="ime" autofocus required="required" size="20"/>
                    </p>
                    <p>
                        <label>Prezime:</label>
                        <input type="text" name="prezime" id="prezime" required="required" size="20"/><br><br>
                    </p>
                    <p>
                        <label>Korisničko ime:</label>
                        <input type="text" id="korIme" name="korIme" required="required" size="20" maxlength="15"/><br><br>
                    </p>
                    <p>
                        <label>Godina rođenja:</label>
                        <input type="date" id="godina" name="godina" required="required"> <br><br>
                    </p>
                    <p>
                        <label for="email">Email adresa: </label>
                        <input type="email" id="email" name="email" size="30" required="required" ><br><br>
                    </p>
                    <p>
                        <label>Lozinka:</label>
                        <input type="password" name="lozinka" id="lozinka" required="required" size="20"> 
                    </p>
                    <p>
                        <label>Potvrda lozinke:</label>
                        <input type="password" name="lozinka2" id="lozinka2" required="required" size="20"><br><br>
                    </p>
                    <p>
                    <h2 type="text" id="mainCaptcha"></h2><br>
                    <input type="button" id="refresh" value="refresh"/><br>          
                    <input type="text" id="txtInput"/>    
                    <input id="Button1" type="button" value="Check"/><br>
                    <!--<div id="g-recaptcha" class="g-recaptcha" data-sitekey="6LeIxAcTAAAAAJcZVRqyHh71UMIEGNQ_MXjiZKhI"></div>-->
                    </p>
                    <p>
                        <input type="button" name="register" id="register" class="register" value="Registriraj se" />
                    </p>
                    <div id="greske"></div>
                    <div id="greskeCaptcha"></div>
                </fieldset> 
            </form>
            <div id="poruka" hidden="hidden"> Ispis naziva svih elemenata obrasca:</div>
            <form novalidate name="aktivacija" id="aktivacija" method="post" enctype="multipart/form-data"
                  action="">
                <legend>Aktivacija korisničkog računa</legend><br>
                <p>
                    <label>Unesite aktivacijski kod: </label>
                    <input id="aktKod" type="text" name="aktKod" required="required" size="20" maxlength="15"/><br><br>
                </p>
                <p>
                    <input type="button" name="aktiviraj" id="aktiviraj" class="aktiviraj" value="Aktiviraj" />
                </p>
            </form>
        </div>

        <footer class="spojiSveStupcePodnozja">
            <address>Kontakt:<a href="mailto:bromic@foi.hr">Borna Romić</a></address>
            <p class="tekst"> Ime i prezime: Borna Romić</p>
            <p class="tekst">Datum rođenja: 30.03.1998.</p>
            <p><small>&copy; 2020. B. Romić</small></p>
        </footer>
    </body>
</html>