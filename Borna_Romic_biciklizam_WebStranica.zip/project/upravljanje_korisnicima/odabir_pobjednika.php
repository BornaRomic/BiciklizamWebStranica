<?php
$putanja = dirname($_SERVER["REQUEST_URI"], 2);
$direktorij = dirname(getcwd());
include '../zaglavlje.php';

if (!isset($_SESSION["uloga"]) || $_SESSION["uloga"] !== "1") {
    header("Location: ../obrasci/prijava.php");
    exit();
}
?>

<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html lang="hr">

    <head>
        <title>Odabir pobjednika utrke</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="author" content="Borna Romić">
        <meta name="keywords" content="FOI, WebDiP, 2020.">
        <link href="../css/bromic.css" rel="stylesheet" type="text/css" />
        <link href="../css/bromic_prilagodbe.css" rel="stylesheet" type="text/css" media="screen and (max-width:1024px)" />
        <link href="../css/bromic_ispis.css" rel="stylesheet" type="text/css" />
        <meta name="author" content="Borna Romić">
        <meta name="keywords" content="FOI, WebDiP, 2020.">
        <meta name="description" content="Stranica s tablicom.">
        <style type="text/css">
            .bicDogadjaji{
                font-size: 30pt;
            }

            .tablicaEventovi{
                border: 0.5vw solid;
                border-radius: 3vw;
                flex-wrap: wrap;
                justify-content: center;
            }

            th,td{
                padding: 15px;
                height:20px;
            }
            #boja1{
                background-color: #66ffcc;
            }
            #boja2{
                background-color: #429bf5;
            }
            #boja3{
                background-color: #8a42f5;
            }
            #boja4{
                background-color: #f54272;
            }
            #boja5{
                background-color: #7542f5;
            }
            #boja6{
                background-color: #4a5e52;
            }
            #sadrzaj{
                font-family: "Palatino Linotype", "Book Antiqua", Palatino, serif;
            }
            h2{
                text-align: center;
            }

        </style>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="//code.jquery.com/jquery-1.12.4.js"></script>
        <script type="text/javascript" src="../javascript/bromic_jquery.js"></script>
    </head>
    <body class="resetka">
        <header class="spojiSveStupceZaglavlje">
            <p><img class="slika" usemap="#mapa1" src="../multimedija/logo_bicikl.png" alt="stranica logo" width="130" height="80" />
                <map name="mapa1">
                    <area href="../index.php" alt="pravokutnik" shape="rect" coords="0,0,130,80"/></map>
            </p>
            <h1>Odabir pobjednika utrke</h1>
            <form name = "pretrazivanje" id="pretrazivanje" method= "post"
                  action = "http://barka.foi.hr/WebDiP/2019/materijali/zadace/ispis_forme.php">
                <?php
                if (isset($_SESSION["uloga"]) && $_SESSION["uloga"] < 4) {
                    echo "<a href=\"../odjava.php\">Odjava</a>";
                } else {
                    echo "<a href=\"../obrasci/prijava.php\">Prijava</a>";
                }
                ?>

            </form>
        </header>
<?php
include '../meni.php';
?>
        
        <div id="sadrzaj" class="spojiStupce" style="overflow-x:auto;">
            <table border="1" >
                <caption>Gotove utrke</caption>
                <thead>
                    <tr>
                        <th>ID utrka</th>
                        <th>Naziv utrke</th>
                        <th>Vrijeme završetka</th>
                    </tr>
                </thead>
                <tbody class="tableUt" id="tableUt">

                </tbody>
            </table> 
            <table border="1" >
                <caption>Rezultati utrke</caption>
                <thead>
                    <tr>
                        <th>Ime</th>
                        <th>Prezime</th>
                        <th>Korisničko ime</th>
                        <th>Vrijeme završetka</th>
                    </tr>
                </thead>
                <tbody class="tableRez" id="tableRez">

                </tbody>
            </table> 
        </div>

        <form method="POST" action="">
            <div id="myModal" class="" role="dialog">
                <div class="">
                    <div class="">
                        <div class="">
                        </div>
                            <div class="">
                                <div class="">
                                    <input readonly type="hidden" id="utrkaId" name="utrkaId" class="">
                                </div>
                            </div>
                        <div class="">
                            <h4 class="">Odaberi pobjednika</h4>
                        </div>
                        <fieldset>
                            <div class="">
                                <div class="">
                                    <label>ID korisnika</label><br>
                                    <input readonly type="text" id="korisnikId" name="korisnikId" class=""><br><br>
                                </div>
                                <div class="">
                                    <label>Opis</label><br>
                                    <textarea name="textVeliki" id="textVeliki"  cols="30" rows="5"></textarea><br>
                                </div>
                            </div>
                            <div class="">
                                <br><input type="button" id="spremi" name="spremi" class="spremi" value="Spremi"><br>
                                <input name="reset" type="reset" value="Isprazni polja" />
                            </div>
                        </fieldset>
                    </div>
                </div>
            </div>
        </form>
        
        <footer class="spojiSveStupcePodnozja">
            <address>Kontakt:<a href="mailto:bromic@foi.hr">Borna Romić</a></address>
            <p class="tekst"> Ime i prezime: Borna Romić</p>
            <p class="tekst">Datum rođenja: 30.03.1998.</p>
            <p><small>&copy; 2020. B. Romić</small></p>
        </footer>
    </body>
</html>