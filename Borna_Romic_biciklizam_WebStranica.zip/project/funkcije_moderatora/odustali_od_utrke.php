<?php
    $putanja = dirname($_SERVER["REQUEST_URI"], 2);
    $direktorij = dirname(getcwd());
    include '../zaglavlje.php';
    error_reporting(E_ERROR | E_PARSE);

    if (!isset($_SESSION["uloga"]) || $_SESSION["uloga"] > "2") {
        header("Location: ../obrasci/prijava.php");
        exit();
    }
    $korIme = Sesija::dajKorisnika();
?>

<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html lang="hr">

    <head>
        <title>Odustali od utrke</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="author" content="Borna Romić">
        <meta name="keywords" content="FOI, WebDiP, 2020.">
        <link href="../css/bromic.css" rel="stylesheet" type="text/css" />
        <link href="../css/bromic_prilagodbe.css" rel="stylesheet" type="text/css" media="screen and (max-width:1024px)" />
        <link href="../css/bromic_ispis.css" rel="stylesheet" type="text/css" />
        <meta name="author" content="Borna Romić">
        <meta name="keywords" content="FOI, WebDiP, 2020.">
        <meta name="description" content="Stranica s tablicom.">
        <style type="text/css">
            .bicDogadjaji{
                font-size: 30pt;
            }

            .tablicaEventovi{
                border: 0.5vw solid;
                border-radius: 3vw;
                flex-wrap: wrap;
                justify-content: center;
            }

            th,td{
                padding: 15px;
                height:20px;
            }
            #boja1{
                background-color: #66ffcc;
            }
            #boja2{
                background-color: #429bf5;
            }
            #boja3{
                background-color: #8a42f5;
            }
            #boja4{
                background-color: #f54272;
            }
            #boja5{
                background-color: #7542f5;
            }
            #boja6{
                background-color: #4a5e52;
            }
            #sadrzaj{
                font-family: "Palatino Linotype", "Book Antiqua", Palatino, serif;
            }
            h2{
                text-align: center;
            }

        </style>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="//code.jquery.com/jquery-1.12.4.js"></script>
        <script type="text/javascript" src="../javascript/bromic_jquery.js"></script>
    </head>
    <body class="resetka">
        <header class="spojiSveStupceZaglavlje">
            <p><img class="slika" usemap="#mapa1" src="../multimedija/logo_bicikl.png" alt="stranica logo" width="130" height="80" />
                <map name="mapa1">
                    <area href="../index.php" alt="pravokutnik" shape="rect" coords="0,0,130,80"/></map>
            </p>
            <h1>Odustali od utrke</h1>
            <form name = "pretrazivanje" id="pretrazivanje" method= "post"
                  action = "http://barka.foi.hr/WebDiP/2019/materijali/zadace/ispis_forme.php">
                <?php
                if (isset($_SESSION["uloga"]) && $_SESSION["uloga"] < 4) {
                    echo "<a href=\"../odjava.php\">Odjava</a>";
                } else {
                    echo "<a href=\"../obrasci/prijava.php\">Prijava</a>";
                }
                ?>

            </form>
        </header>
<?php
include '../meni.php';
?>
        <section id="sadrzaj" class="spojiStupce" style="overflow-x:auto;">
            <table id="tablica" border="1" >
                <caption>Buduće utrke</caption>
                <thead>
                    <tr>
                        <th>ID utrke</th>
                        <th>Naziv utrke</th>
                        <th>Datum početka</th>
                        <th>Biciklijada</th>
                        <th>Max broj natjecatelja</th>
                        <th>Status utrke</th>
                    </tr>
                </thead>
                <tbody class="tableData" id="tableData">
                    
                </tbody>
            </table> 
            <table border="1" >
                <caption>Korisnici koji su odustali</caption>
                <thead>
                    <tr>
                        <th>Ime</th>
                        <th>Prezime</th>
                        <th>Korisničko ime</th>
                        <th>Razlog odustajanja</th>
                    </tr>
                </thead>
                <tbody class="tableRez" id="tableRez">

                </tbody>
            </table> 
        </section>
        <form method="POST" action="">
            <div id="myModal" class="" role="dialog">
                <div class="">
                    <div class="">
                        <div class="">
                        </div>
                            <div class="">
                                <div class="">
                                </div>
                            </div>
                            <div class="">
                                    <label>ID utrke</label>
                                    <input readonly type="text" id="utrkaId" name="utrkaId" class=""><br><br>
                            </div>
                            <div class="">
                                <input type="hidden" value="<?php echo $korIme['korisnik']; ?>" id ="KORIME"/>
                            </div>
                    </div>
                </div>
            </div>
        </form>
        <footer class="spojiSveStupcePodnozja">
            <address>Kontakt:<a href="mailto:bromic@foi.hr">Borna Romić</a></address>
            <p class="tekst"> Ime i prezime: Borna Romić</p>
            <p class="tekst">Datum rođenja: 30.03.1998.</p>
            <p><small>&copy; 2020. B. Romić</small></p>
        </footer>
    </body>
</html>