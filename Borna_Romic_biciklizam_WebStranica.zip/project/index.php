<?php
    $putanja = dirname($_SERVER['REQUEST_URI']);
    //var_dump($putanja);
    $direktorij = getcwd();
    error_reporting(E_ERROR | E_PARSE);

    include './zaglavlje.php';
    //var_dump($_SESSION);
    //var_dump(Sesija::dajKorisnika());
?>

<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html lang="hr">

    <head>
        <title>Početna stranica</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="author" content="Borna Romić">
        <meta name="keywords" content="FOI, WebDiP, 2020.">
        <meta name="description" content="Početna stranica o biciklizmu.">
        <link href="css/bromic_pocetna.css" rel="stylesheet" type="text/css" />
        <link href="css/bromic_prilagodbe.css" rel="stylesheet" type="text/css" media="screen and (max-width:1024px)" />
        <link href="css/bromic_ispis.css" rel="stylesheet" type="text/css" />
        <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/smoothness/jquery-ui.css">

        <script type="text/javascript" src="javascript/bromic.js"></script>
        <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="//code.jquery.com/jquery-1.12.4.js"></script>
        <script src="//code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
        <script type="text/javascript" src="javascript/bromic_jquery.js"></script>
    </head>
    <body class ="resetka">
        <header class="spojiSveStupceZaglavlje">
            <p><img class="slika" usemap="#mapa1" src="multimedija/logo_bicikl.png" alt="stranica logo"/>
                <map name="mapa1">
                    <area href="index.php" alt="pravokutnik" shape="rect" coords="0,0,130,80"/></map>
            </p>
            <h1>Početna stranica</h1>
            <form name = "pretrazivanje" id="pretrazivanje" method= "post"
                  action = "http://barka.foi.hr/WebDiP/2019/materijali/zadace/ispis_forme.php">
                <?php
                if (isset($_SESSION["uloga"]) && $_SESSION["uloga"] <4){
                    echo "<a href=\"odjava.php\">Odjava</a>";
                    //$kor= $_SESSION["korisnik"];
                    //echo "$kor";
                }
                else{
                    echo "<a href=\"obrasci/prijava.php\">Prijava</a>";
                }
                ?>
            </form>
        </header>
        <nav id="izbornikSlika" class="stupac_1">
            <img usemap="#mapa2" src="multimedija/slika_izbornik.jpg" alt="SlikaIzbornik" width="1600" height="135" />
            <map name="mapa2">
                <area href="ostalo/PopisLokacijaBiciklijada.php" alt="pravokutnik" shape="rect" coords="32,49,382,85"/>
                <area href="ostalo/planirane_utrke.php" alt="poligon" shape="rect" coords="520,50,780,83"/>
                <area href="o_autoru.html" alt="poligon" shape="rect" coords="950, 50, 1180, 83"/>
                <area href="dokumentacija.html" alt="krug" shape="rect" coords="1300, 50, 1580, 83"/>
            </map>
        </nav>
        
        <?php
        include './meni.php';
        ?>

        <section id="slikeIspod" class="spojiSlike1">
            <h4 id="eventSlike">Biciklizam</h4> <br>
            <p class="clanak">Bicikli su proizvedeni u 19. stoljeću i sada ih ima približno milijardu širom svijeta. Oni su glavno prijevozno sredstvo u mnogim dijelovima svijeta.</p>
            <p class="clanak">Biciklizam se široko smatra vrlo učinkovitim načinom prijevoza, optimalnim za kratke do umjerene udaljenosti.
            </p><p class="clanak">Osim toga, vožnja biciklom pruža razne zdravstvene koristi.
            </p>
            <p class="clanak">
                Mnogi biciklistički klubovi održavaju organizirane vožnje u kojima sudjeluju biciklisti svih razina.</p>
            <p class="clanak"> Tipična organizirana vožnja započinje velikom skupinom biciklista, zvanom masa, hrpa ili čak peloton  
            </p><p class="clanak">Vožnje se obično sastoje od nekoliko različitih ruta, razvrstanih po kilometraži, </p><p class="clanak"> i s određenim brojem stanica za odmor, koje obično uključuju osvježenja, alate za prvu pomoć i održavanje.</p><p class="clanak"> Rute se mogu razlikovati i do 160 km. </p>
            <img  class="slikaEvent" src="multimedija/slika_1.jpeg" alt="Slika1" width="300" height="300" />
            <img  class="slikaEvent"  src="multimedija/slika_2.png" alt="Slika2" width="300" height="300" />
            <img  class="slikaEvent" src="multimedija/slika_3.jpg" alt="Slika3" width="300" height="300" />
            <img  class="slikaEvent" src="multimedija/slika_4.png" alt="Slika4" width="300" height="300" />
            <img  class="slikaEvent" src="multimedija/slika_5.jpg" alt="Slika5" width="300" height="300" /><br>
            <img  class="slikaEvent" src="multimedija/slika_6.png" alt="Slika6" width="300" height="300" />
            <img  class="slikaEvent" src="multimedija/slika_7.jpg" alt="Slika7" width="300" height="300" />
            <img  class="slikaEvent" src="multimedija/slika_8.png" alt="Slika8" width="300" height="300" />
            <img  class="slikaEvent" src="multimedija/slika_9.png" alt="Slika9" width="300" height="300" />
            <img  class="slikaEvent" src="multimedija/slika_10.png" alt="Slika10" width="300" height="300" />
        </section>
        <footer class="spojiSveStupcePodnozja">
            <address>Kontakt:<a href="mailto:bromic@foi.hr">Borna Romić</a></address>
            <p class="tekst"> Ime i prezime: Borna Romić</p>
            <p class="tekst">Datum rođenja: 30.03.1998.</p>
            <p><small>&copy; 2020. B. Romić</small></p>
        </footer>
    </body>
</html>