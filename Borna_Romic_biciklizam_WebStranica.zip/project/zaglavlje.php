<?php

require "$direktorij/baza.class.php";
require "$direktorij/sesija.class.php";
Sesija::kreirajSesiju();

/* OVO MI UNISTI INDEX ali mi dnevnik i ovak i onak ne radi pa neka bude za sad
function dodaj_zapis() {
    //MORA SE NA BARCI DODATI CHMOD 777 datoteci dnevnik.log KAKO BI SE UPISIVALO VALJDA
    global $direktorij;
    $sada = date('d.m.Y H:i:s');
    $fp = fopen("$direktorij/izvorne_datoteke/dnevnik.log", "a+");
    
    fwrite($fp, $sada);
    fwrite($fp, ", ");
    fwrite($fp, "http://localhost".$_SERVER["PHP_SELF"]);
    fwrite($fp, "\n");
    fclose($fp);
}

dodaj_zapis();
*/
/*
  vrati_ascPolje
 * @param string $naziv
 */
/*
function vrati_ascPolje($naziv) {
    $fp = fopen($naziv, "r");
    $rezultat = fread($fp, filesize($naziv));
    fclose($fp);
    $polje = explode("\n", $rezultat);
    //var_dump($polje);
    
    for($i = 1; $i< count($polje)-1; $i++){
        $kljuc = explode(", ", $polje[i]);
        $ascPolje[$kljuc[0]] = $kljuc[1];
    }
    return $ascPolje;
}*/
/*
dodaj_zapis
*/
?>